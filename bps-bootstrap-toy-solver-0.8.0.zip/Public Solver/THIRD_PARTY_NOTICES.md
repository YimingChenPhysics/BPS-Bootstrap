# Third-party notices

## KaTeX 0.18.9

The offline mathematics renderer is an unmodified subset of the KaTeX 0.18.9 browser distribution, released on 2026-09-23. It is stored in `src/public_solver/static/vendor/katex/`:

- `katex.min.js`: minified browser API.
- `katex.min.css`: original stylesheet.
- `fonts/`: all 60 WOFF2, WOFF, and TTF files referenced by that stylesheet.
- `LICENSE`: the complete upstream MIT license, including its copyright notice.

Copyright (c) 2013–2020 Khan Academy and other contributors, as stated in the distributed license. No changes have been made to the vendored assets. Optional extensions, development sources, alternative bundles, and command-line tools are not included. Rendering uses these local files and does not require a CDN or an internet connection.

Sources:

- [Official release](https://github.com/KaTeX/KaTeX/releases/tag/v0.18.9)
- [Version-pinned npm package metadata](https://registry.npmjs.org/katex/0.18.9)
- [Downloaded npm archive](https://registry.npmjs.org/katex/-/katex-0.18.9.tgz)
- [Official self-hosting instructions](https://katex.org/docs/browser#download--host-things-yourself)

The archive was checked against the SHA-512 integrity value published in the package metadata before extraction:

```text
sha512-8ad9RyoKsb/g8/yLFE+KAlP+DhbCTRUNi/V9XGsxn0R+trJJltNwzcDNo0q/DEkOy5fQUQTAQyCXCYSE+OakTQ==
```

The unmodified browser files also match the SHA-384 hashes published in the official browser documentation:

```text
katex.min.js   sha384-19KE2cFb3U+RUWmyhBz7aLOGDG8WrRC6hE3oY/HTZZlAAVWYTdmvLC//+TIV3zUx
katex.min.css  sha384-lPx0C4zIUZLpveABMwOFcFeGZwsvKBJfhJ85FN1PYOV7xApBcFMhcAEMVKF8loOI
```

Keep the `fonts/` directory alongside the stylesheet when packaging or relocating the assets. Preserve the upstream license when redistributing this code.
