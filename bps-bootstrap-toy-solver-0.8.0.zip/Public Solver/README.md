# BPS Bootstrap: Toy Solver

For AI agents: [AGENTS.md](AGENTS.md) is the short guide to running and modifying this folder.

## What to share

This folder contains the public application, documentation, and sample inputs.
The source ZIP in `dist/` is ready to give to another person; extract it and
follow the installation instructions below. The wheel in `dist/` is an
alternative for installing the Python package directly.

| Files | Purpose |
| --- | --- |
| `src/`, `launch.py`, `pyproject.toml` | Application and installation files |
| `README.md`, `AGENTS.md`, `docs/`, `THIRD_PARTY_NOTICES.md` | User and agent guides, algebra reference, and bundled-library notices |
| `examples/` | Sample input configurations |
| `dist/` | Clean source ZIP and installable wheel |

Our tests, research comparisons, audits, and local run data are kept separately
in the maintainer's `Public Solver Internal` folder. They are not needed to run
this application. A new user's `.public-solver/` directory is created when they
run the app; it holds their own settings, caches, and history and should not be
included when redistributing the source.

## Overview

A local, configurable large-N moment matrix builder. Define creator
letters, their bosonic or fermionic statistics and exact charges, choose a
truncation level, and generate a canonical Hermitian moment matrix. Unbarred
letters **always create**; their barred partners **annihilate** and carry the
opposite charges.

The solver implements oscillator algebra, trace canonicalization,
charge selection, moment construction, optional system equations, and exact
semidefinite-program (SDP) preparation. Moments are real and identified with
their Hermitian conjugates. Gauge singlets, supercharge equations, and
user-defined symmetry Ward identities can be imposed. Step 3 fixes or bounds observables,
builds affine multi-trace relaxations, removes redundant PSD directions, and
constructs a feasibility, minimization, or maximization problem.
Step 4 solves the prepared problem with native SDPA-GMP and keeps a local run
history. An optional BMN-only SU(3) reduction replaces moment blocks with smaller
highest-weight multiplicity blocks. A separate BMN option imposes upper bounds
on two specified length-six moments.

## Run on your computer

Python 3.10 or later is required. This folder is self-contained: it can be copied
out of the research repository. No parent project, saved research cache,
Node.js installation or external web service is needed. Numerical solving
also requires SDPA-GMP, installed separately as described below.

In a terminal opened in this folder:

```sh
python -m venv .venv
# macOS / Linux:
source .venv/bin/activate
# Windows PowerShell instead:
# .venv\Scripts\Activate.ps1
python -m pip install .
matrix-moments
```

The command opens a browser at `http://127.0.0.1:8769`. Everything runs locally.
Stop it with Ctrl+C. If the browser does not open, visit the printed address.
Use `matrix-moments --port 8770` if that port is occupied. The equivalent Python
entry point is `python -m public_solver`. When developing from this source tree,
`python launch.py` is also available after installing the dependencies.

Open the printed local address to use the application. Opening
`src/public_solver/static/index.html` directly shows an **Open solver** link;
the Python application must be running for generation and saved setups.

## In the interface

1. Enter a LaTeX name such as `X`, `\psi_1`, or `\phi^{a}` in **Naming (LaTeX)**
   and choose its statistics. The **Creation** and **Annihilation** columns
   show live previews. Omit `$` delimiters. Names are case-sensitive.
2. Choose zero to eight charges. Enter exact fractions, integers, or decimals
   for each creator. Annihilator charges are automatically negated.
3. Choose level ℓ. The word basis includes the identity and every word through
   length ℓ; moment entries reach length 2ℓ.
4. Charge neutrality is automatic, for each individual trace factor.
5. In **Loop equations and additional symmetry constraints**, choose whether to impose
   gauge singlets. Under **Supercharge**, select **Supercharge Ward identity (default)**
   or **Matrix relation (specific to e.g. quarter BPS sector)** once, then add
   one or more definitions and any additional symmetry generators.
   Each term has an exact coefficient and an ordered word assembled by clicking
   the rendered creation/annihilation buttons. Click a word token to remove it.
6. In Step 3, optionally add observable constraints. Choose **=**, **≤**, or **≥**
   beside each value to fix an expectation value or impose an upper or lower
   bound. These choices are available for every system. Each observable is a sum of trace terms with real
   exact coefficients; an empty word supplies a constant. Each word must have
   even fermion parity, zero charges, and length at most 2ℓ. Choose **Check
   feasibility**, **Minimize**, or **Maximize**. For either optimization mode,
   define the objective using the same trace-term editor, without a fixed value.
7. Click **Build SDP** once to use the current letters and constraints.
   Inspect the prepared PSD blocks, remaining variables, and
   reconstruction formulas, or download the exact result. Summary cards show
   the total PSD dimension and largest block size. Preparation also works
   without observable constraints; it does not run a numerical solver.
8. Expand **Loop equations** alongside the other prepared-result details to search the
   first 100 generated moment identities, including original matrix trace words and
   canonical trace products. These identities use the final coordinates and
   retain any unresolved free directions. The prepared PSD blocks are the
   page's single matrix view. Model import/export saves all inputs for another
   computer or run.
9. **Step 4: SDP solve** automatically checks the SDPA installation. Use
   **Check again** after installing or repairing it. Choose **Default** or
   **Custom** under **SDPA settings**, then click **Solve**. The iteration log
   streams above the result. **Cancel solve** stops the current numerical run.
   **Historical Runs**, collapsed initially, retains each run's settings,
   physics inputs, result and log across restarts.

### Optional BMN SU(3) reduction

In Step 3, **BMN only: use SU(3) block reduction** uses the paper's
highest-weight reduction of the moment PSD blocks. It is enabled in the built-in
BMN setup and can be switched off.
It requires the seven BMN species, the preset's six charge columns, and both
SU(3) symmetry generators; letter names and ordering may change. Other sectors
continue through the general solver. JSON requests use
`"bmn_su3_reduction": true` inside `preparation`.

The browser shows both BMN controls only when Steps 1–2 match the built-in BMN
configuration, including its truncation level, gauge singlet, full supercharge
Ward equations, and both SU(3) generators. Matching ignores display names and
species and term ordering, equivalent rational spellings, and whitespace in
the preset's coefficients. The order of letters within each word must match.
New matching configurations with no Step 3 configuration start with both
controls enabled and Λ = 100. Loading a saved Step 3 configuration preserves
its explicit choices, including disabled or omitted BMN options.

The reduction certifies the full moment form's SU(3) invariance exactly and
retains all irrep multiplicities. It leaves the general solver's independent
variables, fixed observables, reconstruction, objective, cutoff bounds and
multitrace relaxation unchanged. It does not adopt the research solver's
different scalar coordinates. Feasibility is preserved, but the numerical
feasibility margin is basis dependent and should not be compared across the
two block representations.

The projected blocks enter Step 3 directly, so fixed-value preparation and
null-direction reduction run once on the smaller blocks. The original charge
blocks do not undergo a separate general preparation first. Steps 1–2 still
construct the moment matrix and impose its constraints using the shared code.

The certified projection and auxiliary blocks are stored together in one complete
model checkpoint, independently of Step 3 targets, objectives, and cutoff.
Fixed-observable definitions identify the baseline null-direction plans. New
values certify those plans at each point without searching for additional
special-value nulls. Complete per-value preparations are not cached.

### Optional BMN observable cutoff

Directly below the SU(3) control in Step 3, **BMN only: impose positive cutoff on
two observables** adds the upper bounds

```text
⟨tr((f bar(f))³)⟩ ≤ Λ
⟨tr((φ₁ bar(φ₁))³)⟩ ≤ Λ
```

The two observables share one positive exact value of Λ, initially `100` in the
built-in BMN setup. Other values such as `10`, `3/2`, or `sqrt(2)` are accepted.
The option is enabled in that setup, can be switched off, and works
independently of the SU(3) reduction. The backend requires the seven BMN species and their six charge columns,
identified by charges and statistics rather than names or ordering, and level
`ℓ ≥ 3`. JSON requests use `"bmn_observable_cutoff": "10"` inside `preparation`;
omission or `null` disables it.

Here “positive cutoff” means Λ is positive and each observable is bounded
above. It introduces exactly two 1×1 PSD blocks, displayed individually in
**Prepared PSD blocks**. It adds no lower bounds and does not bound every
independent coordinate. The ordered words are retained through the exact
oscillator and constraint relations, including contact terms.

### SDPA installation check

Use the native **SDPA Multiprecision (SDPA-GMP)** executable, usually named
`sdpa_gmp`. Ordinary double-precision SDPA and a Python wrapper alone do not
provide this interface. No particular installation directory is required.
SDPA is optional for building and inspecting the prepared SDP.

The app looks for the executable in this order:

1. The `SDPA_GMP_EXECUTABLE` environment variable.
2. The `sdpa_executable` setting in `<data-dir>/solver.json`.
3. `<data-dir>/bin/sdpa_gmp` (or `sdpa_gmp.exe`).
4. The `sdpa_gmp` command on the server's `PATH`.

The data directory defaults to `.public-solver` in the folder where the app is
started; `--data-dir` can change it. A coding agent can install the executable
anywhere and register its absolute path in `.public-solver/solver.json`:

```json
{"sdpa_executable": "/absolute/path/to/sdpa_gmp"}
```

For Windows, use an absolute path such as `C:/tools/sdpa_gmp.exe`. A relative
path is resolved against the data directory unless it names a command on PATH.
The file is local machine configuration, separate from saved physics setups
and excluded from the publishable package. An invalid explicit selection is
reported instead of silently choosing another solver.

Settings are read again on each check, so updating `solver.json` needs no
restart. Restart the app after changing its environment or PATH. A missing
installation produces a short instruction to ask your coding agent to install
SDPA-GMP and return to **Check again**. A broken installation produces a repair
instruction; diagnostic details are available from `/api/solver/status` for
the coding agent. The app never installs software itself.

A successful check verifies the multiprecision version and solves a disposable
one-variable problem, checking its known optimum, returned solution, and at
least 192-bit arithmetic. Version and solve checks have 5- and 10-second timeouts.
Test files are created in temporary storage and cleaned up. This readiness
check is independent of the user's model, caches, and generated SDP.

### SDPA settings and results

The default controls follow the experimental multiprecision workflow:

| Control | Meaning | Default |
| --- | --- | --- |
| Precision | Requested arithmetic precision in bits | 384 |
| Stopping tolerance | SDPA objective-gap and feasibility tolerances | 1e-14 |
| Initial scale (λ*) | Scale of the initial primal and dual matrices | 2 |
| Feasible centering (β*) | Search-direction centering when the iterate is feasible | 0.1 |
| Infeasible centering (β̄) | Search-direction centering when the iterate is infeasible | 0.2 |
| Maximum iterations | Iteration limit | 500 |

See the [SDPA parameter documentation](https://sdpa-python.github.io/docs/usage/params.html)
for the native meanings. GMP may round the requested precision up to a machine
limb boundary; the returned effective precision is checked. Custom settings
apply only to numerical runs and do not invalidate the exact build caches.

For feasibility, the solver maximizes a common margin `t` in the retained
physical blocks `M(r) − tI ≥ 0`. The optional bounds `−Λ ≤ rᵢ ≤ Λ` are kept
unshifted. A validated positive margin is reported as feasible, a validated
negative margin interval as infeasible, and a near-zero or inadequately
validated result as unresolved. Fully constant problems are checked directly.
For minimization or maximization, the exact prepared objective, including its
constant offset, is passed to SDPA with the corresponding sign convention.

Before SDPA starts, the page reports **Preparing SDPA input** with entry counts,
then **Writing SDPA input**. Prepared artifacts contain a single exact sparse
coefficient table with references from matrices and observables. SDPA export
consumes that table directly, validates exact coefficients and symmetry, and
adds the feasibility margin algebraically. Old text artifacts are imported
once at the compatibility boundary. Export can be cancelled.
The status changes to **Running SDPA** for numerical iterations and
**Checking the SDPA result** for validation afterward.

The app independently checks solution matrices, PSD eigenvalues, affine
residuals, primal/dual objective values and precision using multiprecision
arithmetic. It shares numerical coefficient conversions within each validation
run and reuses eigenvalue checks when physical and solver matrices are identical.
Conclusions and objective intervals are numerical assessments, not rigorous
mathematical certificates. Reaching an iteration limit or a
native termination phase alone is insufficient to claim optimality,
infeasibility or unboundedness. A feasible point may be reported with
optimality unresolved. Results include the selected BMN observable cutoff.

For a minimization or maximization objective with multiple trace terms,
**Value of components** shows each term's value at the returned optimal or
feasible point. If optimality remains unresolved, the table says so. Weighted
objectives also show coefficients and contributions to the total. These are not
separate minima or maxima. Components depending on unresolved loop directions
are marked **Not determined individually**. This display is also available for
saved runs, without repeating the solve.

Each solve is saved under `.public-solver/solves/<run-id>/`, separately from
source and tests. This contains an immutable input snapshot, exact prepared
SDP, iteration log and checked result, plus native problem, parameter and
output files when numerical iterations are needed. **View** reopens a historical log and result; **Download run** exports
the setup, prepared SDP, settings and checked result as JSON. The log display
keeps its most recent 100 KB; the full log remains in the run directory.
One numerical solve runs at a time. Reloading the page reconnects to an active
solve; interrupted runs remain in history. Changing model inputs requires a
new build before a new solve can start. Numerical settings are recorded per
run, separately from named physics setups.

The shared mode applies to every supercharge or matrix-relation entry. Use
**Add supercharge** or **Add matrix relation** for another definition; each has
its own name, terms, removal control and rendered equations. Untouched blank
entries impose nothing. Existing saved single-definition setups still load.
A traced supercharge must have odd fermion parity; a symmetry generator must
be even. Hermitian adjoints are included automatically. Coefficients accept
integers, exact fractions/decimals, `sqrt(2)`, `i`, and arithmetic with parentheses.
Use **Matrix relation (specific to e.g. quarter BPS sector)** for a reduced polynomial such as `F = XY − YX`:
enter two terms, `+1` with word `X Y`, and `−1` with word `Y X`. The preview shows
`<tr(F O)> = 0` and `<tr(O F†)> = 0`, with the adjoint on the opposite side.
For example, the bosonic eighth-BPS setup can include three separate entries
`[x,y]`, `[x,z]` and `[y,z]`. The matrix polynomials are inserted inside traces;
the app does not impose unrestricted operator identities `F = 0`.
In **Supercharge Ward identity (default)** mode the preview instead shows each traced generator and
the graded Ward equations `<[Q,tr(O)]_gr> = <[Q†,tr(O)]_gr> = 0`.
Here `O` ranges over charge-compatible words within the truncation. For a
generator whose longest term has length `d`, insertion lengths are at most
`2ℓ − d` in matrix mode or `2ℓ + 2 − d` in Ward mode. Only neutral outputs
survive, and exact proportional equations are deduplicated.
The existing limit is twelve definitions in total, including symmetry generators.
Import/export retains the `supercharges` list with a `kind` on each entry;
all entries must have the same kind (`ward` or `matrix`). An omitted kind
means `ward`, preserving the original format.
All terms in one definition must have the same fermion parity. Symmetry
generators may include several charge components; only neutral outputs survive.

Example request files include [a two-boson system](examples/two_boson_constraints.json)
and [BMN gauge/supercharge equations](examples/bmn_constraints.json). Import
them through **Import model**, or use them with the batch command below.
The BMN example imposes no additional flavor symmetry.

The matrix is `M[i,j] = <tr(A[i] adjoint(A[j]))>`. Moments equal their Hermitian
conjugates, including all canonical adjoint contact relations, and are
represented by independent real coordinates. A display variable such as `r7`
is identified in **Prepared variables**. The bottom **Loop equations** list
shows the resulting moment identities, including linear combinations and
contact constants. Bundled KaTeX typesets
names, overbars, subscripts and fractions without an internet service.
Independent-coordinate selection follows the research reducer's priority:
eliminate non-normally-ordered single traces first, then multi-traces, then
normally ordered single traces. Within each single-trace class, shorter words
are eliminated first. Normal ordering uses creators before annihilators and
the order of the defined species. The `r` labels retain their moment numbering;
their numeric order does not determine which variables are eliminated.
Moment blocks originate from basis words with equal charges; each matrix
entry is neutral. Auxiliary blocks are numbered separately as **Multitrace
relaxation block 1**, **Multitrace relaxation block 2**, and so on. **Block size**
states the selected matrix dimensions. **Total PSD dimension** sums the row
counts of all displayed blocks; **Largest block** gives the largest matrix size.

The page previews the first 100 rows of result tables and the first 12 × 12
entries of each matrix. Formulas longer than 1,000 characters are labelled
“Long expression omitted.” Full counts and matrix dimensions are still shown.
The downloaded JSON and numerical solver retain every block and all exact
nonzero entries; entries absent from those full matrices are zero. Full
mathematical data is retained as exact coefficients. Formula text and optional
LaTeX are rendered only for requested previews or explicit text downloads. The browser display
does not receive the solver's internal coefficient data. Basis and entry indices in
JSON start at zero. Signed species IDs encode words: positive means creator,
negative means annihilator, and absolute value is the one-based species index.

## Mathematical scope

Each letter is divided by √N and `tr = Tr/N`. Canonicalization uses the
oscillator relations, graded cyclic rotations, and their color-index contact
terms. These contacts can split one trace into several. Only the leading
large-N trace algebra is retained; this is not a finite-N algebra engine.

The large-N factorization consequence imposed during moment construction is **neutrality
of every trace factor**. For example, `<tr(X) tr(bar(X))>` vanishes when X has
nonzero charge, even though the total charge is zero. Products of neutral
factors remain symbolic; this stage does not replace them by nonlinear
products of single-trace expectation values. Fermionic trace factors retain
their graded ordering signs. Hermitian-conjugate moments are automatically
identified, with contact terms included. No additional fermion-parity
selection is imposed.

See [the algebra derivation](docs/algebra.md) for the cyclic-contact rule and
the precise approximation. These choices are recorded in every result.

### SDP preparation

Step 3 retains affine equations. If a single-trace expectation is fixed to
`a`, its available products become `<tr(A) tr(B)> = a <tr(B)>`. Fixing an affine
combination `c₀ + Σ cᵢ <tr(Aᵢ)> = v` also imposes
`Σ cᵢ <tr(Aᵢ) tr(B)> = (v − c₀) <tr(B)>` wherever the required products are
available. This includes fixed-fixed products and preserves exact constants.
Unfixed products remain independent relaxed moments, rather than nonlinear
products of optimization variables.

An inequality constrains only the specified expectation value or linear
combination. It does not fix its value, substitute the bound into other
moments, or generate fixed-factor equations. After applying the equality
constraints, `O ≤ v` contributes the scalar PSD block `[v − O]`, and `O ≥ v`
contributes `[O − v]`. Contact terms from the ordered trace words are retained
exactly. These blocks have `kind="inequality"`, stay unshifted during the
feasibility-margin calculation, and appear individually in the prepared SDP.
Constant bounds are retained, including contradictions detected before solving.

For JSON compatibility, both equality and inequality rows use the existing
`preparation.fixed_observables` list. Add `"relation": "<="` or
`"relation": ">="` to choose an inequality. An omitted relation or `"="`
means equality; existing saved setups keep their original meaning. The
prepared output separates equality rows in `fixed_observables` from bounds in
`observable_inequalities`. To bound an observable on both sides, add two rows.

For selected neutral, even trace words `Wᵢ` of length at most ℓ, let
`mᵢ = <tr(Wᵢ)>`, `Dᵢⱼ = <tr(Wᵢ) tr(Wⱼ)>`, and
`Mᵢⱼ = <tr(Wᵢ adjoint(Wⱼ))>`. Preparation adds the two PSD conditions
`[[1, mᵀ], [m, D]] ≥ 0` and `M − D ≥ 0`: the double-trace Schur block and
the color-traceless covariance block. Required missing double-trace entries
are introduced as exact auxiliary coordinates. Identical double traces not
covered by this block retain their individual 2×2 PSD conditions.

User-defined charges can allow neutral odd trace factors. Those factors remain
in the moment matrices and graded trace identities, but are excluded from
these auxiliary bosonic Schur and covariance blocks. Preparation does not add
a fermion-parity selection rule.

After eliminating the fixed-observable and factorization equalities, numerical
SVD and pivoted QR propose each affine block's **common kernel**, the intersection
of the kernels of its constant matrix and every variable coefficient matrix.
The proposed rows undergo exact reduction, and every proposed null vector must
annihilate all coefficient matrices exactly. Only certified directions are removed. The retained
principal submatrix is PSD-equivalent at every variable assignment; a null
direction at just one assignment is insufficient. Each block exports its
`kept_indices` and `nullspace` in the original block basis.

For scans over fixed values, the solver caches the initial retained dimension
and selected original coefficient rows. The key includes the unfixed model and
fixed-observable definitions, but excludes their numerical targets, display
names, objective, and cutoff. At a new point it rebuilds those selected rows,
computes their exact kernel, and certifies that kernel against the complete
new coefficient stack at the cached dimension. It does not search for additional
null directions at later values. If the cached selection fails, the full block
is retained and the baseline plan is left unchanged. A baseline with no removed
directions likewise keeps the full block at all later values. An uncertified
initial numerical proposal also leaves the block full-sized. Null vectors and
compressed matrices from an earlier numerical point are never blindly reused.
The cache stores only a dimension, row indices, and coefficient names, in one bounded record per scan setup;
completed block plans survive cancellation.

Whole blocks related by an exact simultaneous row/column permutation are
removed automatically from the unfixed model, before applying any Section 3
settings. The model-wide certificates are cached and reused across changes to
fixed observables, objectives, and cutoffs. No additional equivalence search
is performed after fixing values or after common-kernel compression.
The check compares every constant and variable coefficient; it never assumes
a symmetry from letter names, relabels independent variables, or samples
numerical moment values. This includes the boson-exchange duplicates in the
quarter-BPS trace-Ward workflow. Ambiguous searches are bounded and leave the
block in place if equivalence is not certified. The entire model-wide
equivalence search has a two-minute budget. When it expires, preparation
continues with the certified reductions already found and retains all remaining
blocks. This safe partial reduction is cached for later Section 3 settings.
General dense congruences and
irreducible representation decomposition remain outside this reduction.

Only retained blocks enter `blocks` and the displayed counts and dimensions.
`block_reduction.before_compression` records the model-wide certificates, indexed by
the original `source_index`. Each permutation `p` certifies
`removed[i,j] = retained[p[i],p[j]]` before fixing observables, so the equality
remains valid for every allowed Section 3 setting. The compatibility fields
`after_compression` and `omitted_compressed_blocks` are empty.
`null_compressed_psd_dimension` is the
dimension after null removal before whole-block removal. The final dimension
plus `removed_redundant_psd_dimension` equals that intermediate dimension.

Finally, scalar directions invisible to all prepared PSD blocks, any objective,
every observable inequality, and the enabled BMN cutoff observables are removed
by selecting independent coefficient columns. Setting the dropped parameters
to zero chooses a **representative**, not an additional physical equality.
The `reconstruction` list gives that representative in the original moment
coordinates. To recover every moment assignment with the same prepared
matrices, objective value, and bounded observables, add arbitrary real multiples of the vectors in
`scalar_coordinate_reduction.reconstruction_nullspace`, ordered by
`reconstruction_symbol_order`. The separate `nullspace` in that object uses
the equality-free `parameter_order`. Thus PSD-invisible moments are not
asserted to vanish or be uniquely determined.

For full moment identities, `moment_reductions` resolves the original matrix
trace words and canonical trace products in the final coordinates. When
PSD-invisible freedom remains, these expressions include arbitrary real
parameters `t1`, `t2`, etc., listed in `loop_free_parameters`. The
**Loop equations** view displays these full identities. The separate
`reconstruction` list remains the representative obtained by setting those
free parameters to zero.

The optional `preparation.bmn_observable_cutoff` adds exactly two 1×1 PSD blocks:
`[Λ − ⟨tr((f bar(f))³)⟩]` and `[Λ − ⟨tr((φ₁ bar(φ₁))³)⟩]`.
With the standard BMN species order their literal words are
`[7,-7,7,-7,7,-7]` and `[1,-1,1,-1,1,-1]`. These are the alternating
creator–annihilator words; replacing them by normal-ordered words changes the
observable through contact terms. Preparation resolves each physical moment
and transports it through fixed-value equalities. Scalar-coordinate selection
retains the directions needed by each observable before appending its bound.
The cutoff adds no new optimization variables, and both blocks are retained
even when an observable becomes a constant.

The export records the bound and its physical targets in
`bmn_observable_cutoff`. Its scalar blocks have `kind="cutoff"`, contribute to
the displayed dimensions, and receive no feasibility-margin shift. Each block
has its own entry in **Prepared PSD blocks**.

The former general `preparation.variable_cutoff` bounded the absolute value of
each independent coordinate. That feature has been removed. Such bounds depend
on the coordinate convention and are different mathematical constraints from
the two physical-moment bounds above; old requests are never silently converted.

The default problem is feasibility. To construct an optimization problem, add
`preparation.optimization`, for example:

```json
{"mode": "minimize", "objective": {"name": "J", "terms": [
  {"coefficient": "1", "word": [1, -1]},
  {"coefficient": "-1", "word": [2, -2]}
]}}
```

Use `"maximize"` to reverse the direction. Omitting `optimization`, using
`null`, or setting `{"mode":"feasibility"}` selects feasibility. The objective
is a real linear combination of charge-neutral, even-parity trace words within
the truncation. An empty word supplies a constant. It is transformed by the
same exact canonicalization and physical equalities as the moments, including
all constant contact terms. Scalar-coordinate reduction preserves both the
PSD entries and the objective; no objective-sensitive direction is discarded.
The objective is never imposed as an extra PSD constraint or fixed equality.
The prepared result exports its `optimization.mode`, `expression`, and `latex`
in the final coordinates. A fully fixed objective remains a constant.

## Cache, progress and limits

All automatic caches live in `.public-solver/cache/` (or `cache/` inside your
chosen `--data-dir`). They can become large. To reclaim space, stop the app and
delete only this `cache/` folder; it is recreated on the next build. Saved
setups, solver settings, build results, and run history are kept outside it.
Clearing this folder also starts new null-direction scan baselines: the first
subsequent point determines their retained dimensions. Keep the compact null
plans when continuing a scan with its original baseline convention.
Do not delete the whole `.public-solver/` folder to clear caches. On macOS,
press Command+Shift+Period in Finder to show folders whose names start with a dot.

Older versions stored `canonical.sqlite3` and `build.sqlite3` directly inside
`.public-solver/`. Those old cache files can also be deleted after stopping the
app; they are no longer used by the browser or batch workflow.

Canonical results are saved as checksummed JSON inside SQLite, under
`.public-solver/cache/canonical.sqlite3`. Keys include the algorithm version and the
ordered species statistics. Canonicalization is independent of display names,
charges and level, so compatible jobs reuse it. Model fingerprints and all
settings remain in each result. Cache files never contain executable pickle
data.

Prepared builds persist one complete `compiled_model` checkpoint in
`.public-solver/cache/build.sqlite3`: moments, exact coefficient rows,
relaxation blocks, optional BMN projection, coordinate definitions, and certified
block equivalences. Its key covers model inputs, level, constraints, SU(3)
switch, and algorithm/SymPy versions. It excludes fixed definitions and targets,
names, objective, inequalities, and cutoff. Changing the SU(3) projection
switch selects a different compiled model. The
checkpoint is atomic and self-contained; a
missing or invalid checkpoint rebuilds the whole model through the same code.
There are no separate expression, relaxation, or fixed-factor caches to reconcile.

The reusable stages follow their actual dependencies:

| Stage | Reused when Step 3 changes | Work at a new numerical point |
| --- | --- | --- |
| Canonical algebra and constraint-family reductions | All Step 3 observable and target changes | None |
| Complete unfixed model, relaxation, projection, and block-equivalence certificates | Fixed definitions, targets, names, objectives, inequalities, and cutoff | Load the same exact coefficient rows |
| Baseline null-direction plans | Same equality definitions; targets, names, objective, inequalities, and cutoff may change | Rebuild selected rows and certify them exactly at the current values |
| Fixed-factor equations and final SDP | No complete per-point cache | Apply current targets, eliminate equalities, certify compression, select coordinates, and reconstruct moments |

The fixed-factor representation solves currently run in point preparation.
They do not rebuild the model, relaxation matrices, or block equivalences.
This keeps a single preparation algorithm while retaining the expensive
reusable stages needed for scans.

Full column rank can be certified directly from exact coefficient rows, before
or after certified common-kernel compression. Such compression preserves the
coefficient information, so a complete earlier proof avoids redundant scalar
elimination. When that proof is incomplete, ordinary exact elimination still
determines the ordered coordinates and reconstruction kernel.

A separate compact null-direction plan records the baseline dimension and
coefficient-row selections for each fixed-observable definition. Target values,
display names, objective, inequalities, and cutoff do not alter that key. Every
reuse is certified at the current point; a failed certificate keeps the full
block and preserves the baseline plan. Point preparation is always recomputed
from the compiled model, without storing complete per-setting results.
The null-plan identity describes the exact unfixed matrices and coordinates and
uses a separate storage namespace. Rebuilding or changing the compiled cache
format therefore does not reset the baseline. Existing plans from the previous
workflow are adopted through an exact historical-key lookup at the upgrade
boundary. That compatibility lookup may render the old key once; ordinary
point preparation continues to use coefficient rows.

Within the model layer, exact reduction proceeds through symmetry, gauge, and
supercharge or matrix-relation families. Each family substitutes its results
into the next and saves a completed checkpoint. Substitutions are extracted
from nonzero sparse coefficients, with the existing variable priority retained;
the final relations and independent variables agree with a single stacked
reduction. New reductions are checked exactly before saving. Matching,
checksummed checkpoints retain structural validation without repeating the
algebraic proof; `verify_cached=True` on the reducer enables that diagnostic.
Completed family
checkpoints survive cancellation and contain no fixed-observable values,
objective or BMN observable cutoff. The progress message identifies the current
family and whether it is being reduced, checked, or reused.

The compiled model and completed result use the same coefficient-native artifact
format. Each distinct row and exact number is stored once; matrices, moments,
and observables reference those tables. The browser receives a bounded rendered
preview. All moment identities, PSD entries, variables, equalities, and
reconstruction data remain available in the full artifact. Python callers can
use `build_request_data` for native rows or `build_request` for complete text
output; both execute the same scientific algorithm. Text downloads render on
demand. Fixed values, objective choices, and Λ affect only point preparation.
Stage keys include the build algorithm and
SymPy versions; changes to build mathematics must increment
`BUILD_CACHE_VERSION` in `build_cache.py`. Null-direction baseline plans use
their independent scientific identity and namespace. The stage cache uses checksummed JSON,
atomic writes, and keeps at most 16 entries per stage for the current algorithm.
This existing retention limit also applies to null plans: numerical target
changes share one entry, but enough distinct models or equality definitions
can evict an older baseline. Returning to an evicted scan starts a new baseline,
just as explicitly clearing the cache does.
Damaged entries are rebuilt; unavailable or oversized stage-cache storage
disables reuse without aborting a valid calculation.
Caching is automatic and persists across server restarts. The progress display
reports reuse; exports include stage statuses in `build_cache` and total current
build time in `build_elapsed_seconds`.

Final point preparation is not cached. Changes confined to that calculation do
not invalidate the compiled Sections 1–2 model.

Jobs run in a separate process. The page shows progress and allows cancellation;
completed cache entries survive cancellation. Results and inputs are retained
under `.public-solver/jobs/`. Choose another storage directory with `--data-dir`.

Use **Save set up as:** at the top of the page to store a named setup, then
choose it under **Saved setups** and click **Load** to restore it. Setups include
letter names and statistics, charge names and values, the truncation level,
gauge selection, supercharge mode and terms, symmetry generators, and Step 3
observable constraints with their relations, both optional BMN controls, and optimization mode and objective,
including exact input values. Saving
an existing name updates that setup; the button changes to **Update**. Loading
restores the inputs without generating a matrix.

The BMN observable cutoff and its exact value are saved and restored with the
setup. Existing records containing the removed `variable_cutoff` option remain
stored and readable. Loading or importing one removes the obsolete option from
the editable copy and shows a persistent notice. The new BMN cutoff remains off
unless it was explicitly selected; the old bound is never converted into it.
The saved record changes only when you save again. Historical solve records
retain their original cutoff meaning. Batch and Python requests must remove the
obsolete active option explicitly.

Named setups are stored in `.public-solver/setups.sqlite3`, separately from the
canonical cache and generated results. They survive restarts and are shared by
browsers using the same solver data directory. **Export model** and **Import
model** remain available for transferring setups to another computer.

**Saved setups** also includes four built-in configurations on every installation:

| Setup | Initial level | Included constraints |
| --- | --- | --- |
| Half BPS | 4 | One boson `z`, one charge, gauge singlet; no supercharge equation |
| Quarter BPS | 4 | Two bosons, two charges, gauge singlet, `[x,z]` matrix relation, SU(2) Ward generator |
| Eighth BPS | 3 | Three bosons, three charges, gauge singlet, three commutator matrix relations, three SU(3) Ward generators |
| BMN | 3 | Three scalar bosons, three fermions and `f`; five physical charges plus the bonus charge, gauge singlet, full supercharge Ward equations, two SU(3) simple-root Ward generators |

The quarter- and eighth-BPS configurations preserve the author's saved constraints
and observables, with the initial levels listed above.
The eighth-BPS setup also fixes `<tr(z bar(z))> = 1` and minimizes
`<tr(z bar(z) z bar(z))>`. The other three start with unfixed observables and
feasibility. BMN includes SU(3) singlet constraints by default, using the two
simple-root generators and their automatic adjoints. Its Step 3 defaults also
enable SU(3) block reduction and the two-observable upper cutoff with Λ = 100.
All presets use unbarred creators and barred
annihilators; BMN includes the relative `sqrt(2)` coefficient in the notes.

Built-in configurations are packaged in `src/public_solver/presets/`; they do
not depend on a local database or the research repository. Loading one proposes
a name ending in `(copy)` for saving edits under **My setups**. Personal copies
never overwrite the built-in version.

Builds have no default size ceilings on basis words, selected matrix entries,
constraint generation, or covariance trace factors. Available memory and
computation time determine practical sizes; a running build can be cancelled.
Optional basis and entry limits apply only if explicitly supplied at launch:

```sh
matrix-moments --max-basis-size 10000 --max-selected-entries 150000
```

The server only listens on this computer's loopback address. This local
application is not a public multi-user hosting service.

## Batch and Python use

```sh
matrix-moments --generate examples/mixed_letters.json --output moments.json
```

```python
from public_solver import Model, Species, build_request

model = Model((Species("X", "boson", ("1",)),), ("R",))
request = {"model": model.to_dict(), "level": 3, "preparation": {
    "fixed_observables": [{
        "name": "n", "value": "3/2",
        "terms": [{"coefficient": "1", "word": [1, -1]}]
    }]
}}
result = build_request(request, cache_path=".public-solver/cache/canonical.sqlite3")
prepared = result["preparation"]

# Reuse the setup while changing a fixed value.
request["preparation"]["fixed_observables"][0]["value"] = "2"
result = build_request(request, cache_path=".public-solver/cache/canonical.sqlite3")
```

`build_request_data` is the coefficient-native workflow used by browser jobs;
`build_request` renders the same result as complete text for Python and batch
callers. Both accept the same request JSON and reuse the compiled Sections 1–2
model and compact null-row plans when `cache_path` is supplied. Without a cache
path they compute everything afresh.
The lower-level `build_moment_matrix` and `prepare_sdp` text adapters remain
available. The historical `prepare_sdp(cache_stages=True)` argument is accepted
for compatibility but does not enable complete per-point caching or select
another preparation algorithm.

`build_moment_matrix` returns a JSON-compatible exact result with model, assumptions,
basis, sparse blocks, moment coordinates, Hermitian relations, selected trace
identities, and cache statistics. Schema version 3 also records the constraint
configuration, exact generated equations, and their rank after Hermitian
reduction. Their `terms` coefficients are exact arithmetic strings; each term's
`traces` field uses the same signed token convention as the moment matrix.
The `canonical_traces` export
contains expectation identities **after** neutral-factor selection; the
canonical algebra cache remains independent of that selection. The only
Python runtime dependencies are SymPy, mpmath, NumPy, and SciPy.

`prepare_sdp` accepts that result and returns prepared blocks, equality and
dimension summaries, fixed observables, remaining coordinates, full
`moment_reductions`, and the reconstruction data described above. It leaves the supplied moment result
unchanged. A batch request can include a `preparation` object; the batch output
then includes the same information under `result["preparation"]`. For example,
save this as `request.json` to fix `1 + <tr(X bar(X))> = 5/2`:

```json
{
  "model": {
    "species": [{"name": "X", "statistics": "boson", "charges": ["1"]}],
    "charge_names": ["R"]
  },
  "level": 3,
  "preparation": {
    "fixed_observables": [{
      "name": "n+1", "value": "5/2",
      "terms": [
        {"coefficient": "1", "word": []},
        {"coefficient": "1", "word": [1, -1]}
      ]
    }]
  }
}
```

```sh
matrix-moments --generate request.json --output prepared.json
```

For example, this row imposes an upper bound in any system containing the
specified trace word:

```json
{"name": "n", "relation": "<=", "value": "100",
 "terms": [{"coefficient": "1", "word": [1, -1]}]}
```

Use `"preparation": {"fixed_observables": []}` to prepare without observable constraints;
omit `preparation` to export only the moment-construction result.

## Source and tests

Publishable package code is entirely in `src/public_solver/`:

| Module | Responsibility |
| --- | --- |
| `model.py` | Immutable letters, statistics, charges and adjoints |
| `polynomial.py` | Exact sparse graded trace products |
| `canonical.py` | Leading large-N cyclic contacts and canonicalization |
| `brackets.py` | Indexed trace brackets with planar contact terms |
| `constraints.py` | Gauge insertions, generator validation, Ward equations and exact reduction |
| `affine.py` | Exact affine equality elimination and certified common-kernel compression |
| `block_reduction.py` | Certified removal of permutation-equivalent PSD blocks |
| `preparation.py` | Fixed-observable factorization, covariance relaxation and SDP coordinate reduction |
| `cache.py` | Versioned persistent canonical identities |
| `build_cache.py` | Bounded persistent JSON cache for completed build stages |
| `affine_data.py`, `artifact.py` | Native exact coefficient rows and a single self-contained artifact codec |
| `display.py` | Cached exact expression text and bounded browser previews |
| `pipeline.py` | Shared request validation and cached build workflow |
| `setups.py` | Persistent named input configurations |
| `sdpa.py`, `solver_settings.py` | Native installation checks and numerical controls |
| `solver_engine.py` | Affine SDPA export and multiprecision result validation |
| `objective_values.py` | Physical objective components evaluated at the returned solution |
| `constraint_reduction.py` | Generic staged exact elimination and model-only reduction checkpoints |
| `solve_runs.py`, `solve_worker.py` | Persistent solve history, execution and cancellation |
| `moments.py` | Basis, neutral-factor selection, real Hermitian coordinates and blocks |
| `worker.py`, `server.py`, `cli.py` | Local jobs, HTTP interface and command line |
| `static/` | Offline browser interface |
| `static/notation.js` | LaTeX display names and mathematical typesetting |
| `static/constraints.js` | Generator term editor and equation display |
| `static/setups.js` | Named setup saving, selection and loading |
| `static/preparation.js` | Fixed-observable editor and prepared PSD displays |
| `static/solver.js` | SDPA controls, live output, results and historical runs |

The maintainer's test suite and research comparisons are kept outside this
public folder, in `Public Solver Internal`; its README gives the test commands.
They are not dependencies of the application.

To build an installable wheel:

```sh
python -m pip wheel --no-deps . --wheel-dir dist
```

KaTeX and its fonts are distributed locally under the MIT license. See
[third-party notices](THIRD_PARTY_NOTICES.md); the renderer's license is also
included in the installed package.
