"""Contact-aware canonical traces at leading large N.

Rotate the last matrix entry to the front using the oscillator algebra.
The mother term is a graded cyclic rotation. Contracting positions k and n-1
splits the color cycle into word[:k] and word[k+1:-1]. Each normalized daughter
product has exactly the same N order as the input trace: removal of two
letters compensates the extra color loop. No color indices need be materialized.

Products of normalized traces supercommute at this order. Their inter-trace
contact terms are down by N^-2; this module is not a finite-N algebra engine.
"""

from fractions import Fraction
from typing import Callable

from .cache import CanonicalCache
from .model import Model, Word, adjoint_word
from .polynomial import Polynomial, TraceProduct, add, multiply


class Canonicalizer:
    def __init__(self, model: Model, cache: CanonicalCache | None = None,
                 check_cancelled: Callable[[], None] | None = None):
        self.model = model
        self.cache = cache
        self.check_cancelled = check_cancelled or (lambda: None)
        self._memo: dict[Word, Polynomial] = {(): {(): Fraction(1)}}
        self.computed = 0
        self.memory_hits = 0

    def word(self, word: Word) -> Polynomial:
        word = self.model.validate_word(word)
        self.check_cancelled()
        if word in self._memo:
            self.memory_hits += 1
            return dict(self._memo[word])
        if self.cache is not None:
            cached = self.cache.get(word)
            if cached is not None:
                self._memo[word] = cached
                return dict(cached)
        result = self._canonicalize(word)
        self._memo[word] = result
        self.computed += 1
        if self.cache is not None:
            self.cache.put(word, result)
        return dict(result)

    def product(self, factors: TraceProduct) -> Polynomial:
        result: Polynomial = {(): Fraction(1)}
        for word in factors:
            result = multiply(self.model, result, self.word(word))
            if not result:
                break
        return result

    def adjoint(self, factors: TraceProduct) -> Polynomial:
        return self.product(tuple(adjoint_word(w) for w in reversed(factors)))

    def _rotation(self, word: Word) -> tuple[Word, int, Polynomial]:
        last = word[-1]
        odd_last = self.model.parity((last,))
        crossed_sign = 1
        contacts: Polynomial = {}
        for k in range(len(word) - 2, -1, -1):
            current = word[k]
            if current == -last:
                # [annihilator, creator]=+delta; {fermion, adjoint}=+delta.
                contact_sign = 1 if odd_last or current < 0 else -1
                daughters = self.product((word[:k], word[k + 1:-1]))
                add(contacts, daughters, Fraction(crossed_sign * contact_sign))
            if odd_last and self.model.parity((current,)):
                crossed_sign = -crossed_sign
        return (last,) + word[:-1], crossed_sign, contacts

    def _canonicalize(self, word: Word) -> Polynomial:
        rotations = tuple(word[i:] + word[:i] for i in range(len(word)))
        representative = min(rotations, key=self.model.word_key)
        if word != representative:
            current = word
            sign = 1
            result: Polynomial = {}
            while current != representative:
                current, mother_sign, contacts = self._rotation(current)
                add(result, contacts, Fraction(sign))
                sign *= mother_sign
            add(result, self.word(representative), Fraction(sign))
            return result

        # A periodic trace can equal minus itself. Keep any lower-degree
        # contact contribution instead of naively declaring every such word zero.
        period = next(i for i in range(1, len(word) + 1)
                      if word[i:] + word[:i] == word)
        moved = word[-period:]
        stationary = word[:-period]
        stabilizer_sign = -1 if self.model.parity(moved) * self.model.parity(stationary) else 1
        if stabilizer_sign == 1:
            return {(word,): Fraction(1)}
        current = word
        sign = 1
        contacts_sum: Polynomial = {}
        for _ in range(period):
            current, mother_sign, contacts = self._rotation(current)
            add(contacts_sum, contacts, Fraction(sign))
            sign *= mother_sign
        return {key: value / 2 for key, value in contacts_sum.items()}
