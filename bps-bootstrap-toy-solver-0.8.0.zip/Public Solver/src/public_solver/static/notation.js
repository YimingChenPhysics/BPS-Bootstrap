"use strict";

// One local renderer for input previews, matrix entries and moment labels.
const SolverNotation = (() => {
  const options = Object.freeze({
    throwOnError: true,
    trust: false,
    strict: "error",
    maxExpand: 100,
    maxSize: 6,
    minRuleThickness: 0.06,
    output: "htmlAndMathml",
  });

  function validateName(raw) {
    const name = String(raw).trim();
    if (!name || [...name].length > 128 || /[<>$\x00-\x1f]/.test(name) || !/\p{L}/u.test(name)) {
      throw new Error("Use a LaTeX letter name, such as X or \\psi_{1}, without $ delimiters (up to 128 characters).");
    }
    try { katex.renderToString(name, { ...options, macros: {} }); }
    catch (_) { throw new Error(`Invalid LaTeX name: ${name}. Check commands and braces.`); }
    return name;
  }

  function render(latex, label = latex) {
    const node = document.createElement("span");
    node.className = "typeset";
    node.setAttribute("aria-label", String(label));
    try {
      // Only KaTeX-generated markup is inserted. Trust is disabled, so names
      // cannot create links, external resources or arbitrary HTML.
      const formula = String(latex);
      // A complete equation expands many more macros than one letter name.
      // Scale with its length while still stopping recursive macro definitions.
      node.innerHTML = katex.renderToString(formula, {
        ...options, maxExpand: Math.max(1000, 4 * formula.length), macros: {},
      });
    } catch (_) {
      node.textContent = "?";
      node.classList.add("invalid-latex");
      node.title = "Invalid LaTeX";
    }
    return node;
  }

  function operator(name, annihilator = false) {
    return annihilator ? `\\overline{${name}}` : `{${name}}`;
  }

  function word(tokens, species) {
    if (!tokens?.length) return "1";
    return tokens.map(token => operator(species[Math.abs(token) - 1].name, token < 0)).join("\\,");
  }

  function moment(traces, species) {
    return `\\left\\langle ${traces.map(tokens => `\\operatorname{tr}\\!\\left(${word(tokens, species)}\\right)`).join("\\,")} \\right\\rangle`;
  }

  function variable(name) {
    return String(name).replace(/^([A-Za-z]+)(\d+)$/, "$1_{$2}");
  }

  function chargeName(name) {
    const subscripts = "₀₁₂₃₄₅₆₇₈₉";
    return String(name).replace(/_?\{?(\d+)\}?$/, (_, digits) => [...digits].map(c => subscripts[Number(c)]).join(""));
  }

  return Object.freeze({ validateName, render, operator, word, moment, variable, chargeName });
})();
