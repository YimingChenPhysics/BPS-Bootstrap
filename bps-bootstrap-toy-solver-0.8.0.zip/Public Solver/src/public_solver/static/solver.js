"use strict";

const SolverStatus = (() => {
  const fields = {
    precision: "solver-precision", epsilon: "solver-epsilon", lambda_star: "solver-lambda-star",
    beta_star: "solver-beta-star", beta_bar: "solver-beta-bar", max_iterations: "solver-max-iterations",
  };
  const fallbackDefaults = { precision: 384, epsilon: "1e-14", lambda_star: "2", beta_star: "0.1", beta_bar: "0.2", max_iterations: 500 };
  const ACTIVE = new Set(["queued", "running"]);
  const LOG_LIMIT = 100 * 1024;
  let elements = null;
  let checking = false, ready = false, building = false, starting = false, cancelling = false;
  let historyBusy = false, historyLoaded = false, settingsEdited = false;
  let preparedJobId = null, preparedCurrent = false, activeRunId = null, selectedRunId = null;
  let records = [], viewVersion = 0, offset = 0, log = "", pollTimer = null;
  const $ = id => document.getElementById(id);
  const node = (tag, className, text) => {
    const result = document.createElement(tag);
    if (className) result.className = className;
    if (text !== undefined) result.textContent = String(text);
    return result;
  };
  const modeLabel = mode => ({ feasibility: "Check feasibility", minimize: "Minimize", maximize: "Maximize" }[mode] || String(mode || "Check feasibility"));
  const timestamp = value => {
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? String(value || "Saved run") : date.toLocaleString();
  };

  async function request(url, options = {}) {
    const response = await fetch(url, { cache: "no-store", ...options,
      headers: { "Content-Type": "application/json", ...(options.headers || {}) } });
    let result;
    try { result = await response.json(); } catch (_) { throw new Error("The local app returned an unreadable response."); }
    if (!response.ok) throw new Error(typeof result?.error === "string" ? result.error : `The local app could not complete the request (${response.status}).`);
    return result;
  }

  function showError(message = "") {
    $("solver-error").textContent = message;
    $("solver-error").hidden = !message;
  }

  function updateControls() {
    if (!elements) return;
    const solving = starting || Boolean(activeRunId);
    elements.button.disabled = checking || solving;
    $("solver-settings-mode").disabled = solving || building;
    Object.values(fields).forEach(id => { $(id).disabled = solving || building; });
    $("solver-solve-button").disabled = !ready || checking || !preparedJobId || !preparedCurrent || building || solving || !historyLoaded;
    $("solver-solve-button").textContent = starting ? "Starting…" : activeRunId ? "Solving…" : "Solve";
    $("solver-cancel-button").hidden = !activeRunId;
    $("solver-cancel-button").disabled = cancelling;
    $("solver-history-refresh").disabled = historyBusy;
    $("solver-prepared-notice").textContent = building ? "Wait for the SDP build to finish."
      : !preparedJobId ? "Build an SDP above to enable solving."
      : !preparedCurrent ? "Inputs have changed. Build the SDP again before solving."
      : !historyLoaded ? "Load saved runs before starting a new solve."
      : activeRunId ? "A solve is in progress. Its inputs are saved with the run."
      : "The current prepared SDP is ready to solve.";
  }

  function setPrepared(jobId, isCurrent) {
    preparedJobId = jobId || null;
    preparedCurrent = Boolean(isCurrent);
    updateControls();
  }

  function setRunning(value) { building = Boolean(value); updateControls(); }

  function useDefaults(defaults) {
    if (settingsEdited) return;
    for (const [key, id] of Object.entries(fields)) $(id).value = String(defaults?.[key] ?? fallbackDefaults[key]);
  }

  function capture() {
    const mode = $("solver-settings-mode").value;
    if (mode === "default") return { mode, settings: null };
    if (mode !== "custom") throw new Error("Choose Default or Custom SDPA settings.");
    const settings = Object.fromEntries(Object.entries(fields).map(([key, id]) => [key, $(id).value.trim()]));
    for (const [key, lower, upper, label] of [["precision", 32, 4096, "Arithmetic precision"], ["max_iterations", 1, 100000, "Maximum iterations"]]) {
      const value = Number(settings[key]);
      if (!settings[key] || !Number.isSafeInteger(value) || value < lower || value > upper) throw new Error(`${label} must be an integer from ${lower} to ${upper}.`);
      settings[key] = value;
    }
    const numeric = {};
    for (const key of ["epsilon", "lambda_star", "beta_star", "beta_bar"]) {
      const value = settings[key];
      numeric[key] = Number(value);
      if (value.length > 128 || !/^[+\-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+\-]?\d+)?$/.test(value) || !Number.isFinite(numeric[key]) || numeric[key] <= 0) {
        throw new Error("Tolerance, initial scale, and centering weights must be positive finite numbers (decimal or scientific notation).");
      }
    }
    if (numeric.beta_star > numeric.beta_bar || numeric.beta_bar >= 1) throw new Error("Centering weights must satisfy 0 < β* ≤ β̄ < 1.");
    return { mode, settings };
  }

  async function check() {
    if (!elements || checking || starting || activeRunId) return;
    checking = true; ready = false;
    elements.panel.setAttribute("aria-busy", "true");
    elements.panel.dataset.status = "checking";
    elements.message.textContent = "Checking SDPA…";
    elements.instruction.textContent = "";
    elements.instruction.hidden = true;
    updateControls();
    try {
      const result = await request("/api/solver/status", { method: "GET" });
      if (!result || !["ready", "missing", "broken"].includes(result.status) || typeof result.message !== "string" || !result.message.trim()) throw new Error("Unexpected installation status.");
      ready = result.status === "ready";
      elements.panel.dataset.status = result.status;
      elements.message.textContent = result.message;
      useDefaults(result.defaults);
      if (typeof result.instruction === "string" && result.instruction.trim()) {
        elements.instruction.textContent = result.instruction;
        elements.instruction.hidden = false;
      }
    } catch (_) {
      elements.panel.dataset.status = "error";
      elements.message.textContent = "Could not check SDPA. Check that the local app is running, then click Check again.";
    } finally {
      checking = false;
      elements.panel.setAttribute("aria-busy", "false");
      updateControls();
    }
  }

  function decimalParts(value) {
    const match = /^([+-]?)(?:(\d+)(?:\.(\d*))?|\.(\d+))(?:[eE]([+-]?\d+))?$/.exec(String(value).trim());
    if (!match) return null;
    const fraction = match[3] ?? match[4] ?? "";
    const digits = `${match[2] || ""}${fraction}`.replace(/^0+/, "") || "0";
    const exponent = Number(match[5] || "0") - fraction.length;
    if (!Number.isSafeInteger(exponent) || digits.length > 10000) return null;
    return { negative: match[1] === "-", digits, exponent };
  }

  // Round decimal strings directly, retaining precision beyond JavaScript numbers.
  function displayNumber(value, significant = 12) {
    const parts = decimalParts(value);
    if (!parts) return String(value);
    if (parts.digits === "0") return "0";
    let exponent = parts.exponent + parts.digits.length - 1;
    let digits = parts.digits.slice(0, significant);
    if (parts.digits.length > significant && parts.digits[significant] >= "5") {
      digits = String(BigInt(digits) + 1n);
      if (digits.length > significant) { exponent++; digits = digits.slice(0, significant); }
    }
    digits = digits.replace(/0+$/, "");
    const sign = parts.negative ? "-" : "";
    if (exponent < -4 || exponent >= significant) {
      return `${sign}${digits[0]}${digits.length > 1 ? `.${digits.slice(1)}` : ""}e${exponent >= 0 ? "+" : ""}${exponent}`;
    }
    const point = exponent + 1;
    if (point <= 0) return `${sign}0.${"0".repeat(-point)}${digits}`;
    if (point >= digits.length) return `${sign}${digits}${"0".repeat(point - digits.length)}`;
    return `${sign}${digits.slice(0, point)}.${digits.slice(point)}`;
  }

  function intervalWidth(lower, upper) {
    const left = decimalParts(lower), right = decimalParts(upper);
    if (!left || !right) return null;
    const exponent = Math.min(left.exponent, right.exponent);
    if (Math.max(left.exponent, right.exponent) - exponent > 10000) return null;
    const integer = part => BigInt(part.digits) * (part.negative ? -1n : 1n) * 10n ** BigInt(part.exponent - exponent);
    return `${integer(right) - integer(left)}e${exponent}`;
  }

  function elapsedDisplay(value) {
    const seconds = Number(value);
    if (!Number.isFinite(seconds) || seconds < 0) return `${displayNumber(value)} s`;
    const rounded = seconds > 0 && seconds < 0.01 ? seconds.toPrecision(2) : seconds.toFixed(2);
    return `${rounded.includes("e") ? rounded : rounded.replace(/(\.\d*?)0+$/, "$1").replace(/\.$/, "")} s`;
  }

  function metric(list, label, value, exact = null) {
    if (value === null || value === undefined || value === "") return;
    const pair = node("div"), displayed = node("dd", "", value);
    if (exact != null) displayed.title = String(exact);
    pair.append(node("dt", "", label), displayed); list.append(pair);
  }

  function resultContent(record) {
    const content = node("div");
    if (record.result) {
      const result = record.result;
      const status = { feasible: "Feasible", infeasible: "Infeasible", optimal: "Optimal", unresolved: "Unresolved", unbounded: "Unbounded" }[result.status] || "Unresolved";
      content.append(node("h3", "solver-result-heading", status));
      content.append(node("p", "", result.message || String(result.status || "Run completed.")));
      const metrics = node("dl", "solver-metrics");
      const mode = result.mode || record.summary?.mode;
      const feasibility = mode === "feasibility";
      const lower = feasibility ? result.margin_lower : result.objective_lower;
      const upper = feasibility ? result.margin_upper : result.objective_upper;
      if (lower != null && upper != null) {
        const shownLower = displayNumber(lower), shownUpper = displayNumber(upper);
        const same = shownLower === shownUpper;
        metric(metrics, feasibility ? "Feasibility margin interval" : "Objective interval",
          same ? `≈ ${shownLower}` : `≈ [${shownLower}, ${shownUpper}]`, `[${lower}, ${upper}]`);
        if (same) {
          const width = intervalWidth(lower, upper);
          metric(metrics, "Interval width", width == null ? "See exact endpoints" : displayNumber(width), width);
        }
      }
      const value = feasibility ? result.margin_value : result.objective_value;
      if (value != null) metric(metrics, feasibility ? "Feasibility margin" : "Objective value", displayNumber(value), value);
      metric(metrics, "Iterations", result.iterations);
      if (result.elapsed_seconds != null) metric(metrics, "Elapsed time", elapsedDisplay(result.elapsed_seconds), `${result.elapsed_seconds} s`);
      content.append(metrics);
      if (["minimize", "maximize"].includes(mode) && ["optimal", "feasible"].includes(result.status)
          && result.objective_value != null && result.objective_components?.length > 1) {
        content.append(componentValues(result.objective_components, record.summary?.letters || [], result.status));
      }
    } else if (record.error || record.status === "failed" || record.status === "cancelled") {
      content.append(node("h3", "solver-result-heading", record.status === "cancelled" ? "Cancelled" : "Failed"));
      content.append(node("p", "", record.error || (record.status === "cancelled" ? "Solve cancelled." : "Solve failed.")));
    }
    return content;
  }

  function renderSelected(record) {
    $("solver-run").hidden = false;
    $("solver-run-title").textContent = `Run · ${timestamp(record.created_at)}`;
    const status = { queued: "Queued", running: "Solve in progress…", complete: "Run completed", failed: "Run failed", cancelled: "Run cancelled" }[record.status] || String(record.status || "Loading run…");
    const phase = ACTIVE.has(record.status) && typeof record.progress?.message === "string" ? record.progress.message : status;
    $("solver-run-status").textContent = `${modeLabel(record.summary?.mode)} · ${phase}`;
    const download = $("solver-run-download");
    download.href = `/api/solves/${encodeURIComponent(record.run_id)}/download`;
    download.hidden = false;
    $("solver-result").hidden = !record.result && !["failed", "cancelled"].includes(record.status);
    $("solver-result").replaceChildren(resultContent(record));
  }

  function math(latex, fallback = latex) {
    return typeof SolverNotation === "undefined" ? node("span", "", fallback) : SolverNotation.render(latex, fallback);
  }

  function componentValues(components, letters, status) {
    const section = node("div", "solver-components");
    const description = status === "feasible"
      ? "At the returned feasible point; optimality remains unresolved." : "At the returned solution.";
    section.append(node("h4", "", "Value of components"), node("p", "helper", description));
    const weighted = components.some(component => component.coefficient !== "1");
    const table = node("table", "solver-components-table"), head = node("thead"), headings = node("tr");
    for (const label of ["Component", "Value", ...(weighted ? ["Coefficient", "Contribution"] : [])]) {
      const th = node("th", "", label); th.setAttribute("scope", "col"); headings.append(th);
    }
    head.append(headings); table.append(head);
    const body = node("tbody"), species = letters.map(name => ({ name }));
    for (const component of components) {
      const row = node("tr"), label = node("th"); label.setAttribute("scope", "row");
      const latex = !component.word?.length ? "1" : typeof SolverNotation === "undefined" ? null
        : SolverNotation.moment([component.word], species);
      label.append(latex == null ? document.createTextNode(component.label) : math(latex, component.label));
      row.append(label);
      const missing = component.status === "undetermined" ? "Not determined individually" : "Unavailable";
      const cell = value => {
        const td = node("td", "", value == null ? missing : displayNumber(value));
        if (value != null) td.title = String(value);
        return td;
      };
      row.append(cell(component.value));
      if (weighted) {
        const coefficient = node("td"); coefficient.append(math(component.coefficient_latex, component.coefficient));
        row.append(coefficient, cell(component.contribution));
      }
      body.append(row);
    }
    table.append(body);
    const scroll = node("div", "solver-components-scroll"); scroll.append(table); section.append(scroll);
    return section;
  }

  function numberLatex(value) {
    const text = String(value ?? "0");
    if (!/^[\d\s.+\-*/^(),a-zA-Z]+$/.test(text)) return "\\text{expression}";
    return text.replace(/sqrt\(([^()]*)\)/g, "\\sqrt{$1}").replace(/\*\*/g, "^").replace(/\*/g, "\\cdot ");
  }

  function observableLine(observable, index, letters) {
    const row = node("p", "solver-history-observable");
    const relation = { "<=": "\\le", ">=": "\\ge" }[observable.relation] || "=";
    if (typeof SolverNotation !== "undefined" && Array.isArray(observable.terms)) {
      const species = letters.map(name => ({ name }));
      const definition = observable.terms.map(term => {
        let word = "1";
        try { if (term.word?.length) word = SolverNotation.moment([term.word], species); } catch (_) { word = "?"; }
        return term.coefficient === "1" ? word : `\\left(${numberLatex(term.coefficient)}\\right)${word}`;
      }).join(" + ");
      row.append(math(`${observable.name || `O_{${index + 1}}`} = ${definition} ${relation} ${numberLatex(observable.value)}`));
    } else row.textContent = `${observable.name || `Observable ${index + 1}`} ${{ "<=": "≤", ">=": "≥" }[observable.relation] || "="} ${observable.value}`;
    return row;
  }

  function renderHistory() {
    $("solver-history-notice").textContent = records.length ? `${records.length} saved ${records.length === 1 ? "run" : "runs"}` : "No saved runs yet.";
    const list = records.map(record => {
      const entry = node("article", "solver-history-record");
      entry.append(node("h3", "", `${timestamp(record.created_at)} · ${record.status}`));
      const summary = record.summary || {};
      const metrics = node("dl", "solver-metrics");
      metric(metrics, "Truncation level", summary.level);
      metric(metrics, "Task", modeLabel(summary.mode));
      metric(metrics, "SDPA settings", record.settings_mode === "custom" ? "Custom" : "Default");
      const settings = record.settings || {};
      metric(metrics, "Precision", settings.precision == null ? null : `${settings.precision} bits`);
      metric(metrics, "Tolerance ε", settings.epsilon);
      metric(metrics, "Initial scale λ*", settings.lambda_star);
      metric(metrics, "Centering β* / β̄", settings.beta_star == null ? null : `${settings.beta_star} / ${settings.beta_bar}`);
      metric(metrics, "Maximum iterations", settings.max_iterations);
      entry.append(metrics);
      if (summary.letters?.length) {
        const letters = node("p", ""); letters.append(document.createTextNode("Letters: "));
        summary.letters.forEach((name, index) => { if (index) letters.append(document.createTextNode(", ")); letters.append(math(name)); });
        entry.append(letters);
      }
      if (summary.objective) {
        const objective = node("p", ""); objective.append(document.createTextNode(`${modeLabel(summary.mode)}: `), math(summary.objective.latex || summary.objective.expression || "0")); entry.append(objective);
      }
      (summary.fixed_observables || []).forEach((observable, index) => entry.append(observableLine(observable, index, summary.letters || [])));
      if (summary.bmn_observable_cutoff != null) {
        const cutoff = node("p", ""); cutoff.append(document.createTextNode("BMN observable cutoff: "), math(`\\Lambda = ${numberLatex(summary.bmn_observable_cutoff)}`)); entry.append(cutoff);
      }
      if (summary.variable_cutoff != null) {
        const cutoff = node("p", ""); cutoff.append(document.createTextNode("Legacy variable cutoff: "), math(`\\Lambda = ${numberLatex(summary.variable_cutoff)}`)); entry.append(cutoff);
      }
      entry.append(resultContent(record));
      const actions = node("div", "solver-history-actions");
      const view = node("button", "text-button", "View run"); view.type = "button";
      view.addEventListener("click", () => selectRun(record.run_id));
      const download = node("a", "text-button", "Download run"); download.href = `/api/solves/${encodeURIComponent(record.run_id)}/download`;
      actions.append(view, download); entry.append(actions);
      return entry;
    });
    $("solver-history-list").replaceChildren(...list);
  }

  async function refreshHistory(selectActive = false) {
    if (!elements || historyBusy) return;
    historyBusy = true; updateControls();
    try {
      const data = await request("/api/solves", { method: "GET" });
      if (!Array.isArray(data.runs) || !(data.active_run_id == null || typeof data.active_run_id === "string")) throw new Error("Unexpected history response.");
      records = data.runs;
      activeRunId = data.active_run_id || null;
      historyLoaded = true;
      renderHistory();
      if (selectActive && activeRunId && selectedRunId !== activeRunId) await selectRun(activeRunId);
    } catch (_) {
      historyLoaded = false;
      $("solver-history-notice").textContent = "Could not load saved runs. Check the local app, then click Refresh.";
    } finally { historyBusy = false; updateControls(); }
  }

  function upsertRecord(record) {
    const index = records.findIndex(item => item.run_id === record.run_id);
    const previous = records[index];
    if (index < 0) records.unshift(record); else records[index] = record;
    if (!previous || previous.status !== record.status || !ACTIVE.has(record.status)) renderHistory();
  }

  function schedulePoll(version, delay = 700) {
    if (pollTimer !== null) window.clearTimeout(pollTimer);
    pollTimer = window.setTimeout(() => pollSelected(version), delay);
  }

  async function pollSelected(version) {
    if (version !== viewVersion || !selectedRunId) return;
    const runId = selectedRunId;
    try {
      const data = await request(`/api/solves/${encodeURIComponent(runId)}?offset=${offset}`, { method: "GET" });
      if (version !== viewVersion) return;
      if (data.run_id !== runId || typeof data.log !== "string" || !Number.isSafeInteger(data.next_offset) || data.next_offset < offset) throw new Error("Unexpected solve progress response.");
      const previousOffset = offset;
      offset = data.next_offset;
      const output = $("solver-console");
      const nearBottom = output.scrollHeight - output.scrollTop - output.clientHeight < 40;
      log = (log + data.log).slice(-LOG_LIMIT);
      output.textContent = log || (typeof data.progress?.message === "string" ? data.progress.message : "Waiting for solve progress…");
      if (nearBottom || previousOffset === 0) output.scrollTop = output.scrollHeight;
      const { log: _log, next_offset: _offset, ...record } = data;
      if (ACTIVE.has(record.status)) activeRunId = runId;
      else if (activeRunId === runId) { activeRunId = null; cancelling = false; }
      upsertRecord(record); renderSelected(record); updateControls();
      const moreLog = data.log.length > 0 && offset - previousOffset >= 64 * 1024;
      if (activeRunId && activeRunId !== runId) await refreshHistory();
      if (version !== viewVersion) return;
      if (ACTIVE.has(record.status) || activeRunId || moreLog) schedulePoll(version, moreLog ? 0 : 700);
    } catch (_) {
      if (version !== viewVersion) return;
      $("solver-run-status").textContent = "Could not read solve progress. Check that the local app is running; retrying shortly…";
      schedulePoll(version, 2500);
    }
  }

  async function selectRun(runId) {
    if (!elements || typeof runId !== "string" || !runId) return;
    if (pollTimer !== null) window.clearTimeout(pollTimer);
    pollTimer = null;
    const version = ++viewVersion;
    selectedRunId = runId; offset = 0; log = "";
    $("solver-console").textContent = "Loading native SDPA output…";
    $("solver-run").hidden = false;
    $("solver-result").hidden = true;
    const record = records.find(item => item.run_id === runId);
    if (record) renderSelected(record);
    await pollSelected(version);
  }

  async function solve() {
    if (!elements || $("solver-solve-button").disabled) return;
    let settings;
    try { settings = capture(); } catch (error) { showError(error.message); return; }
    const jobId = preparedJobId;
    starting = true; showError(); updateControls();
    try {
      const data = await request("/api/solve", { method: "POST", body: JSON.stringify({ job_id: jobId, settings: settings.settings, settings_mode: settings.mode }) });
      if (typeof data.run_id !== "string" || !data.run_id) throw new Error("The local app did not return a run identifier.");
      activeRunId = data.run_id;
      await selectRun(data.run_id);
    } catch (error) {
      showError(`Could not start the solve: ${error.message}`);
      await refreshHistory(true);
    } finally { starting = false; updateControls(); }
  }

  async function cancel() {
    if (!activeRunId || cancelling) return;
    const runId = activeRunId;
    cancelling = true; showError(); updateControls();
    try {
      await request(`/api/solves/${encodeURIComponent(runId)}/cancel`, { method: "POST", body: "{}" });
      $("solver-run-status").textContent = "Cancellation requested. Waiting for the solve to stop…";
    } catch (error) { cancelling = false; showError(`Could not cancel the solve: ${error.message}`); updateControls(); }
  }

  function init() {
    if (window.location?.protocol === "file:" || elements) return;
    const panel = $("solver-panel"), message = $("solver-status-message"), instruction = $("solver-status-instruction"), button = $("solver-check-button");
    if (!panel || !message || !instruction || !button) return;
    elements = { panel, message, instruction, button };
    button.addEventListener("click", check);
    $("solver-settings-mode").addEventListener("change", () => { $("solver-custom-settings").hidden = $("solver-settings-mode").value !== "custom"; showError(); });
    Object.values(fields).forEach(id => $(id).addEventListener("input", () => { settingsEdited = true; showError(); }));
    $("solver-solve-button").addEventListener("click", solve);
    $("solver-cancel-button").addEventListener("click", cancel);
    $("solver-history-refresh").addEventListener("click", () => refreshHistory(true));
    useDefaults(); updateControls();
    check(); refreshHistory(true);
  }

  if (window.location?.protocol !== "file:") {
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init, { once: true });
    else init();
  }
  return { init, check, setPrepared, setRunning, capture, refreshHistory };
})();
