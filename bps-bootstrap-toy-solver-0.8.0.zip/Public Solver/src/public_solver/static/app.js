"use strict";

(() => {
  const $ = (id) => document.getElementById(id);
  if (window.location?.protocol === "file:") {
    document.querySelector(".workspace").hidden = true;
    $("file-launcher").hidden = false;
    return;
  }
  const state = {
    species: [{ name: "X", statistics: "boson", charges: ["1"] }],
    chargeNames: ["Q1"],
    jobId: null,
    result: null,
    resultJobId: null,
    resultConfig: null,
    jobConfig: null,
    loopPage: 0,
    loopFilter: null,
    loopRendered: null,
    running: false,
    setupBusy: false,
    limits: null,
    pollTimer: null,
    bmnSetup: null,
  };
  const LOOP_PAGE_SIZE = 100;
  const cooking = typeof SolverCooking !== "undefined" ? SolverCooking.create() : null;
  function element(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = String(text);
    return node;
  }

  function expressionNode(latex, fallback) {
    return SolverNotation.render(latex ?? SolverNotation.variable(fallback ?? "0"), fallback);
  }

  function formatNumber(value) {
    return Number(value || 0).toLocaleString();
  }

  function showError(message) {
    $("form-error").textContent = message || "";
    $("form-error").hidden = !message;
  }

  function exactCharge(raw) {
    const value = String(raw).trim();
    if (value.length > 2048) throw new Error("Charge values must be at most 2048 characters.");
    let a;
    let b;
    if (/^[+-]?\d+(?:\s*\/\s*[+-]?\d+)?$/.test(value)) {
      const [numerator, denominator = "1"] = value.split("/");
      a = BigInt(numerator.trim()); b = BigInt(denominator.trim());
    } else {
      const match = /^([+-]?)(?:(\d+)(?:\.(\d*))?|\.(\d+))(?:[eE]([+-]?\d+))?$/.exec(value);
      if (!match) throw new Error(`“${value || "(empty)"}” is not an exact charge. Use an integer, fraction, or decimal, such as 1/2 or 0.5.`);
      const exponent = Number(match[5] || "0");
      if (!Number.isSafeInteger(exponent) || Math.abs(exponent) > 100) throw new Error("Charge exponents must lie between -100 and 100.");
      const fraction = match[3] ?? match[4] ?? "";
      a = BigInt(`${match[2] || "0"}${fraction}`) * (match[1] === "-" ? -1n : 1n);
      const scale = fraction.length - exponent;
      b = scale > 0 ? 10n ** BigInt(scale) : 1n;
      if (scale < 0) a *= 10n ** BigInt(-scale);
    }
    if (b === 0n) throw new Error("A charge denominator cannot be zero.");
    if (b < 0n) { a = -a; b = -b; }
    let x = a < 0n ? -a : a;
    let y = b;
    while (y) { const remainder = x % y; x = y; y = remainder; }
    a /= x; b /= x;
    if ((a < 0n ? -a : a).toString(2).length > 1024 || b.toString(2).length > 1024) {
      throw new Error("Charge numerators and denominators must fit within 1024 bits.");
    }
    return b === 1n ? String(a) : `${a}/${b}`;
  }

  function captureConfig() {
    const level = Number($("level").value);
    if ($("level").value.trim() === "" || !Number.isSafeInteger(level) || level < 0 || level > 12) {
      throw new Error("Choose an integer from 0 to 12 for the truncation level.");
    }
    const chargeCount = Number($("charge-count").value);
    if (!Number.isInteger(chargeCount) || chargeCount < 0 || chargeCount > 8 || String($("charge-count").value).trim() === "") {
      throw new Error("Choose between 0 and 8 charges.");
    }
    if (!state.species.length) throw new Error("Add at least one letter before generating a matrix.");
    if (state.species.length > 24) throw new Error("This interface supports at most 24 letters.");
    const usedNames = new Set();
    const species = state.species.map((item, i) => {
      const name = SolverNotation.validateName(item.name);
      if (usedNames.has(name)) throw new Error(`The name “${name}” is used more than once. Each letter needs a unique name.`);
      usedNames.add(name);
      return { name, statistics: item.statistics, charges: item.charges.slice(0, chargeCount).map(exactCharge) };
    });
    const chargeNames = state.chargeNames.slice(0, chargeCount).map((name, i) => name.trim() || `Q${i + 1}`);
    if (new Set(chargeNames).size !== chargeNames.length) throw new Error("Each charge needs a unique name.");
    return { model: { species, charge_names: chargeNames }, level, charge_neutral: true,
      constraints: constraintsEditor.capture(), preparation: preparationEditor.capture() };
  }

  // Compare the actual preset definition, not the selected setup's name.
  // Names and ordering of terms are presentation; order within a word matters.
  function isBmnSetup() {
    const preset = state.bmnSetup;
    if (!preset || Number($("level").value) !== preset.level ||
        Number($("charge-count").value) !== preset.model.charge_names.length ||
        state.species.length !== preset.model.species.length) return false;
    try {
      const speciesKey = item => JSON.stringify([item.statistics, item.charges.map(exactCharge)]);
      const canonicalSpecies = preset.model.species.map(speciesKey);
      const mapping = state.species.map(item => canonicalSpecies.indexOf(speciesKey(item)) + 1);
      if (mapping.includes(0) || new Set(mapping).size !== mapping.length) return false;
      const coefficientKey = value => {
        try { return exactCharge(value); }
        catch (_) { return value.replace(/\s+/g, ""); }
      };
      const constraintsKey = (config, ids) => JSON.stringify({
        gauge_singlet: config.gauge_singlet,
        ...Object.fromEntries(["supercharges", "symmetries"].map(family => [family,
          config[family].map(generator => JSON.stringify([
            generator.kind ?? "ward",
            generator.terms.map(term => JSON.stringify([
              coefficientKey(term.coefficient),
              term.word.map(token => Math.sign(token) * ids[Math.abs(token) - 1]),
            ])).sort(),
          ])).sort(),
        ])),
      });
      return constraintsKey(constraintsEditor.capture(), mapping) ===
        constraintsKey(preset.constraints, canonicalSpecies.map((_, i) => i + 1));
    } catch (_) { return false; } // Incomplete edits cannot enable BMN options.
  }

  function modelChanged() {
    showError("");
    constraintsEditor.refreshModel();
    preparationEditor.refreshModel();
    updateEstimate();
    if (state.result) {
      let same = false;
      try { same = JSON.stringify(captureConfig()) === state.resultConfig; } catch (_) { /* An incomplete model is changed. */ }
      $("preparation-stale-notice").hidden = same;
      if (typeof SolverStatus !== "undefined") SolverStatus.setPrepared(state.resultJobId, same);
    }
  }

  function renderLetters() {
    const header = element("tr");
    const naming = element("th", "", "Naming");
    naming.append(element("span", "naming-help", "(LaTeX input, such as \\phi_1, or \\psi_1)"));
    header.append(naming);
    ["Creation operator", "Annihilation operator", "Statistics"].forEach((label) => header.append(element("th", "", label)));
    state.chargeNames.forEach((name, i) => {
      const th = element("th");
      const input = element("input", "charge-heading");
      input.type = "text";
      input.maxLength = 24;
      input.value = name;
      input.setAttribute("aria-label", `Name of charge ${i + 1}`);
      input.title = `Name of charge ${i + 1}`;
      input.addEventListener("input", () => { state.chargeNames[i] = input.value; modelChanged(); });
      th.append(input); header.append(th);
    });
    const removeHeader = element("th");
    removeHeader.append(element("span", "sr-only", "Remove letter"));
    header.append(removeHeader);
    $("letters-head").replaceChildren(header);
    const rows = state.species.map((item, i) => {
      const row = element("tr");
      const nameCell = element("td");
      const nameInput = element("input");
      nameInput.type = "text";
      nameInput.maxLength = 128;
      nameInput.value = item.name;
      nameInput.placeholder = "X, \\psi_1, \\phi^{a}";
      nameInput.autocomplete = "off";
      nameInput.spellcheck = false;
      nameInput.setAttribute("aria-label", `Naming (LaTeX) for letter ${i + 1}`);
      nameCell.append(nameInput);
      const creatorCell = element("td", "operator-cell");
      const annihilatorCell = element("td", "annihilator-cell");
      function updatePreviews() {
        let valid = true;
        try {
          SolverNotation.validateName(item.name);
          nameInput.title = "LaTeX without $ delimiters";
        } catch (error) {
          valid = false;
          nameInput.title = error.message;
        }
        nameInput.setAttribute("aria-invalid", String(!valid));
        creatorCell.replaceChildren(SolverNotation.render(valid ? SolverNotation.operator(item.name) : "?", `${item.name || "unnamed"} creation`));
        annihilatorCell.replaceChildren(SolverNotation.render(valid ? SolverNotation.operator(item.name, true) : "?", `${item.name || "unnamed"} annihilation`));
      }
      updatePreviews();
      nameInput.addEventListener("input", () => {
        item.name = nameInput.value;
        updatePreviews();
        remove.title = `Remove ${item.name || "letter"}`;
        modelChanged();
      });
      const statisticsCell = element("td");
      const select = element("select");
      select.setAttribute("aria-label", `Statistics for letter ${i + 1}`);
      [["boson", "Bosonic"], ["fermion", "Fermionic"]].forEach(([value, label]) => {
        const option = element("option", "", label); option.value = value; select.append(option);
      });
      select.value = item.statistics;
      select.addEventListener("change", () => { item.statistics = select.value; modelChanged(); });
      statisticsCell.append(select);
      row.append(nameCell, creatorCell, annihilatorCell, statisticsCell);
      state.chargeNames.forEach((_, chargeIndex) => {
        const cell = element("td");
        const input = element("input", "charge-input");
        input.type = "text";
        input.maxLength = 2048;
        input.value = item.charges[chargeIndex] ?? "0";
        input.placeholder = "0";
        input.autocomplete = "off";
        input.spellcheck = false;
        input.setAttribute("aria-label", `Charge ${chargeIndex + 1} for creator ${i + 1}`);
        input.title = "Integer, fraction, or decimal; the annihilator has the opposite charge.";
        input.addEventListener("input", () => { item.charges[chargeIndex] = input.value; modelChanged(); });
        cell.append(input); row.append(cell);
      });
      const removeCell = element("td");
      const remove = element("button", "remove-letter", "×");
      remove.type = "button";
      remove.title = `Remove ${item.name || "letter"}`;
      remove.setAttribute("aria-label", `Remove letter ${i + 1}`);
      remove.addEventListener("click", () => { state.species.splice(i, 1); renderLetters(); modelChanged(); });
      removeCell.append(remove); row.append(removeCell);
      return row;
    });
    $("letters-body").replaceChildren(...rows);
    updateScrollHint();
  }

  function updateScrollHint() {
    const table = document.querySelector(".letters-scroll");
    $("charge-scroll-hint").hidden = table.scrollWidth <= table.clientWidth + 1;
  }

  function updateEstimate() {
    const level = Number($("level").value);
    const output = $("estimate");
    output.classList.remove("limit-warning");
    if (!Number.isSafeInteger(level) || level < 0 || $("level").value.trim() === "") {
      output.textContent = "Choose a nonnegative level to estimate the size."; return;
    }
    const alphabetSize = BigInt(state.species.length * 2);
    let count = 1n;
    let power = 1n;
    let large = false;
    for (let i = 0; i < level; i++) {
      power *= alphabetSize; count += power;
      if (count > 1000000000000000000n) { large = true; break; }
      if (alphabetSize === 0n) break;
    }
    const strong = element("strong", "", large ? "More than 10¹⁸ basis words" : `${count.toLocaleString()} basis ${count === 1n ? "word" : "words"}`);
    output.replaceChildren(strong);
    if (state.limits?.max_basis_size != null && (large || count > BigInt(state.limits.max_basis_size))) {
      output.classList.add("limit-warning");
      output.append(document.createTextNode(` This exceeds this server’s ${formatNumber(state.limits.max_basis_size)}-word limit; reduce the level or number of letters.`));
    }
  }

  async function request(url, options = {}) {
    const response = await fetch(url, { ...options, headers: { "Content-Type": "application/json", ...(options.headers || {}) } });
    let data;
    try { data = await response.json(); } catch (_) { throw new Error(`The local server returned an unreadable response (${response.status}).`); }
    if (!response.ok) {
      const error = new Error(data.error || `The request failed (${response.status}).`);
      error.httpStatus = response.status;
      throw error;
    }
    return data;
  }

  function updateEditingState() {
    const disabled = state.running || state.setupBusy;
    $("model-form").querySelectorAll("input,select,button").forEach((input) => { input.disabled = disabled; });
    $("import-button").disabled = disabled;
    $("export-button").disabled = disabled;
    constraintsEditor.setDisabled(disabled);
    preparationEditor.setDisabled(disabled);
    $("build-sdp-button").disabled = disabled;
    if (typeof SolverStatus !== "undefined") SolverStatus.setRunning(disabled);
  }

  function setRunning(running) {
    state.running = running;
    if (!running) cooking?.stop();
    updateEditingState();
    setupLibrary.setDisabled(running);
    $("build-sdp-button").firstElementChild.textContent = running ? "Building…" : "Build SDP";
    $("cancel-button").hidden = !running;
    $("cancel-button").disabled = false;
  }

  function updateProgress(job) {
    const progress = job.progress || {};
    const badge = $("status-badge");
    $("status-panel").hidden = false;
    $("status-eyebrow").textContent = job.status === "queued" ? "QUEUED" : "BUILDING SDP";
    const stages = { cache: "Reusing cached work", canonicalization: "Canonicalizing moments", constraints: "Applying loop equations and symmetry constraints",
      hermiticity: "Identifying Hermitian conjugates", matrix: "Assembling the moment matrix",
      factorization: "Fixing observables and building the relaxation", null_directions: "Reducing PSD block sizes",
      scalar_coordinates: "Selecting independent SDP variables", preparation_output: "Preparing the results",
      block_reduction: "Removing equivalent PSD blocks", bmn_observable_cutoff: "Applying the BMN observable cutoff",
      bmn_su3: "Reducing BMN blocks with SU(3)",
      saving: "Saving the results" };
    const stage = stages[progress.stage] || "Preparing your model";
    $("status-title").textContent = stage.charAt(0).toUpperCase() + stage.slice(1);
    $("status-message").textContent = progress.message || "Exact canonicalization is running. Reusable results are saved in the local cache.";
    badge.textContent = job.status === "queued" ? "Queued" : "Working";
    badge.classList.remove("failed");
    const bar = $("generation-progress");
    bar.hidden = false;
    if (Number(progress.total) > 0 && Number.isFinite(Number(progress.completed))) {
      bar.max = Number(progress.total); bar.value = Math.max(0, Number(progress.completed));
    } else { bar.removeAttribute("value"); }
  }

  function finishStatus(kind, title, message) {
    $("status-panel").hidden = false;
    $("status-eyebrow").textContent = kind.toUpperCase();
    $("status-title").textContent = title;
    $("status-message").textContent = message;
    $("status-badge").textContent = kind === "failed" ? "Needs attention" : kind === "cancelled" ? "Stopped" : "Complete";
    $("status-badge").classList.toggle("failed", kind === "failed");
    $("generation-progress").hidden = true;
  }

  async function preparedResult(jobId) {
    const result = await request(`/api/jobs/${encodeURIComponent(jobId)}/result?view=prepared`);
    if (!result.preparation || result.preparation.status !== "prepared") throw new Error("The server did not return a prepared SDP.");
    return result;
  }

  function showPreparedResult(result, jobId) {
    state.result = result;
    state.loopFilter = null;
    state.loopRendered = null;
    $("loop-equations-list").replaceChildren();
    $("loop-free-parameters").replaceChildren();
    state.resultJobId = jobId;
    state.resultConfig = state.jobConfig;
    SolverPreparation.renderResult($("prepared-result-content"), result, jobId, $("loop-equations-details"));
    renderLoopEquations();
    $("prepared-results").hidden = false;
    $("loop-equations-details").hidden = false;
    $("preparation-stale-notice").hidden = true;
    if (typeof SolverStatus !== "undefined") SolverStatus.setPrepared(state.resultJobId, true);
    setRunning(false);
    $("status-panel").hidden = true;
  }

  async function restoreCompletedJob(jobId) {
    state.jobId = jobId;
    setRunning(true);
    $("cancel-button").hidden = true;
    try {
      const job = await request(`/api/jobs/${encodeURIComponent(jobId)}`);
      if (job.status !== "complete") throw new Error("This saved SDP build is not complete.");
      const result = await preparedResult(jobId);
      if (!result.setup) throw new Error("This saved SDP build does not include its setup.");
      const migrated = await loadConfig(result.setup);
      state.jobConfig = migrated ? null : JSON.stringify(captureConfig());
      showPreparedResult(result, jobId);
      if (migrated) modelChanged();
    } catch (error) {
      setRunning(false);
      finishStatus("failed", "Could not open saved SDP", error.message);
    }
  }

  async function pollJob(jobId) {
    if (jobId !== state.jobId || !state.running) return;
    try {
      const job = await request(`/api/jobs/${encodeURIComponent(jobId)}`);
      if (jobId !== state.jobId) return;
      if (job.status === "complete") {
        showPreparedResult(await preparedResult(jobId), jobId);
        return;
      }
      if (job.status === "failed" || job.status === "cancelled") {
        setRunning(false);
        finishStatus(job.status, job.status === "failed" ? "SDP build could not finish" : "SDP build cancelled", job.error || job.progress?.message || "Your model settings are ready for another run.");
        return;
      }
      updateProgress(job);
      state.pollTimer = window.setTimeout(() => pollJob(jobId), 700);
    } catch (error) {
      if (jobId !== state.jobId || !state.running) return;
      if (error instanceof TypeError) {
        $("status-message").textContent = "Connection to the local server was interrupted. Retrying in a moment…";
        state.pollTimer = window.setTimeout(() => pollJob(jobId), 2500);
      } else {
        setRunning(false);
        finishStatus("failed", "Could not read the build status", error.message);
      }
    }
  }

  async function buildSdp(event) {
    event.preventDefault();
    if (state.running || state.setupBusy) return;
    let config;
    try { config = captureConfig(); } catch (error) {
      showError(error.message);
      return;
    }
    showError("");
    state.jobId = null;
    setRunning(true);
    $("cancel-button").disabled = true;
    updateProgress({ status: "queued", progress: { stage: "Preparing your model" } });
    cooking?.start(config);
    try {
      const job = await request("/api/generate", { method: "POST", body: JSON.stringify(config) });
      if (!job.job_id) throw new Error("The local server did not return a job identifier.");
      state.jobId = job.job_id;
      state.jobConfig = JSON.stringify(config);
      $("cancel-button").disabled = false;
      await pollJob(job.job_id);
    } catch (error) {
      setRunning(false);
      finishStatus("failed", "SDP build could not start", error instanceof TypeError ? "Could not connect to the local server. Check that BPS Bootstrap: Toy Solver is still running, then try again." : error.message);
    }
  }

  async function cancelJob() {
    if (!state.jobId || !state.running) return;
    $("cancel-button").disabled = true;
    try {
      await request(`/api/jobs/${encodeURIComponent(state.jobId)}/cancel`, { method: "POST", body: "{}" });
      $("status-message").textContent = "Cancellation requested. Waiting for the current algebra step to stop…";
    } catch (error) { $("cancel-button").disabled = false; showError(`Could not cancel: ${error.message}`); }
  }

  function renderLoopEquations(resetPage = true) {
    if (resetPage) state.loopPage = 0;
    const result = state.result;
    const equations = result?.preparation?.moment_reductions || [];
    const total = Math.max(equations.length, Number(result?.preparation?.preview_counts?.moment_reductions) || 0);
    $("loop-count").textContent = `${formatNumber(total)} moments`;
    if (!$("loop-equations-details").open) return;
    const query = $("loop-search").value.toLocaleLowerCase().trim();
    if (state.loopFilter?.result !== result || state.loopFilter.query !== query) {
      state.loopFilter = { result, query, rows: query ? equations.filter(row => `${row.text} ${row.expression}`.toLocaleLowerCase().includes(query)) : equations };
    }
    const filtered = state.loopFilter.rows;
    const pages = Math.max(1, Math.ceil(filtered.length / LOOP_PAGE_SIZE));
    state.loopPage = Math.max(0, Math.min(state.loopPage, pages - 1));
    if (state.loopRendered?.result === result && state.loopRendered.query === query && state.loopRendered.page === state.loopPage) return;
    const start = state.loopPage * LOOP_PAGE_SIZE;
    const visible = filtered.slice(start, start + LOOP_PAGE_SIZE);
    $("loop-equations-list").replaceChildren(...visible.map(equation => {
      const row = element("div", "relation-row");
      row.append(SolverNotation.render(equation.traces.length ? SolverNotation.moment(equation.traces, result.model.species) : "1", equation.text),
        SolverNotation.render("="), expressionNode(equation.latex, equation.expression));
      return row;
    }));
    $("loop-page-caption").textContent = filtered.length ? `${formatNumber(start + 1)}–${formatNumber(start + visible.length)} of ${formatNumber(filtered.length)}` : "No matching moments.";
    if (total > equations.length) $("loop-page-caption").textContent += ` · Preview: first ${formatNumber(equations.length)} of ${formatNumber(total)} moments.`;
    $("loop-prev-button").disabled = state.loopPage === 0;
    $("loop-next-button").disabled = state.loopPage >= pages - 1;
    const free = result?.preparation?.loop_free_parameters || [];
    $("loop-free-parameters").hidden = !free.length;
    $("loop-free-parameters").replaceChildren();
    if (free.length) {
      $("loop-free-parameters").append(document.createTextNode("Additional free parameters "));
      free.forEach((parameter, index) => {
        if (index) $("loop-free-parameters").append(document.createTextNode(", "));
        $("loop-free-parameters").append(expressionNode(parameter.latex, parameter.name));
      });
      $("loop-free-parameters").append(document.createTextNode(" retain moment freedom that does not affect the PSD blocks."));
    }
    state.loopRendered = { result, query, page: state.loopPage };
  }

  function downloadJson(value, filename) {
    const blob = new Blob([`${JSON.stringify(value, null, 2)}\n`], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = element("a"); anchor.href = url; anchor.download = filename;
    document.body.append(anchor); anchor.click(); anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  async function loadConfig(data) {
    // Saved build recovery must see the same BMN eligibility as later edits.
    if (!await bmnReferenceReady) throw new Error("Could not load the BMN definition. Reload the page and try again.");
    if (!data || typeof data !== "object") throw new Error("The setup must contain a model.");
    const model = data.model || data;
    if (!Array.isArray(model.species) || !model.species.length) throw new Error("The JSON must contain a model with a nonempty species list.");
    if (model.species.length > 24) throw new Error("The editor supports at most 24 letter rows.");
    const names = model.charge_names;
    if (!Array.isArray(names) || names.length > 8 || names.some((name) => typeof name !== "string")) throw new Error("The model must contain charge_names: a list of 0–8 names.");
    const species = model.species.map((item) => {
      if (typeof item.name !== "string" || !["boson", "fermion"].includes(item.statistics)) throw new Error("Each species needs a name and statistics set to boson or fermion.");
      if (!Array.isArray(item.charges) || item.charges.length !== names.length) throw new Error(`“${item.name}” must have one charge value for every charge name.`);
      return { name: SolverNotation.validateName(item.name), statistics: item.statistics, charges: item.charges.map(exactCharge) };
    });
    const level = data.level ?? data.settings?.level ?? Number($("level").value);
    if (!Number.isSafeInteger(Number(level)) || Number(level) < 0 || Number(level) > 12) throw new Error("The imported level must be an integer from 0 to 12.");
    const constraints = SolverConstraints.validateConfig(data.constraints?.config ?? data.constraints, species);
    let rawPreparation = data.preparation?.config ?? data.preparation;
    const migrated = rawPreparation?.variable_cutoff != null;
    if (migrated) {
      rawPreparation = { ...rawPreparation };
      delete rawPreparation.variable_cutoff;
    }
    const preparation = SolverPreparation.validateConfig(rawPreparation, species, Number(level));
    if (new Set(species.map(item => item.name)).size !== species.length) throw new Error("Each letter needs a unique name.");
    if (names.some(name => !name.trim() || name.length > 24) || new Set(names).size !== names.length) throw new Error("Charge names must be unique, nonempty, and at most 24 characters.");
    state.species = species;
    state.chargeNames = [...names];
    $("charge-count").value = String(names.length);
    $("level").value = String(level);
    constraintsEditor.load(constraints);
    preparationEditor.load(rawPreparation);
    renderLetters(); modelChanged();
    const notice = $("cutoff-migration-notice");
    notice.textContent = migrated ? "The former general variable cutoff was removed from this setup. " +
      (preparation.bmn_observable_cutoff != null ? "The BMN observable cutoff remains enabled." : "This setup now has no cutoff; enable the BMN option if wanted.") : "";
    notice.hidden = !migrated;
    return migrated || (rawPreparation == null && isBmnSetup()) || (!isBmnSetup() &&
      (preparation.bmn_su3_reduction || preparation.bmn_observable_cutoff != null));
  }

  async function importModel(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      if (file.size > 5 * 1024 * 1024) throw new Error("Choose a model JSON file smaller than 5 MB.");
      await loadConfig(JSON.parse(await file.text()));
    } catch (error) { showError(`Could not import the model: ${error.message}`); }
    finally { $("import-file").value = ""; }
  }

  document.querySelectorAll("[data-latex]").forEach(node => {
    node.replaceChildren(SolverNotation.render(node.dataset.latex, node.getAttribute("aria-label") || node.dataset.latex));
  });

  const constraintsEditor = SolverConstraints.create({ container: $("constraints-editor"), getSpecies: () => state.species, onChange: modelChanged });
  const preparationEditor = SolverPreparation.create({ container: $("preparation-editor"), getSpecies: () => state.species, getLevel: () => Number($("level").value), isBmnSetup, onChange: modelChanged });
  const bmnReferenceReady = request("/api/setups/builtin-bmn").then(result => {
    state.bmnSetup = result.config;
    if (!state.bmnSetup?.model?.species || !state.bmnSetup.constraints) throw new Error("Missing BMN definition.");
    preparationEditor.refreshModel();
    return true;
  }).catch(() => {
    state.bmnSetup = null;
    showError("Could not load the BMN definition. Reload the page to use saved setups and BMN options.");
    return false;
  });
  const setupLibrary = SolverSetups.create({ request, captureConfig, loadConfig,
    onBusyChange(value) { state.setupBusy = value; updateEditingState(); } });

  $("model-form").addEventListener("submit", buildSdp);
  $("build-sdp-button").addEventListener("click", buildSdp);
  $("cancel-button").addEventListener("click", cancelJob);
  $("add-letter").addEventListener("click", () => {
    if (state.species.length >= 24) { showError("This interface supports at most 24 letters."); return; }
    const names = new Set(state.species.map((item) => item.name));
    let name = "Y"; let i = 1;
    while (names.has(name)) { name = `X${i++}`; }
    state.species.push({ name, statistics: "boson", charges: state.chargeNames.map(() => "0") });
    renderLetters(); modelChanged();
    $("letters-body").lastElementChild?.querySelector("input")?.focus();
  });
  $("charge-count").addEventListener("input", () => {
    const raw = $("charge-count").value;
    const count = Number(raw);
    if (raw.trim() === "" || !Number.isInteger(count) || count < 0 || count > 8) { modelChanged(); return; }
    while (state.chargeNames.length < count) state.chargeNames.push(`Q${state.chargeNames.length + 1}`);
    state.chargeNames = state.chargeNames.slice(0, count);
    state.species.forEach((item) => {
      while (item.charges.length < count) item.charges.push("0");
      item.charges = item.charges.slice(0, count);
    });
    renderLetters(); modelChanged();
  });
  $("level").addEventListener("input", modelChanged);
  $("loop-equations-details").addEventListener("toggle", () => {
    if ($("loop-equations-details").open) renderLoopEquations(false);
  });
  $("loop-search").addEventListener("input", () => renderLoopEquations());
  $("loop-prev-button").addEventListener("click", () => { state.loopPage--; renderLoopEquations(false); });
  $("loop-next-button").addEventListener("click", () => { state.loopPage++; renderLoopEquations(false); });
  $("import-button").addEventListener("click", () => $("import-file").click());
  $("import-file").addEventListener("change", importModel);
  $("export-button").addEventListener("click", () => {
    try { downloadJson(captureConfig(), "bps-bootstrap-model.json"); showError(""); } catch (error) { showError(error.message); }
  });

  renderLetters(); updateEstimate();
  setupLibrary.refresh();
  window.addEventListener("resize", updateScrollHint);
  window.addEventListener("pagehide", () => cooking?.stop());
  request("/api/info").then((info) => {
    state.limits = info.limits || null;
    if (info.version) $("app-version").textContent = `v${info.version}`;
    updateEstimate();
  }).catch(() => { /* Server information is optional; generation still works without it. */ });
  if (window.location?.search) {
    const jobId = new URLSearchParams(window.location.search).get("job");
    if (jobId && /^[a-f0-9]{32}$/.test(jobId)) restoreCompletedJob(jobId);
    else if (jobId) showError("The saved build link is invalid.");
  }
})();
