"use strict";

// The editor owns generator definitions; algebra and coefficient evaluation stay
// on the server. Word references follow species objects, never mutable names.
const SolverConstraints = (() => {
  const MAX_GENERATORS = 12;
  const MAX_TERMS = 64;
  const MAX_WORD = 8;
  const emptyConfig = () => ({ gauge_singlet: false, supercharges: [], symmetries: [] });
  const node = (tag, className, text) => {
    const result = document.createElement(tag);
    if (className) result.className = className;
    if (text !== undefined) result.textContent = String(text);
    return result;
  };
  const button = (label, className, action) => {
    const result = node("button", className, label);
    result.type = "button"; result.addEventListener("click", action); return result;
  };

  function validateConfig(raw, species) {
    if (raw === undefined || raw === null) return emptyConfig();
    if (typeof raw !== "object" || Array.isArray(raw)) throw new Error("Constraints must be an object.");
    const gauge = raw.gauge_singlet ?? false;
    if (typeof gauge !== "boolean") throw new Error("Gauge singlet must be true or false.");
    const result = { gauge_singlet: gauge, supercharges: [], symmetries: [] };
    for (const family of ["supercharges", "symmetries"]) {
      const generators = raw[family] ?? [];
      if (!Array.isArray(generators)) throw new Error(`${family} must be a list.`);
      if (generators.length > MAX_GENERATORS) throw new Error(`Use at most ${MAX_GENERATORS} generators in total.`);
      result[family] = generators.map((generator, index) => {
        if (!generator || typeof generator !== "object") throw new Error("Invalid generator definition.");
        const name = generator.name ?? (family === "supercharges" ? `Q_{${index + 1}}` : `S_{${index + 1}}`);
        if (typeof name !== "string" || name.length > 128) throw new Error("Generator names must have at most 128 characters.");
        if (name.trim()) SolverNotation.validateName(name);
        const kind = generator.kind ?? "ward";
        if (family === "supercharges" && !["ward", "matrix"].includes(kind)) throw new Error("Unknown supercharge equation type.");
        if (family === "symmetries" && kind !== "ward") throw new Error("Symmetry generators use Ward identities.");
        if (!Array.isArray(generator.terms) || !generator.terms.length || generator.terms.length > MAX_TERMS) throw new Error(`Each generator needs 1–${MAX_TERMS} terms.`);
        const terms = generator.terms.map((term) => {
          if (!term || typeof term.coefficient !== "string" || !term.coefficient.trim() || term.coefficient.length > 128) throw new Error("Each coefficient must be a nonempty expression of at most 128 characters.");
          if (!Array.isArray(term.word) || term.word.length > MAX_WORD || term.word.some(token => !Number.isInteger(token) || token === 0 || Math.abs(token) > species.length)) throw new Error(`Each word must contain up to ${MAX_WORD} valid letter tokens.`);
          return { coefficient: term.coefficient.trim(), word: [...term.word] };
        });
        return { name: name.trim(), ...(family === "supercharges" ? { kind } : {}), terms };
      });
    }
    if (new Set(result.supercharges.map(generator => generator.kind)).size > 1) throw new Error("Choose one shared mode: all entries must be supercharges or all must be matrix relations.");
    if (result.supercharges.length + result.symmetries.length > MAX_GENERATORS) throw new Error(`Use at most ${MAX_GENERATORS} generators in total.`);
    return result;
  }

  // Presentation only: no arithmetic is evaluated here. Restrict the preview
  // alphabet; the backend remains responsible for exact coefficient validation.
  function coefficientLatex(value) {
    const text = String(value).trim();
    if (!/^[\d\s.+\-*/^(),a-zA-Z]+$/.test(text)) return "\\text{coefficient}";
    return text.replace(/sqrt\(([^()]*)\)/g, "\\sqrt{$1}")
      .replace(/\b[Ii]\b/g, "\\mathrm{i}").replace(/\*\*/g, "^").replace(/\*/g, "\\cdot ");
  }

  function create({ container, getSpecies, onChange }) {
    let mode = "ward";
    const blankSupercharge = (index = 1) => {
      const prefix = mode === "matrix" ? "F" : "Q";
      while (config.supercharges.some(generator => generator.name === `${prefix}_{${index}}`)) index++;
      return { name: `${prefix}_{${index}}`, kind: mode, draft: true, terms: [{ coefficient: "1", refs: [] }] };
    };
    const isBlankSupercharge = generator => generator.draft && generator.terms.length === 1 &&
      !generator.terms[0].refs.length && ["", "1"].includes(generator.terms[0].coefficient.trim());
    let config = emptyConfig();
    config.supercharges = [blankSupercharge()];
    let selectedTerm = config.supercharges[0].terms[0];
    let disabled = false;
    let previousSpecies = [];
    let previousLabels = "";
    const previewNodes = new Map();
    const groupLabels = { supercharges: "Supercharge", symmetries: "Additional symmetry constraints" };
    const entryLabel = (family, index) => family === "supercharges" ? `${mode === "matrix" ? "Matrix relation" : "Supercharge"} ${index + 1}` : `Symmetry ${index + 1}`;

    function refsFromWord(word, species) {
      return word.map(token => ({ species: species[Math.abs(token) - 1], annihilator: token < 0 }));
    }

    function wordFromRefs(refs, validate = true) {
      return refs.map(ref => {
        const index = getSpecies().indexOf(ref.species);
        if (index < 0) {
          if (validate) throw new Error("A generator contains a removed letter. Remove its highlighted token or choose the replacement letter.");
          return null;
        }
        return (index + 1) * (ref.annihilator ? -1 : 1);
      });
    }

    function termIssue(generator, family, term) {
      if (wordFromRefs(term.refs, false).includes(null)) return "Contains a removed letter.";
      const odd = term.refs.filter(ref => ref.species.statistics === "fermion").length % 2;
      if (family === "supercharges" && generator.kind !== "matrix" && !odd) return "A Ward supercharge term needs odd fermion parity.";
      if (family === "symmetries" && odd) return "A symmetry-generator term needs even fermion parity.";
      return "";
    }

    function capture(validate = true) {
      const result = emptyConfig(); result.gauge_singlet = config.gauge_singlet;
      for (const family of ["supercharges", "symmetries"]) {
        const generators = family === "supercharges" ? config[family].filter(generator => !isBlankSupercharge(generator)) : config[family];
        result[family] = generators.map((generator, index) => {
          const name = generator.name.trim() || (family === "supercharges" ? `${mode === "matrix" ? "F" : "Q"}_{${index + 1}}` : `S_{${index + 1}}`);
          if (validate) SolverNotation.validateName(name);
          return { name, ...(family === "supercharges" ? { kind: generator.kind } : {}), terms: generator.terms.map((term, termIndex) => {
            const word = wordFromRefs(term.refs, validate);
            if (validate) {
              if (!term.coefficient.trim()) throw new Error(`${name}, term ${termIndex + 1}: enter a coefficient.`);
              const issue = termIssue(generator, family, term);
              if (issue) throw new Error(`${name}, term ${termIndex + 1}: ${issue}`);
            }
            return { coefficient: term.coefficient.trim(), word };
          }) };
        });
      }
      if (validate && result.supercharges.length + result.symmetries.length > MAX_GENERATORS) throw new Error(`Use at most ${MAX_GENERATORS} generators in total.`);
      return result;
    }

    function formulas(generator, family) {
      if (family === "supercharges" && isBlankSupercharge(generator)) return [];
      const matrix = family === "supercharges" && generator.kind === "matrix";
      let terms = generator.terms.map(term => {
        const word = term.refs.map(ref => getSpecies().includes(ref.species) ? SolverNotation.operator(ref.species.name || "?", ref.annihilator) : "\\boxed{?}").join("\\,") || "1";
        const body = matrix ? word : `\\operatorname{tr}\\!\\left(${word}\\right)`;
        const coefficient = term.coefficient.trim();
        if (coefficient === "1") return body;
        if (coefficient === "-1") return `-${body}`;
        return `\\left(${coefficientLatex(coefficient || "0")}\\right)\\,${body}`;
      }).join(" + ").replace(/\+ -/g, "- ");
      if (matrix) {
        let commutator = false;
        const [a, b] = generator.terms;
        if (generator.terms.length === 2 && a.coefficient.trim() === "1" && b.coefficient.trim() === "-1" &&
            a.refs.length === 2 && b.refs.length === 2 && a.refs.every((ref, i) =>
              ref.species === b.refs[1 - i].species && ref.annihilator === b.refs[1 - i].annihilator)) {
          terms = `\\left[${a.refs.map(ref => getSpecies().includes(ref.species) ? SolverNotation.operator(ref.species.name || "?", ref.annihilator) : "\\boxed{?}").join(",\\,")}\\right]`;
          commutator = true;
        }
        const polynomial = commutator ? terms : `\\left(${terms}\\right)`;
        return [
          `\\left\\langle\\operatorname{tr}\\!\\left(${polynomial}\\,O\\right)\\right\\rangle = 0`,
          `\\left\\langle\\operatorname{tr}\\!\\left(O\\,${polynomial}^{\\dagger}\\right)\\right\\rangle = 0`,
        ];
      }
      const name = generator.name.trim() || (family === "supercharges" ? "Q" : "S");
      const bracket = family === "supercharges" ? "_{\\mathrm{gr}}" : "";
      return [`${name} = ${terms}`,
        `\\left\\langle\\left[${name},\\operatorname{tr}(O)\\right]${bracket}\\right\\rangle = 0`,
        `\\left\\langle\\left[${name}^{\\dagger},\\operatorname{tr}(O)\\right]${bracket}\\right\\rangle = 0`];
    }

    function updatePreview(generator, family) {
      const preview = previewNodes.get(generator);
      if (preview) {
        const equations = formulas(generator, family);
        preview.hidden = !equations.length;
        preview.replaceChildren(node("span", "helper", "Equations to impose"), ...equations.map(value => SolverNotation.render(value)));
      }
    }

    function changed() { onChange(); }

    function setDisabled(value) {
      disabled = value;
      container.querySelectorAll("input,select,button").forEach(control => {
        control.disabled = disabled || control.dataset.limitDisabled === "true";
      });
    }

    function renderPalette(generator, term) {
      const palette = node("div", "word-palette");
      const heading = node("div", "palette-heading");
      heading.append(node("span", "", `Add letters to term ${generator.terms.indexOf(term) + 1}`));
      const undo = button("Undo last letter", "text-button", () => { term.refs.pop(); render(); changed(); });
      undo.dataset.limitDisabled = String(!term.refs.length);
      heading.append(undo); palette.append(heading);
      const choices = node("div", "palette-choices");
      getSpecies().forEach((species, index) => {
        const pair = node("div", "palette-pair");
        for (const annihilator of [false, true]) {
          const choice = button("", "palette-letter", () => {
            if (term.refs.length >= MAX_WORD) return;
            term.refs.push({ species, annihilator }); generator.draft = false; render(); changed();
          });
          choice.setAttribute("aria-label", `Add ${species.name || `letter ${index + 1}`} ${annihilator ? "annihilator" : "creator"} to selected term`);
          choice.title = `${species.statistics === "fermion" ? "Fermionic" : "Bosonic"} ${annihilator ? "annihilator" : "creator"}`;
          choice.dataset.limitDisabled = String(term.refs.length >= MAX_WORD);
          choice.append(SolverNotation.render(SolverNotation.operator(species.name || "?", annihilator)));
          pair.append(choice);
        }
        choices.append(pair);
      });
      if (!getSpecies().length) choices.append(node("span", "helper", "Add letters in Step 1 first."));
      palette.append(choices);
      if (term.refs.length >= MAX_WORD) palette.append(node("p", "helper", `Maximum word length: ${MAX_WORD}. Remove a token to replace it.`));
      return palette;
    }

    function renderGenerator(generator, family, index) {
      const card = node("div", "generator-card");
      card.append(node("h4", "generator-title", entryLabel(family, index)));
      const heading = node("div", "generator-heading");
      const nameLabel = node("label", "generator-name", "Name (LaTeX)");
      const name = node("input"); name.type = "text"; name.maxLength = 128; name.value = generator.name;
      name.placeholder = family === "supercharges" ? (mode === "matrix" ? "F" : "Q") : "S";
      name.setAttribute("aria-label", `${entryLabel(family, index)} name`);
      name.addEventListener("input", () => { generator.name = name.value; updatePreview(generator, family); changed(); });
      nameLabel.append(name); heading.append(nameLabel);
      const remove = button("Remove", "text-button remove-generator", () => {
        config[family].splice(index, 1);
        if (generator.terms.includes(selectedTerm)) selectedTerm = null;
        render(); changed();
      });
      remove.setAttribute("aria-label", `Remove ${entryLabel(family, index).toLowerCase()}`);
      heading.append(remove); card.append(heading);
      const preview = node("div", "generator-preview"); preview.setAttribute("aria-live", "polite");
      previewNodes.set(generator, preview); updatePreview(generator, family);
      const terms = node("div", "generator-terms");
      generator.terms.forEach((term, termIndex) => {
        const row = node("div", `generator-term${selectedTerm === term ? " selected-term" : ""}`);
        const coefficientLabel = node("label", "coefficient-field", `Coefficient ${termIndex + 1}`);
        const coefficient = node("input"); coefficient.type = "text"; coefficient.value = term.coefficient; coefficient.maxLength = 128;
        coefficient.spellcheck = false;
        coefficient.setAttribute("aria-label", `${entryLabel(family, index)}, term ${termIndex + 1} coefficient`);
        coefficient.addEventListener("input", () => { term.coefficient = coefficient.value; generator.draft = false; updatePreview(generator, family); changed(); });
        coefficientLabel.append(coefficient); row.append(coefficientLabel);
        const wordArea = node("div", "term-word-area");
        const wordHeading = node("div", "term-word-heading");
        wordHeading.append(node("span", "", "Ordered word"));
        const select = button(selectedTerm === term ? "Editing" : "Edit word", "text-button", () => { selectedTerm = term; render(); });
        select.setAttribute("aria-label", `Edit word in ${entryLabel(family, index).toLowerCase()}, term ${termIndex + 1}`);
        wordHeading.append(select); wordArea.append(wordHeading);
        const word = node("div", "term-word");
        if (!term.refs.length) word.append(button("Choose letters", "empty-word", () => { selectedTerm = term; render(); }));
        term.refs.forEach((ref, tokenIndex) => {
          const missing = !getSpecies().includes(ref.species);
          const token = button("", `word-token${missing ? " invalid-token" : ""}`, () => { term.refs.splice(tokenIndex, 1); selectedTerm = term; render(); changed(); });
          token.title = missing ? "Removed letter: click to remove this token" : "Click to remove this token";
          token.setAttribute("aria-label", `Remove ${ref.species.name} ${ref.annihilator ? "annihilator" : "creator"} at position ${tokenIndex + 1}`);
          token.append(SolverNotation.render(SolverNotation.operator(ref.species.name || "?", ref.annihilator)), node("span", "token-remove", "×"));
          word.append(token);
        });
        wordArea.append(word);
        const issue = termIssue(generator, family, term);
        if (issue && term.refs.length) wordArea.append(node("p", "term-issue", issue));
        row.append(wordArea);
        const removeTerm = button("×", "remove-term", () => {
          generator.terms.splice(termIndex, 1);
          if (selectedTerm === term) selectedTerm = generator.terms[Math.max(0, termIndex - 1)];
          render(); changed();
        });
        removeTerm.setAttribute("aria-label", `Remove term ${termIndex + 1} from ${entryLabel(family, index).toLowerCase()}`);
        removeTerm.dataset.limitDisabled = String(generator.terms.length <= 1);
        row.append(removeTerm); terms.append(row);
      });
      card.append(terms);
      const addTerm = button("+ Add term", "text-button add-term", () => {
        if (generator.terms.length >= MAX_TERMS) return;
        const term = { coefficient: "1", refs: [] }; generator.terms.push(term); selectedTerm = term; render(); changed();
      });
      addTerm.dataset.limitDisabled = String(generator.terms.length >= MAX_TERMS); card.append(addTerm);
      if (generator.terms.includes(selectedTerm)) card.append(renderPalette(generator, selectedTerm));
      card.append(preview);
      return card;
    }

    function render() {
      previewNodes.clear();
      const gaugeRow = node("div", "gauge-choice");
      const gaugeLabel = node("label", "", "Gauge singlet requirement");
      const gauge = node("select"); gauge.id = "gauge-singlet";
      gaugeLabel.htmlFor = "gauge-singlet";
      for (const [value, label] of [["true", "Enforce"], ["false", "Not enforce"]]) {
        const option = node("option", "", label); option.value = value; gauge.append(option);
      }
      gauge.value = String(config.gauge_singlet);
      gauge.addEventListener("change", () => { config.gauge_singlet = gauge.value === "true"; changed(); });
      gaugeRow.append(gaugeLabel, gauge);
      const groups = node("div", "constraint-groups");
      for (const family of ["supercharges", "symmetries"]) {
        const group = node("section", "constraint-group");
        const heading = node("div", "constraint-group-heading");
        heading.append(node("h3", "", groupLabels[family]));
        group.append(heading);
        const count = () => config.symmetries.length + config.supercharges.filter(generator => !isBlankSupercharge(generator)).length;
        if (family === "supercharges") {
          const typeLabel = node("label", "shared-constraint-mode", "Mode");
          const type = node("select");
          type.setAttribute("aria-label", "Supercharge or matrix relation mode");
          for (const [value, label] of [["ward", "Supercharge Ward identity (default)"], ["matrix", "Matrix relation (specific to e.g. quarter BPS sector)"]]) {
            const option = node("option", "", label); option.value = value; type.append(option);
          }
          type.value = mode;
          type.addEventListener("change", () => {
            mode = type.value;
            config.supercharges.forEach((generator, i) => {
              if (isBlankSupercharge(generator)) { generator.draft = true; generator.name = `${mode === "matrix" ? "F" : "Q"}_{${i + 1}}`; }
              generator.kind = mode;
            });
            render(); changed();
          });
          typeLabel.append(type); group.append(typeLabel);
          const add = button(mode === "matrix" ? "+ Add matrix relation" : "+ Add supercharge", "secondary-button", () => {
            if (count() >= MAX_GENERATORS || config.supercharges.length + config.symmetries.length >= MAX_GENERATORS) return;
            const generator = blankSupercharge(config.supercharges.length + 1);
            config.supercharges.push(generator); selectedTerm = generator.terms[0]; render(); changed();
          });
          add.dataset.limitDisabled = String(count() >= MAX_GENERATORS || config.supercharges.length + config.symmetries.length >= MAX_GENERATORS);
          heading.append(add);
        } else {
          const add = button("+ Add symmetry generator", "secondary-button", () => {
            if (count() >= MAX_GENERATORS) return;
            const term = { coefficient: "1", refs: [] };
            config.symmetries.push({ name: `S_{${config.symmetries.length + 1}}`, terms: [term] });
            selectedTerm = term; render(); changed();
          });
          add.dataset.limitDisabled = String(count() >= MAX_GENERATORS);
          heading.append(add);
        }
        if (family === "supercharges") group.append(node("p", "helper insertion-help", mode === "matrix"
          ? "O runs over charge-compatible words within the truncation. Each adjoint equation is included as shown."
          : "O runs over charge-compatible words within the truncation. The subscript gr denotes the graded commutator."));
        if (!config[family].length) group.append(node("p", "helper generator-empty", family === "symmetries" ? "No additional generators." : "No equations added."));
        const list = node("div", "generator-list");
        config[family].forEach((generator, index) => list.append(renderGenerator(generator, family, index)));
        group.append(list);
        groups.append(group);
      }
      container.replaceChildren(gaugeRow, groups); setDisabled(disabled);
    }

    function refreshModel() {
      const species = getSpecies();
      const labels = JSON.stringify(species.map(item => [item.name, item.statistics]));
      if (labels === previousLabels && species.length === previousSpecies.length && species.every((item, i) => item === previousSpecies[i])) return;
      previousSpecies = [...species]; previousLabels = labels; render();
    }

    function load(raw) {
      const species = getSpecies();
      const validated = validateConfig(raw, species);
      mode = validated.supercharges[0]?.kind || "ward";
      config = { ...validated };
      for (const family of ["supercharges", "symmetries"]) {
        config[family] = validated[family].map(generator => ({ ...generator,
          draft: family === "supercharges" && generator.kind === "ward" && generator.terms.length === 1 &&
            !generator.terms[0].word.length && generator.terms[0].coefficient === "1",
          terms: generator.terms.map(term => ({ coefficient: term.coefficient, refs: refsFromWord(term.word, species) })) }));
      }
      if (!config.supercharges.length) config.supercharges = [blankSupercharge()];
      selectedTerm = isBlankSupercharge(config.supercharges[0]) ? config.supercharges[0].terms[0] : null;
      render();
    }

    refreshModel();
    return Object.freeze({ capture, load, refreshModel, setDisabled });
  }

  function renderResult(container, result) {
    const constraints = result.constraints;
    const config = constraints?.config || emptyConfig();
    const equations = constraints?.equations || [];
    const count = result.summary?.constraint_count ?? equations.length;
    const rank = result.summary?.constraint_rank ?? constraints?.rank ?? 0;
    const active = config.gauge_singlet || config.supercharges?.length || config.symmetries?.length || count;
    container.hidden = !active;
    if (!active) { container.replaceChildren(); return; }
    const details = node("details");
    const summary = node("summary");
    summary.append(node("span", "", "Applied equations"), node("span", "details-count", `${Number(count).toLocaleString()} ${Number(count) === 1 ? "equation" : "equations"} · rank ${Number(rank).toLocaleString()}`));
    details.append(summary);
    const counts = constraints.counts || {};
    details.append(node("p", "helper", `Gauge: ${counts.gauge || 0} · Supercharge: ${counts.supercharge || 0} · Symmetry: ${counts.symmetry || 0}`));
    const list = node("div", "constraint-equations");
    equations.slice(0, 100).forEach(equation => {
      const row = node("div", "constraint-equation");
      const label = node("span", "equation-family", equation.family || "");
      if (equation.generator) label.append(document.createTextNode(" · "), SolverNotation.render(equation.generator));
      row.append(label, SolverNotation.render(equation.latex || `${SolverNotation.variable(equation.expression || "0")} = 0`, equation.expression));
      list.append(row);
    });
    details.append(list);
    if (equations.length > 100) details.append(node("p", "helper", "First 100 equations shown. The exact JSON contains the complete list."));
    container.replaceChildren(details);
  }

  return Object.freeze({ create, emptyConfig, validateConfig, renderResult, coefficientLatex });
})();
