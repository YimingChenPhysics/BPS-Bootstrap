"use strict";

const SolverSetups = (() => {
  function create({ request, captureConfig, loadConfig, onBusyChange }) {
    const $ = id => document.getElementById(id);
    const name = $("setup-name");
    const select = $("saved-setups");
    const save = $("save-setup-button");
    const load = $("load-setup-button");
    const notice = $("setup-notice");
    let setups = [];
    let disabled = false;
    let operation = null;
    const nameKey = value => value.trim().normalize("NFC").toLocaleLowerCase();

    function message(text, error = false) {
      notice.textContent = text;
      notice.hidden = !text;
      notice.classList.toggle("setup-error", error);
      notice.setAttribute("role", error ? "alert" : "status");
    }

    function updateControls() {
      const locked = disabled || operation !== null;
      name.disabled = locked;
      select.disabled = locked || !setups.length;
      save.disabled = locked || !name.value.trim();
      load.disabled = locked || !select.value;
      save.textContent = operation === "save" ? "Saving…" : setups.some(item => !item.built_in && nameKey(item.name) === nameKey(name.value)) ? "Update" : "Save";
      load.textContent = operation === "load" ? "Loading…" : "Load";
    }

    function setOperation(value) {
      operation = value;
      updateControls();
      onBusyChange(value === "save" || value === "load");
    }

    function renderList(selected = select.value) {
      const option = document.createElement("option");
      option.value = "";
      option.textContent = setups.length ? "Choose a saved setup" : "No saved setups yet";
      const makeOption = item => {
        const choice = document.createElement("option");
        choice.value = item.id;
        choice.textContent = item.name;
        return choice;
      };
      select.replaceChildren(option);
      for (const [label, entries] of [
        ["Built-in setups", setups.filter(item => item.built_in)],
        ["My setups", setups.filter(item => !item.built_in).sort((a, b) => a.name.localeCompare(b.name))]
      ]) {
        if (!entries.length) continue;
        const group = document.createElement("optgroup");
        group.label = label;
        group.append(...entries.map(makeOption));
        select.append(group);
      }
      select.value = setups.some(item => item.id === selected) ? selected : "";
      updateControls();
    }

    async function refresh() {
      if (operation) return;
      setOperation("list");
      try {
        const result = await request("/api/setups");
        if (!Array.isArray(result.setups)) throw new Error("The local server returned an unreadable setup list.");
        setups = result.setups;
        renderList();
        message("");
      } catch (error) {
        message(`Could not read saved setups: ${error.message}`, true);
      } finally { setOperation(null); }
    }

    async function saveSetup(event) {
      event.preventDefault();
      if (disabled || operation) return;
      try {
        const setupName = name.value.trim();
        if (!setupName) throw new Error("Enter a setup name.");
        const config = captureConfig();
        setOperation("save");
        message("");
        const result = await request("/api/setups", { method: "POST", body: JSON.stringify({ name: setupName, config }) });
        setups = setups.filter(item => item.id !== result.id);
        setups.push({ id: result.id, name: result.name, updated_at: result.updated_at });
        name.value = result.name;
        renderList(result.id);
        message(`Saved “${result.name}”.`);
      } catch (error) {
        message(`Could not save setup: ${error.message}`, true);
      } finally { setOperation(null); }
    }

    async function loadSetup() {
      if (disabled || operation || !select.value) return;
      setOperation("load");
      message("");
      try {
        const result = await request(`/api/setups/${encodeURIComponent(select.value)}`);
        await loadConfig(result.config);
        name.value = result.built_in ? `${result.name} (copy)` : result.name;
        message(`Loaded “${result.name}”.`);
      } catch (error) {
        message(`Could not load setup: ${error.message}`, true);
      } finally { setOperation(null); }
    }

    $("setup-save-form").addEventListener("submit", saveSetup);
    load.addEventListener("click", loadSetup);
    name.addEventListener("input", () => { message(""); updateControls(); });
    select.addEventListener("change", () => { message(""); updateControls(); });
    renderList();
    return Object.freeze({ refresh, setDisabled(value) { disabled = value; updateControls(); } });
  }

  return Object.freeze({ create });
})();
