"use strict";

// An original, quiet pentatonic phrase, synthesized locally. Audio is created
// only from a build/toggle gesture; no downloaded tracks or background player.
const CookingMusic = (() => {
  const PHRASES = [
    [[0, 74], [0.65, 78], [1.4, 81], [2.5, 78], [3.35, 76], [4.25, 74]],
    [[0, 71], [0.8, 74], [1.6, 78], [2.7, 76], [3.6, 74], [4.6, 69]],
  ];
  const PHRASE_INTERVAL_MS = 14000;

  function create({ onChange } = {}) {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    let enabled = true;
    let available = typeof AudioContext === "function";
    let playing = false;
    let active = false;
    let current = null;
    let phraseIndex = 0;
    let lastStatus = `${enabled}/${available}/${playing}`;

    function status() { return { enabled, available, playing }; }

    function notify() {
      const key = `${enabled}/${available}/${playing}`;
      if (key === lastStatus) return;
      lastStatus = key;
      // A display failure must never break the mathematical build workflow.
      try { if (typeof onChange === "function") onChange(status()); } catch (_) { /* Optional decoration. */ }
    }

    function stopVoices(session) {
      for (const voice of session.voices) {
        voice.oscillator.onended = null;
        try { voice.oscillator.stop(); } catch (_) { /* Already ended. */ }
        try { voice.oscillator.disconnect(); voice.envelope.disconnect(); } catch (_) { /* Already disconnected. */ }
      }
      session.voices.clear();
    }

    function quiet(session) {
      if (session.timer !== null) window.clearTimeout(session.timer);
      session.timer = null;
      stopVoices(session);
    }

    function closeContext(context) {
      try { Promise.resolve(context.close()).catch(() => {}); } catch (_) { /* The browser may already have closed it. */ }
    }

    function release() {
      const session = current;
      current = null;
      playing = false;
      if (!session) return;
      session.context.onstatechange = null;
      quiet(session);
      try { session.master.disconnect(); } catch (_) { /* Already disconnected. */ }
      closeContext(session.context);
    }

    function note(session, time, pitch) {
      const oscillator = session.context.createOscillator();
      const envelope = session.context.createGain();
      const voice = { oscillator, envelope };
      session.voices.add(voice);
      oscillator.type = "sine";
      oscillator.frequency.setValueAtTime(440 * 2 ** ((pitch - 69) / 12), time);
      envelope.gain.setValueAtTime(0, time);
      envelope.gain.linearRampToValueAtTime(0.28, time + 0.025);
      envelope.gain.exponentialRampToValueAtTime(0.0001, time + 1.25);
      oscillator.connect(envelope);
      envelope.connect(session.master);
      oscillator.onended = () => {
        session.voices.delete(voice);
        oscillator.disconnect();
        envelope.disconnect();
      };
      oscillator.start(time);
      oscillator.stop(time + 1.3);
    }

    function schedulePhrase(session) {
      if (current !== session || !active || !enabled || session.context.state !== "running") return;
      const start = session.context.currentTime + 0.05;
      const phrase = PHRASES[phraseIndex++ % PHRASES.length];
      for (const [offset, pitch] of phrase) note(session, start + offset, pitch);
      // Leave several quiet seconds between phrases. Schedule from the current
      // audio clock after a delayed/background timer; never replay a backlog.
      session.timer = window.setTimeout(() => {
        session.timer = null;
        try { schedulePhrase(session); } catch (_) { fail(session); }
      }, PHRASE_INTERVAL_MS);
    }

    function fail(session) {
      if (current !== session) return;
      enabled = false;
      release();
      notify();
    }

    function synchronize(session) {
      if (current !== session || !active || !enabled) return;
      try {
        if (session.context.state === "running") {
          if (session.timer === null) schedulePhrase(session);
          playing = true;
        } else {
          quiet(session);
          playing = false;
        }
        notify();
      } catch (_) { fail(session); }
    }

    function begin() {
      if (!active || !enabled || !available || current) return;
      let context;
      try {
        context = new AudioContext();
        const master = context.createGain();
        master.gain.setValueAtTime(0.075, context.currentTime);
        master.connect(context.destination);
        const session = { context, master, timer: null, voices: new Set() };
        current = session;
        context.onstatechange = () => synchronize(session);
        // Call resume synchronously, before leaving the user's click gesture.
        // Session identity protects stop/mute/restart from a late resolution.
        Promise.resolve(context.resume()).then(() => synchronize(session), () => fail(session));
      } catch (_) {
        if (current) release();
        else if (context) closeContext(context);
        available = false;
        playing = false;
        notify();
      }
    }

    function start() {
      if (active) return;
      active = true;
      phraseIndex = 0;
      begin();
    }

    function stop() {
      active = false;
      release();
      notify();
    }

    function toggle() {
      if (!available) return;
      enabled = !enabled;
      if (enabled) begin();
      else release();
      notify();
    }

    return Object.freeze({ start, stop, toggle, status });
  }

  return Object.freeze({ create });
})();
