"use strict";

// A presentation of the submitted model; it never changes the build request.
const SolverCooking = (() => {
  function definitionParts(generator, species, index = 0) {
    const matrix = generator.kind === "matrix";
    const name = generator.name || `${matrix ? "F" : "Q"}_{${index + 1}}`;
    const parts = [`${name} =`];
    generator.terms.forEach((term, termIndex) => {
      const coefficient = term.coefficient.trim();
      const word = SolverNotation.word(term.word, species);
      const body = matrix ? word : `\\operatorname{tr}\\!\\left(${word}\\right)`;
      if (coefficient === "1") parts.push(`${termIndex ? "+ " : ""}${body}`);
      else if (coefficient === "-1") parts.push(`- ${body}`);
      else parts.push(`${termIndex ? "+ " : ""}\\left(${SolverConstraints.coefficientLatex(coefficient)}\\right)\\,${body}`);
    });
    return parts;
  }

  function create() {
    const get = id => document.getElementById(id);
    const panel = get("build-cooking");
    const formula = get("cooking-formula");
    const pages = get("cooking-pages");
    const musicButton = get("cooking-music");
    let config = null;
    let page = 0;
    let active = false;

    function showMusic(status) {
      musicButton.disabled = !status.available;
      musicButton.textContent = !status.available ? "Music unavailable" : status.enabled ? "♪ Mute music" : "♪ Play music";
      musicButton.setAttribute("aria-pressed", String(status.enabled && status.available));
      musicButton.setAttribute("aria-label", !status.available ? "Music unavailable in this browser" : status.enabled ? "Mute cooking music" : "Play cooking music");
    }
    const music = typeof CookingMusic !== "undefined" ? CookingMusic.create({ onChange: showMusic }) : null;
    showMusic(music?.status() ?? { available: false, enabled: false, playing: false });

    function render() {
      const generators = config?.constraints?.supercharges ?? [];
      pages.hidden = generators.length < 2;
      formula.replaceChildren();
      formula.scrollTop = 0;
      formula.scrollLeft = 0;
      if (!generators.length) {
        const label = document.createElement("span");
        label.className = "cooking-empty";
        label.textContent = "Cooking up moments…";
        formula.append(label);
        formula.setAttribute("aria-label", "Preparing the model’s moments; no supercharge specified");
        return;
      }
      const generator = generators[page];
      const kind = generator.kind === "matrix" ? "Matrix relation" : "Supercharge";
      formula.setAttribute("aria-label", `${kind} ${page + 1} of ${generators.length} in the pot`);
      const parts = definitionParts(generator, config.model.species, page);
      formula.classList.toggle("cooking-formula-short", parts.join("").length < 140);
      parts.forEach(part => {
        const term = document.createElement("span");
        term.className = "cooking-term";
        term.append(SolverNotation.render(part));
        formula.append(term);
      });
      get("cooking-page").textContent = `${kind} ${page + 1} of ${generators.length}`;
    }

    get("cooking-previous").addEventListener("click", () => {
      const count = config?.constraints?.supercharges?.length || 0;
      if (!active || !count) return;
      page = (page + count - 1) % count;
      render();
    });
    get("cooking-next").addEventListener("click", () => {
      const count = config?.constraints?.supercharges?.length || 0;
      if (!active || !count) return;
      page = (page + 1) % count;
      render();
    });
    musicButton.addEventListener("click", () => { if (active) music?.toggle(); });

    function start(request) {
      if (active) return;
      active = true;
      config = request;
      page = 0;
      panel.hidden = false;
      // Resume audio in the Build SDP click/submit gesture, before any await.
      music?.start();
      render();
      panel.scrollIntoView?.({ block: "nearest", behavior: "auto" });
    }

    function stop() {
      active = false;
      panel.hidden = true;
      music?.stop();
      config = null;
      formula.replaceChildren();
    }

    return Object.freeze({ start, stop });
  }

  return Object.freeze({ create, definitionParts });
})();
