"use strict";

// Observable constraints are input data. Exact arithmetic and SDP preparation belong
// to the backend; display names never identify letters in an ordered word.
const SolverPreparation = (() => {
  const MAX_OBSERVABLES = 12;
  const MAX_TERMS = 64;
  const MAX_WORD = 24;
  const emptyConfig = () => ({ fixed_observables: [] });
  const node = (tag, className, text) => {
    const result = document.createElement(tag);
    if (className) result.className = className;
    if (text !== undefined) result.textContent = String(text);
    return result;
  };
  const button = (label, className, action) => {
    const result = node("button", className, label);
    result.type = "button"; result.addEventListener("click", action); return result;
  };

  function exactInput(value, description) {
    if (typeof value !== "string" || !value.trim() || value.length > 128) {
      throw new Error(`${description} must be a nonempty exact expression of at most 128 characters.`);
    }
    return value.trim();
  }

  function validateDefinition(raw, species, level, label, fixed = false) {
    const keys = fixed ? ["name", "value", "terms", "relation"] : ["name", "terms"];
    if (!raw || typeof raw !== "object" || Array.isArray(raw) || Object.keys(raw).some(key => !keys.includes(key))) throw new Error(`${label} contains a name, ${fixed ? "value, optional relation, and " : "and "}terms.`);
    const name = raw.name === undefined ? "" : raw.name;
    if (typeof name !== "string" || name.length > 128) throw new Error(`${label} names must have at most 128 characters.`);
    if (name.trim()) SolverNotation.validateName(name);
    const value = fixed ? exactInput(raw.value, `${label} value`) : undefined;
    const relation = fixed && raw.relation !== undefined ? raw.relation : "=";
    if (!["=", "<=", ">="].includes(relation)) throw new Error(`${label} relation must be =, <=, or >=.`);
    if (!Array.isArray(raw.terms) || !raw.terms.length || raw.terms.length > MAX_TERMS) throw new Error(`${label} needs 1–${MAX_TERMS} terms.`);
    const terms = raw.terms.map(term => {
      if (!term || typeof term !== "object" || Array.isArray(term) || Object.keys(term).some(key => !["coefficient", "word"].includes(key))) throw new Error("Each term contains a coefficient and an ordered word.");
      const coefficient = exactInput(term.coefficient, "Coefficient");
      if (!Array.isArray(term.word) || term.word.length > MAX_WORD || term.word.some(token => !Number.isInteger(token) || token === 0 || Math.abs(token) > species.length)) throw new Error(`${label} words need up to ${MAX_WORD} valid letter tokens; an empty word is the identity.`);
      if (Number.isInteger(level) && term.word.length > 2 * level) throw new Error(`${label} contains a word longer than 2ℓ = ${2 * level}. Increase the level or shorten the word.`);
      if (term.word.reduce((parity, token) => parity + (species[Math.abs(token) - 1].statistics === "fermion" ? 1 : 0), 0) % 2) throw new Error(`${label} terms must have even fermion parity.`);
      return { coefficient, word: [...term.word] };
    });
    return { name: name.trim(), ...(fixed ? { value } : {}), terms,
      ...(relation === "=" ? {} : { relation }) };
  }

  function validateConfig(raw, species, level) {
    if (raw === undefined || raw === null) return emptyConfig();
    if (typeof raw !== "object" || Array.isArray(raw) || Object.keys(raw).some(key => !["fixed_observables", "variable_cutoff", "bmn_observable_cutoff", "optimization", "bmn_su3_reduction"].includes(key))) {
      throw new Error("Unknown SDP preparation setting.");
    }
    if (raw.bmn_su3_reduction !== undefined && typeof raw.bmn_su3_reduction !== "boolean") throw new Error("BMN SU(3) block reduction must be enabled or disabled.");
    if (raw.variable_cutoff != null) throw new Error("The general independent-variable cutoff has been removed. Remove variable_cutoff from this setup; the BMN observable cutoff is a separate option.");
    const cutoff = raw.bmn_observable_cutoff == null ? undefined : exactInput(raw.bmn_observable_cutoff, "BMN observable cutoff");
    const observables = raw.fixed_observables ?? [];
    if (!Array.isArray(observables) || observables.length > MAX_OBSERVABLES) throw new Error(`Define at most ${MAX_OBSERVABLES} observable constraints.`);
    let optimization;
    if (raw.optimization != null) {
      const input = raw.optimization;
      const mode = input.mode === undefined ? "feasibility" : input.mode;
      if (typeof input !== "object" || Array.isArray(input) || Object.keys(input).some(key => !["mode", "objective"].includes(key)) || !["feasibility", "minimize", "maximize"].includes(mode)) throw new Error("Choose Check feasibility, Minimize, or Maximize.");
      if (mode === "feasibility") {
        if (input.objective !== undefined) throw new Error("Check feasibility does not include an objective.");
      } else optimization = { mode, objective: validateDefinition(input.objective, species, level, "Objective") };
    }
    return { fixed_observables: observables.map((observable, index) => validateDefinition(observable, species, level, `Observable ${index + 1}`, true)),
      ...(cutoff === undefined ? {} : { bmn_observable_cutoff: cutoff }), ...(optimization ? { optimization } : {}),
      ...(raw.bmn_su3_reduction ? { bmn_su3_reduction: true } : {}) };
  }

  // A limited presentation conversion, never arithmetic evaluation.
  function numberLatex(value) {
    const text = String(value).trim();
    if (!text) return "?";
    if (!/^[\d\s.+\-*/^(),a-zA-Z]+$/.test(text)) return "\\text{expression}";
    return text.replace(/sqrt\(([^()]*)\)/g, "\\sqrt{$1}")
      .replace(/\b[Ii]\b/g, "\\mathrm{i}").replace(/\*\*/g, "^").replace(/\*/g, "\\cdot ");
  }

  function definitionLatex(terms, species) {
    return terms.map(term => {
      const moment = term.word.length ? SolverNotation.moment([term.word], species) : "1";
      return term.coefficient === "1" ? moment : term.coefficient === "-1" ? `-${moment}` : `\\left(${numberLatex(term.coefficient)}\\right)\\,${moment}`;
    }).join(" + ").replace(/\+ -/g, "- ");
  }

  const relationLatex = relation => ({ "<=": "\\le", ">=": "\\ge" }[relation] || "=");

  function create({ container, getSpecies, getLevel = () => undefined, isBmnSetup = () => false, onChange }) {
    let observables = [];
    let selectedTerm = null;
    let cutoffEnabled = false;
    let cutoffValue = "100";
    let bmnReduction = false;
    let bmnEligible = false;
    let bmnDraftInitialized = false;
    let optimizationMode = "feasibility";
    let objective = { name: "", terms: [{ coefficient: "1", refs: [] }] };
    let disabled = false;
    let previousSpecies = [];
    let previousLabels = "";
    const previews = new Map();

    function tokens(refs) {
      return refs.map(ref => {
        const index = getSpecies().indexOf(ref.species);
        if (index < 0) throw new Error("An observable contains a removed letter. Remove its highlighted token or choose its replacement.");
        return (index + 1) * (ref.annihilator ? -1 : 1);
      });
    }

    function capture() {
      const eligible = Boolean(isBmnSetup());
      const definition = observable => ({ name: observable.name,
        terms: observable.terms.map(term => ({ coefficient: term.coefficient, word: tokens(term.refs) })) });
      return validateConfig({ fixed_observables: observables.map(observable => ({
        ...definition(observable), value: observable.value, relation: observable.relation ?? "=",
      })), ...(eligible && cutoffEnabled ? { bmn_observable_cutoff: cutoffValue } : {}),
      ...(eligible && bmnReduction ? { bmn_su3_reduction: true } : {}),
      ...(optimizationMode === "feasibility" ? {} : { optimization: { mode: optimizationMode, objective: definition(objective) } }) }, getSpecies(), getLevel());
    }

    function formula(observable) {
      const terms = observable.terms.map(term => {
        const word = term.refs.map(ref => getSpecies().includes(ref.species) ? SolverNotation.operator(ref.species.name || "?", ref.annihilator) : "\\boxed{?}").join("\\,");
        const body = word ? `\\left\\langle\\operatorname{tr}\\!\\left(${word}\\right)\\right\\rangle` : "1";
        const coefficient = term.coefficient.trim();
        if (coefficient === "1") return body;
        if (coefficient === "-1") return `-${body}`;
        return `\\left(${numberLatex(coefficient)}\\right)\\,${body}`;
      }).join(" + ").replace(/\+ -/g, "- ");
      return `${observable.name.trim() ? `${observable.name.trim()} = ` : ""}${terms}${observable.value === undefined ? "" : ` ${relationLatex(observable.relation)} ${numberLatex(observable.value)}`}`;
    }

    function updatePreview(observable) {
      previews.get(observable)?.replaceChildren(SolverNotation.render(formula(observable)));
    }

    function setDisabled(value) {
      disabled = value;
      container.querySelectorAll("input,select,button").forEach(control => {
        control.disabled = disabled || control.dataset.limitDisabled === "true";
      });
    }

    function changeWord(action) { action(); render(); onChange(); }

    function palette(observable, term) {
      const result = node("div", "word-palette");
      const heading = node("div", "palette-heading");
      heading.append(node("span", "", `Add letters to term ${observable.terms.indexOf(term) + 1}`));
      const actions = node("div", "preparation-word-actions");
      const undo = button("Undo last letter", "text-button", () => changeWord(() => term.refs.pop()));
      undo.dataset.limitDisabled = String(!term.refs.length);
      const identity = button("Use identity", "text-button", () => changeWord(() => { term.refs = []; }));
      identity.dataset.limitDisabled = String(!term.refs.length);
      actions.append(undo, identity); heading.append(actions); result.append(heading);
      const choices = node("div", "palette-choices");
      getSpecies().forEach((species, index) => {
        const pair = node("div", "palette-pair");
        for (const annihilator of [false, true]) {
          const choice = button("", "palette-letter", () => {
            if (term.refs.length < MAX_WORD) changeWord(() => term.refs.push({ species, annihilator }));
          });
          choice.setAttribute("aria-label", `Add ${species.name || `letter ${index + 1}`} ${annihilator ? "annihilator" : "creator"} to ${observable === objective ? "objective" : "observable"} term`);
          choice.title = `${species.statistics === "fermion" ? "Fermionic" : "Bosonic"} ${annihilator ? "annihilator" : "creator"}`;
          choice.dataset.limitDisabled = String(term.refs.length >= MAX_WORD);
          choice.append(SolverNotation.render(SolverNotation.operator(species.name || "?", annihilator)));
          pair.append(choice);
        }
        choices.append(pair);
      });
      if (!getSpecies().length) choices.append(node("p", "helper", "Add letters in Step 1 first."));
      result.append(choices);
      if (term.refs.length >= MAX_WORD) result.append(node("p", "helper", `Maximum word length: ${MAX_WORD}.`));
      return result;
    }

    function observableCard(observable, index, isObjective = false) {
      const label = isObjective ? "Objective" : `Observable ${index + 1}`;
      const card = node("div", `generator-card observable-card${isObjective ? " objective-card" : ""}`);
      if (isObjective) card.append(node("h3", "", "Objective"));
      const heading = node("div", "generator-heading");
      const fields = [["name", "Name (optional LaTeX)", isObjective ? "O" : "R"], ...(!isObjective ? [["value", "Value", "1"]] : [])];
      for (const [key, fieldLabel, placeholder] of fields) {
        const fieldGroup = key === "value" ? node("div", "observable-bound") : heading;
        if (key === "value") {
          const relationField = node("label", "observable-relation", "Relation");
          const relation = node("select"); relation.setAttribute("aria-label", `${label} relation`);
          for (const [value, text] of [["=", "="], ["<=", "≤"], [">=", "≥"]]) {
            const option = node("option", "", text); option.value = value; relation.append(option);
          }
          relation.value = observable.relation ?? "=";
          relation.addEventListener("change", () => { observable.relation = relation.value; updatePreview(observable); onChange(); });
          relationField.append(relation); fieldGroup.append(relationField);
        }
        const field = node("label", key === "name" ? "generator-name" : "observable-value", fieldLabel);
        const input = node("input"); input.type = "text"; input.maxLength = 128; input.value = observable[key];
        input.placeholder = placeholder; input.spellcheck = false; input.autocomplete = "off";
        input.setAttribute("aria-label", `${label} ${key}`);
        input.addEventListener("input", () => { observable[key] = input.value; updatePreview(observable); onChange(); });
        field.append(input); fieldGroup.append(field);
        if (fieldGroup !== heading) heading.append(fieldGroup);
      }
      if (!isObjective) {
        const remove = button("Remove", "text-button remove-generator", () => {
          if (observable.terms.includes(selectedTerm)) selectedTerm = null;
          observables.splice(index, 1); render(); onChange();
        });
        remove.setAttribute("aria-label", `Remove observable ${index + 1}`);
        heading.append(remove);
      }
      card.append(heading);
      const preview = node("div", "generator-preview"); preview.setAttribute("aria-live", "polite");
      previews.set(observable, preview); card.append(preview); updatePreview(observable);
      const terms = node("div", "generator-terms");
      observable.terms.forEach((term, termIndex) => {
        const row = node("div", `generator-term${selectedTerm === term ? " selected-term" : ""}`);
        const coefficientField = node("label", "coefficient-field", `Coefficient ${termIndex + 1}`);
        const coefficient = node("input"); coefficient.type = "text"; coefficient.maxLength = 128; coefficient.value = term.coefficient; coefficient.spellcheck = false;
        coefficient.setAttribute("aria-label", `${label}, term ${termIndex + 1} coefficient`);
        coefficient.addEventListener("input", () => { term.coefficient = coefficient.value; updatePreview(observable); onChange(); });
        coefficientField.append(coefficient); row.append(coefficientField);
        const wordArea = node("div", "term-word-area");
        const wordHeading = node("div", "term-word-heading");
        const edit = button(selectedTerm === term ? "Editing" : "Edit word", "text-button", () => { selectedTerm = term; render(); });
        edit.setAttribute("aria-label", `Edit ${label.toLowerCase()}, term ${termIndex + 1} word`);
        wordHeading.append(node("span", "", "Ordered word"), edit); wordArea.append(wordHeading);
        const word = node("div", "term-word");
        if (!term.refs.length) word.append(button("Identity (1)", "empty-word", () => { selectedTerm = term; render(); }));
        term.refs.forEach((ref, tokenIndex) => {
          const missing = !getSpecies().includes(ref.species);
          const token = button("", `word-token${missing ? " invalid-token" : ""}`, () => changeWord(() => { term.refs.splice(tokenIndex, 1); selectedTerm = term; }));
          token.title = missing ? "Removed letter: click to remove this token" : "Click to remove this token";
          token.setAttribute("aria-label", `Remove ${ref.species.name} ${ref.annihilator ? "annihilator" : "creator"} at position ${tokenIndex + 1}`);
          token.append(SolverNotation.render(SolverNotation.operator(ref.species.name || "?", ref.annihilator)), node("span", "token-remove", "×"));
          word.append(token);
        });
        wordArea.append(word);
        if (term.refs.some(ref => !getSpecies().includes(ref.species))) wordArea.append(node("p", "term-issue", "Contains a removed letter."));
        row.append(wordArea);
        const removeTerm = button("×", "remove-term", () => {
          observable.terms.splice(termIndex, 1);
          if (selectedTerm === term) selectedTerm = observable.terms[Math.max(0, termIndex - 1)];
          render(); onChange();
        });
        removeTerm.setAttribute("aria-label", `Remove term ${termIndex + 1} from ${label.toLowerCase()}`);
        removeTerm.dataset.limitDisabled = String(observable.terms.length <= 1);
        row.append(removeTerm); terms.append(row);
      });
      card.append(terms);
      const addTerm = button("+ Add term", "text-button add-term", () => {
        if (observable.terms.length >= MAX_TERMS) return;
        selectedTerm = { coefficient: "1", refs: [] }; observable.terms.push(selectedTerm); render(); onChange();
      });
      addTerm.setAttribute("aria-label", `Add ${isObjective ? "objective" : "observable"} term`);
      addTerm.dataset.limitDisabled = String(observable.terms.length >= MAX_TERMS); card.append(addTerm);
      if (observable.terms.includes(selectedTerm)) card.append(palette(observable, selectedTerm));
      return card;
    }

    function render() {
      previews.clear();
      const optimization = node("div", "optimization-controls");
      const modeLabel = node("label", "optimization-mode", "Task");
      const mode = node("select"); mode.setAttribute("aria-label", "SDP task");
      for (const [value, text] of [["feasibility", "Check feasibility"], ["minimize", "Minimize"], ["maximize", "Maximize"]]) {
        const option = node("option", "", text); option.value = value; mode.append(option);
      }
      mode.value = optimizationMode;
      mode.addEventListener("change", () => {
        optimizationMode = mode.value;
        if (optimizationMode !== "feasibility") selectedTerm = objective.terms[0];
        else if (objective.terms.includes(selectedTerm)) selectedTerm = null;
        render(); onChange();
      });
      modeLabel.append(mode); optimization.append(modeLabel);
      if (optimizationMode !== "feasibility") optimization.append(observableCard(objective, 0, true));
      const list = node("div", "observable-list");
      if (!observables.length) list.append(node("p", "helper generator-empty", "No observable constraints. You can prepare the relaxation without adding any."));
      observables.forEach((observable, index) => list.append(observableCard(observable, index)));
      const add = button("+ Add observable constraint", "secondary-button add-observable", () => {
        if (observables.length >= MAX_OBSERVABLES) return;
        selectedTerm = { coefficient: "1", refs: [] };
        observables.push({ name: "", value: "1", terms: [selectedTerm] }); render(); onChange();
      });
      add.dataset.limitDisabled = String(observables.length >= MAX_OBSERVABLES);
      const children = [optimization, list, add];
      if (bmnEligible) {
        const bmnOptions = node("div", "bmn-options");
        const bmn = node("label", "bmn-option");
        const bmnToggle = node("input"); bmnToggle.type = "checkbox"; bmnToggle.checked = bmnReduction;
        bmnToggle.setAttribute("aria-label", "BMN only: use SU(3) block reduction");
        bmnToggle.addEventListener("change", () => { bmnReduction = bmnToggle.checked; onChange(); });
        bmn.append(bmnToggle, node("span", "", "BMN only: use SU(3) block reduction"));
        bmn.title = "Requires the BMN letters, charges, and both SU(3) symmetry generators. Preserves independent variables.";
        const cutoff = node("div", "bmn-observable-cutoff");
        const toggleLabel = node("label", "bmn-option");
        const toggle = node("input"); toggle.type = "checkbox"; toggle.checked = cutoffEnabled;
        const cutoffLabel = "BMN only: impose positive cutoff on two observables";
        toggle.setAttribute("aria-label", cutoffLabel);
        toggleLabel.append(toggle, node("span", "", cutoffLabel));
        const valueLabel = node("label", "bmn-cutoff-value");
        const value = node("input"); value.type = "text"; value.value = cutoffValue; value.maxLength = 128;
        value.placeholder = "100"; value.spellcheck = false; value.autocomplete = "off";
        value.title = "Positive exact number, such as 10, 1/2, or sqrt(2).";
        value.setAttribute("aria-label", "BMN observable cutoff Lambda");
        value.dataset.limitDisabled = String(!cutoffEnabled);
        toggle.addEventListener("change", () => {
          cutoffEnabled = toggle.checked;
          value.dataset.limitDisabled = String(!cutoffEnabled);
          setDisabled(disabled); onChange();
          if (cutoffEnabled) value.focus();
        });
        value.addEventListener("input", () => { cutoffValue = value.value; onChange(); });
        valueLabel.append(SolverNotation.render("\\Lambda", "Lambda"), value);
        cutoff.append(toggleLabel, valueLabel);
        const cutoffHelp = node("p", "helper bmn-cutoff-help");
        cutoffHelp.append(SolverNotation.render("\\left\\langle\\operatorname{tr}((f\\bar f)^3)\\right\\rangle \\le \\Lambda,\\qquad \\left\\langle\\operatorname{tr}((\\phi_1\\bar\\phi_1)^3)\\right\\rangle \\le \\Lambda"),
          node("span", "", "Requires BMN and level ℓ ≥ 3. Use a positive exact value for Λ."));
        const cutoffNote = node("p", "helper", "Note: some bounds are approached only as such higher moments tend to infinity. We therefore provide an option to impose a cutoff on these moments. A better cutoff-free approach (not implemented here) is to identify directions along which higher moments can grow without changing the objective, and construct a reduced SDP that preserves the limiting bound.");
        bmnOptions.append(bmn, cutoff, cutoffHelp, cutoffNote);
        children.push(bmnOptions);
      }
      container.replaceChildren(...children); setDisabled(disabled);
    }

    function refreshModel() {
      const species = getSpecies();
      const labels = JSON.stringify(species.map(item => [item.name, item.statistics]));
      const eligible = Boolean(isBmnSetup());
      if (eligible && !bmnDraftInitialized) {
        bmnReduction = true;
        cutoffEnabled = true;
        cutoffValue = "100";
        bmnDraftInitialized = true;
      }
      if (eligible === bmnEligible && labels === previousLabels && species.length === previousSpecies.length && species.every((item, i) => item === previousSpecies[i])) return;
      bmnEligible = eligible;
      previousLabels = labels; previousSpecies = [...species]; render();
    }

    function load(raw) {
      const species = getSpecies();
      const config = validateConfig(raw, species, getLevel());
      const editable = observable => ({ ...observable, terms: observable.terms.map(term => ({
        coefficient: term.coefficient, refs: term.word.map(token => ({ species: species[Math.abs(token) - 1], annihilator: token < 0 })),
      })) });
      observables = config.fixed_observables.map(editable);
      bmnEligible = Boolean(isBmnSetup());
      const useDefaults = raw == null && bmnEligible;
      cutoffEnabled = useDefaults || config.bmn_observable_cutoff !== undefined;
      cutoffValue = config.bmn_observable_cutoff ?? "100";
      bmnReduction = config.bmn_su3_reduction ?? useDefaults;
      // A loaded BMN setup owns its choices, including deliberately absent options.
      bmnDraftInitialized = bmnEligible;
      previousLabels = JSON.stringify(species.map(item => [item.name, item.statistics]));
      previousSpecies = [...species];
      optimizationMode = config.optimization?.mode ?? "feasibility";
      objective = config.optimization ? editable(config.optimization.objective) : { name: "", terms: [{ coefficient: "1", refs: [] }] };
      selectedTerm = null; render();
    }

    refreshModel();
    return Object.freeze({ capture, load, refreshModel, setDisabled });
  }

  function renderResult(container, result, jobId, loopEquations = null) {
    const prepared = result.preparation;
    const summary = prepared.summary || {};
    const previewCounts = prepared.preview_counts || {};
    const format = value => Number(value || 0).toLocaleString();
    const blocks = (prepared.blocks || []).filter(block => Number(block.size) > 0);
    const totalDimension = blocks.reduce((total, block) => total + Number(block.size), 0);
    const largestBlock = blocks.reduce((largest, block) => Math.max(largest, Number(block.size)), 0);
    const expression = (latex, fallback = "0") => SolverNotation.render(latex ?? SolverNotation.variable(fallback), fallback);
    const heading = node("div", "results-heading");
    const title = node("div"); title.append(node("p", "eyebrow", "PREPARED SDP"), node("h2", "", `Level ${result.settings?.level ?? ""}`));
    const download = node("a", "secondary-button download-button", "Download prepared JSON ↓");
    download.href = `/api/jobs/${encodeURIComponent(jobId)}/download`; download.download = "";
    heading.append(title, download);
    const note = node("p", "helper preparation-result-note", "Prepared, not numerically solved.");
    const optimization = prepared.optimization;
    const objectiveNote = ["minimize", "maximize"].includes(optimization?.mode) ? node("p", "preparation-result-note objective-result-note") : null;
    if (objectiveNote) {
      objectiveNote.append(node("strong", "", optimization.mode === "minimize" ? "Minimize" : "Maximize"));
      const input = prepared.config?.optimization?.objective;
      const name = input?.name || optimization.name;
      if (name) objectiveNote.append(SolverNotation.render(name), SolverNotation.render("="));
      if (input?.terms) objectiveNote.append(SolverNotation.render(definitionLatex(input.terms, result.model.species)), SolverNotation.render("="));
      objectiveNote.append(expression(optimization.latex, optimization.expression));
    }
    const cutoffNote = prepared.bmn_observable_cutoff?.enabled ? node("p", "helper preparation-result-note cutoff-result-note") : null;
    if (cutoffNote) {
      cutoffNote.append(node("span", "", "Both BMN cutoff observables are bounded above by "),
        SolverNotation.render(`\\Lambda = ${prepared.bmn_observable_cutoff.value_latex ?? numberLatex(prepared.bmn_observable_cutoff.value)}`));
    }
    const stats = node("div", "summary-grid");
    for (const [label, value] of [["Remaining variables", format(summary.remaining_variable_count)], ["PSD blocks", format(blocks.length)], ["Total PSD dimension", format(totalDimension)], ["Largest block", `${format(largestBlock)} × ${format(largestBlock)}`]]) {
      const stat = node("div", "summary-stat"); stat.append(node("span", "", label), node("strong", "", value)); stats.append(stat);
    }
    const matrixPanel = node("div", "panel matrix-panel");
    const matrixHeading = node("div", "panel-heading matrix-heading"); matrixHeading.append(node("h3", "", "Prepared PSD blocks"));
    const controls = node("div", "block-controls");
    const blockLabel = node("label", "block-label", "Block");
    const select = node("select"); select.setAttribute("aria-label", "Prepared PSD block");
    let multitraceIndex = 0;
    blocks.forEach((block, index) => {
      const name = ["schur", "covariance", "identical"].includes(block.kind) ? `Multitrace relaxation block ${++multitraceIndex}` : block.name || `Block ${index + 1}`;
      const option = node("option", "", name);
      option.value = String(index); select.append(option);
    });
    select.value = blocks.length ? "0" : "";
    select.disabled = blocks.length < 2;
    blockLabel.append(select);
    const dimensions = node("div", "block-dimensions"); dimensions.append(node("span", "", "Block size"));
    const sizeLabel = node("strong"); dimensions.append(sizeLabel);
    const inputs = ["First row", "First column"].map(label => {
      const field = node("label", "window-label");
      const labelText = node("span", "", label);
      const input = node("input"); input.type = "number"; input.min = "1"; input.step = "1"; input.value = "1";
      input.setAttribute("aria-label", `Prepared matrix ${label.toLowerCase()}`);
      field.append(labelText, input); controls.append(field); return { field, input, labelText };
    });
    controls.replaceChildren(blockLabel, dimensions, ...inputs.map(item => item.field));
    const preview = node("div", "matrix-scroll"); preview.tabIndex = 0; preview.setAttribute("aria-label", "Scrollable prepared PSD matrix");
    const caption = node("p", "preview-caption");
    matrixPanel.append(matrixHeading, controls, preview, caption);
    let entries = new Map();
    function drawMatrix() {
      const block = blocks[Number(select.value) || 0];
      const size = Number(block?.size || 0);
      if (!block || !size) {
        preview.replaceChildren(node("p", "helper prepared-empty", "No PSD blocks remain.")); caption.hidden = true; return;
      }
      const start = inputs.map(({ input }) => {
        const value = Number(input.value);
        const clamped = block.preview_size ? 1 : Math.max(1, Math.min(size, Number.isInteger(value) ? value : 1));
        input.value = String(clamped); return clamped - 1;
      });
      const end = start.map(value => Math.min(size, block.preview_size || size, value + 12));
      const table = node("table", "matrix-table");
      table.append(node("caption", "sr-only", "Exact prepared PSD block"));
      const head = node("thead"); const header = node("tr"); header.append(node("th", "", ""));
      function label(index) {
        const th = node("th");
        if (block.labels_latex?.[index] !== undefined) th.append(expression(block.labels_latex[index], block.labels?.[index]));
        else th.textContent = block.labels?.[index] ?? String(index + 1);
        return th;
      }
      for (let col = start[1]; col < end[1]; col++) { const th = label(col); th.scope = "col"; header.append(th); }
      head.append(header); const body = node("tbody");
      for (let row = start[0]; row < end[0]; row++) {
        const tr = node("tr"); const th = label(row); th.scope = "row"; tr.append(th);
        for (let col = start[1]; col < end[1]; col++) {
          const entry = entries.get(`${row},${col}`); const value = entry?.expression || "0";
          const td = node("td", `${value === "0" ? "zero " : ""}${row === col ? "diagonal" : ""}`);
          td.append(expression(entry?.latex, value)); td.title = `M[${row + 1}, ${col + 1}] = ${value}`; tr.append(td);
        }
        body.append(tr);
      }
      table.append(head, body); preview.replaceChildren(table);
      caption.textContent = `Rows ${start[0] + 1}–${end[0]} · Columns ${start[1] + 1}–${end[1]} of ${format(size)} × ${format(size)}`;
      if (block.preview_size && block.preview_size < size) caption.textContent += " · Preview";
      caption.hidden = size <= 12;
    }
    function selectBlock() {
      const block = blocks[Number(select.value) || 0];
      const size = Number(block?.size || 0);
      entries = new Map((block?.entries || []).map(entry => [`${entry.row},${entry.col}`, entry]));
      sizeLabel.textContent = `${format(size)} × ${format(size)}`;
      inputs.forEach(({ input }) => { input.value = "1"; input.max = String(Math.max(1, size)); input.disabled = size <= 12 || Boolean(block?.preview_size); });
      drawMatrix();
    }
    select.addEventListener("change", selectBlock);
    inputs.forEach(({ input }) => input.addEventListener("change", drawMatrix));
    const detailsPanel = node("div", "panel details-panel");
    function details(label, values, renderRow, open = false, fullCount = values.length) {
      const section = node("details"); section.open = open;
      const total = Math.max(values.length, Number(fullCount) || 0);
      const heading = node("summary"); heading.append(node("span", "", label), node("span", "details-count", format(total))); section.append(heading);
      const list = node("div", "relations-list");
      let rendered = false;
      function renderValues() {
        if (rendered || !section.open) return;
        if (!values.length) list.append(node("p", "helper prepared-empty", "None."));
        values.slice(0, 100).forEach((value, index) => list.append(renderRow(value, index)));
        rendered = true;
      }
      section.addEventListener("toggle", renderValues);
      renderValues();
      section.append(list);
      if (total > values.length) section.append(node("p", "helper", `First ${format(Math.min(100, values.length))} of ${format(total)} shown.`));
      else if (values.length > 100) section.append(node("p", "helper", "First 100 shown. Download the exact JSON for the complete list."));
      detailsPanel.append(section);
      return section;
    }
    const constraintInputs = prepared.config?.fixed_observables || [];
    const fixedInputs = constraintInputs.filter(input => !input.relation || input.relation === "=");
    const inequalityInputs = constraintInputs.filter(input => ["<=", ">="].includes(input.relation));
    const observableConstraints = [
      ...(prepared.fixed_observables || []).map((observable, index) => ({ ...observable, input: fixedInputs[index] })),
      ...(prepared.observable_inequalities || []).map((observable, index) => ({ ...observable, input: inequalityInputs[index] })),
    ];
    details("Observable constraints", observableConstraints, observable => {
      const row = node("div", "relation-row");
      if (observable.name) row.append(SolverNotation.render(observable.name), SolverNotation.render("="));
      const input = observable.input;
      const physical = input?.terms ? definitionLatex(input.terms, result.model.species) : undefined;
      row.append(expression(physical ?? observable.latex, observable.expression), SolverNotation.render(relationLatex(observable.relation)), expression(observable.value_latex, observable.value)); return row;
    });
    details("Prepared variables", prepared.variables || [], variable => {
      const row = node("div", "relation-row"); row.append(expression(variable.latex, variable.name));
      if (variable.meaning_latex) row.append(SolverNotation.render("="), expression(variable.meaning_latex, variable.meaning));
      else if (variable.meaning) row.append(node("span", "helper", variable.meaning));
      return row;
    }, false, previewCounts.variables);
    details("Covariance trace words", prepared.covariance_words || [], word => {
      const row = node("div", "relation-row");
      row.append(Array.isArray(word.tokens) ? SolverNotation.render(SolverNotation.moment([word.tokens], result.model.species), word.text) : node("span", "", word.text || "")); return row;
    });
    details("Preparation equalities", prepared.equalities || [], equation => {
      const row = node("div", "relation-row"); row.append(expression(equation.latex, `${equation.expression || "0"} = 0`)); return row;
    }, false, previewCounts.equalities);
    const representative = Number(summary.removed_scalar_directions || 0) > 0;
    const reconstruction = details(representative ? "Representative reconstruction" : "Moment reconstruction", prepared.reconstruction || [], relation => {
      const row = node("div", "relation-row"); row.append(expression(null, relation.symbol), SolverNotation.render("="), expression(relation.latex, relation.expression)); return row;
    }, false, previewCounts.reconstruction);
    if (representative) {
      reconstruction.append(node("p", "helper", "The displayed reconstruction selects a representative. The full remaining freedom is included in reconstruction_nullspace in the exported JSON."));
    }
    if (loopEquations) detailsPanel.append(loopEquations);
    container.replaceChildren(heading, note, ...(objectiveNote ? [objectiveNote] : []), ...(cutoffNote ? [cutoffNote] : []), stats, matrixPanel, detailsPanel);
    selectBlock();
  }

  return Object.freeze({ emptyConfig, validateConfig, create, renderResult });
})();
