"""Exact affine equalities and common-kernel compression of real PSD blocks."""

from collections import deque
from functools import lru_cache

import sympy as sp

from .affine_data import AffineMatrix, AffineRow, AffineRows


def _variables(values):
    variables = tuple(values)
    if (any(not isinstance(value, sp.Symbol) or value.is_real is False for value in variables)
            or len(set(variables)) != len(variables)):
        raise ValueError("Affine variables must be distinct real symbols.")
    return variables


@lru_cache(maxsize=32768)
def _simplify_number(value):
    return sp.simplify(value)


def _validated_number(value):
    """Check an already-normalized exact number without simplifying it again."""
    value = sp.sympify(value)
    if value == 0:
        return sp.S.Zero
    if (value.has(sp.Float) or value.is_number is not True or value.is_real is not True
            or value.is_finite is not True):
        raise ValueError("Affine coefficients must be finite exact real numbers.")
    if value.is_zero is not False:
        raise ValueError("A coefficient could not be certified as nonzero exactly.")
    return value


def _clean(value):
    value = sp.sympify(value)
    if not value.is_Rational:
        value = _simplify_number(value)
    return _validated_number(value)


class _AffineTerms:
    def __init__(self, variables, check, *, normalize=True, cleaner=None):
        self.indices = {variable: index for index, variable in enumerate(variables)}
        self.constant = len(variables)
        self.check = check
        self.normalize = normalize
        self.cleaner = cleaner
        self.cache = {}

    def with_check(self, check):
        """Share exact rows while using the current operation's cancellation check.

        A deadline applies inside first-time coefficient extraction as well as
        between entries. Do not replace the original extractor's callback:
        callers may keep using it after this operation has finished.
        """
        other = _AffineTerms(tuple(self.indices), check,
                             normalize=self.normalize, cleaner=self.cleaner)
        other.cache = self.cache
        return other

    def reindexed(self, variables, check=None):
        """Transfer certified rows to another ordering without extracting again.

        Extending the variable list moves the constant column. Removing an
        actually used variable is an error; no coefficient is silently lost.
        """
        _require_exact_terms(self, tuple(self.indices))
        variables = _variables(variables)
        other = _AffineTerms(variables, self.check if check is None else check)
        columns = {index: other.indices.get(symbol) for symbol, index in self.indices.items()}
        columns[self.constant] = other.constant
        for expression, row in self.cache.items():
            other.check()
            mapped = {}
            for index, coefficient in row.items():
                other.check()
                column = columns[index]
                if column is None:
                    raise ValueError("An affine expression contains an unknown variable.")
                mapped[column] = coefficient
            other.cache[expression] = mapped
        return other

    def __call__(self, expression):
        self.check()
        if isinstance(expression, AffineRow):
            if expression in self.cache:
                return self.cache[expression]
            result = {}
            for symbol, coefficient in expression.items():
                self.check()
                if symbol is not None and symbol not in self.indices:
                    raise ValueError("An affine expression contains an unknown variable.")
                result[self.constant if symbol is None else self.indices[symbol]] = coefficient
            self.cache[expression] = result
            return result
        expression = sp.sympify(expression)
        if expression in self.cache:
            return self.cache[expression]
        if expression.has(sp.Float):
            raise ValueError("Affine expressions must use exact numbers, not floating-point values.")
        expanded = sp.expand(expression)
        if expanded.free_symbols - self.indices.keys():
            raise ValueError("An affine expression contains an unknown variable.")
        result = {}
        for term in sp.Add.make_args(expanded):
            self.check()
            present = term.free_symbols
            if not present:
                index, coefficient = self.constant, term
            elif len(present) == 1:
                variable = next(iter(present))
                coefficient, monomial = term.as_independent(variable, as_Add=False)
                if monomial != variable:
                    raise ValueError("An expression is not affine in the selected variables.")
                index = self.indices[variable]
            else:
                raise ValueError("An expression is not affine in the selected variables.")
            result[index] = result.get(index, sp.S.Zero) + coefficient
        if self.normalize:
            clean = _clean if self.cleaner is None else self.cleaner
            result = {index: coefficient for index, value in result.items()
                      if (coefficient := clean(value)) != 0}
        else:
            # Already-validated pencils only need coefficient extraction.
            result = {index: value for index, value in result.items() if value != 0}
        self.cache[expression] = result
        return result

    def seed(self, expression, coefficients, *, normalized=False):
        """Certify a restored symbolic coefficient map before reusing it.

        Keys are the actual symbols, with ``None`` denoting the constant.
        Reconstructing the affine expression checks the map without walking
        each term of a long expression again. This is deliberately separate
        from accepting an arbitrary prepopulated cache.

        ``normalized=True`` is reserved for coefficient rows whose numbers
        were normalized before persistence. Exact-number and reconstruction
        checks still run; only repeated number simplification is omitted.
        """
        self.check()
        _require_exact_terms(self, tuple(self.indices))
        native = isinstance(expression, AffineRow)
        if not native:
            expression = sp.sympify(expression)
        if not native and expression.has(sp.Float):
            raise ValueError("Affine expressions must use exact numbers, not floating-point values.")
        if expression.free_symbols - self.indices.keys():
            raise ValueError("An affine expression contains an unknown variable.")
        row = {}
        for symbol, coefficient in coefficients.items():
            self.check()
            if symbol is not None and symbol not in self.indices:
                raise ValueError("An affine coefficient map contains an unknown variable.")
            value = (_validated_number if normalized else _clean)(coefficient)
            if value != 0:
                row[self.constant if symbol is None else self.indices[symbol]] = value
        if native:
            original = self(expression)
            if any(_clean(row.get(index, sp.S.Zero) - original.get(index, sp.S.Zero)) != 0
                   for index in row.keys() | original.keys()):
                raise ValueError("An affine coefficient map does not reconstruct its expression.")
        else:
            rebuilt = _expression_from_row(row, tuple(self.indices))
            if expression != rebuilt and sp.expand(expression - rebuilt) != 0:
                raise ValueError("An affine coefficient map does not reconstruct its expression.")
        self.check()
        self.cache[expression] = row
        return row


def _require_exact_terms(terms, variables):
    if (not isinstance(terms, _AffineTerms)
            or terms.indices != {variable: index for index, variable in enumerate(variables)}
            or terms.constant != len(variables)
            or terms.normalize is not True
            or terms.cleaner is not None):
        raise ValueError("Shared PSD coefficients require matching ordered variables and exact validation.")
    return terms


def _expression_from_row(row, variables):
    """Build expanded affine text without expanding a substituted long sum."""
    constant = len(variables)
    return sp.Add(*(part if index == constant else part * variables[index]
                    for index, coefficient in row.items()
                    for part in sp.Add.make_args(coefficient)))


class AffineSubstitution:
    """Apply simultaneous affine substitutions through exact coefficient rows.

    The replacements are compiled once. Each distinct source entry is composed
    once, and its certified target coefficients remain available for subsequent
    kernel compression and scalar-coordinate selection.
    """

    def __init__(self, variables, remaining, substitutions, *, source_terms=None,
                 target_terms=None, check=lambda: None):
        self.check = check
        check()
        variables, self.remaining = _variables(variables), _variables(remaining)
        self.source_terms = (_AffineTerms(variables, check) if source_terms is None else
                             _require_exact_terms(source_terms, variables))
        self.target_terms = (_AffineTerms(self.remaining, check) if target_terms is None else
                             _require_exact_terms(target_terms, self.remaining))
        if set(substitutions) - set(variables):
            raise ValueError("An affine substitution contains an unknown source variable.")
        self.replacements = []
        self.changed_symbols = set()
        self.identity_targets = {}
        for source, variable in enumerate(variables):
            check()
            replacement = substitutions.get(variable, variable)
            row = self.target_terms(replacement)
            self.replacements.append(row)
            if variable not in self.target_terms.indices or row != {self.target_terms.indices[variable]: sp.S.One}:
                self.changed_symbols.add(variable)
            else:
                self.identity_targets[source] = self.target_terms.indices[variable]
        self.replacements.append({len(self.remaining): sp.S.One})
        self.identity_targets[len(variables)] = len(self.remaining)
        self.normalized = {coefficient: coefficient
                           for terms in (self.source_terms, self.target_terms)
                           for row in terms.cache.values() for coefficient in row.values()}
        self.row_factory = AffineRows(self.remaining, check=check)
        self.cache = {}

    def __call__(self, expression):
        self.check()
        native = isinstance(expression, AffineRow)
        if not native:
            expression = sp.sympify(expression)
        if expression in self.cache:
            return self.cache[expression]
        if native and not expression.free_symbols.intersection(self.changed_symbols):
            # Validate source/target scopes while retaining the already-certified
            # row. Large exact coefficients need no additions or multiplication.
            self.source_terms(expression)
            self.target_terms(expression)
            self.cache[expression] = expression
            return expression
        combined = {}
        source_row = self.source_terms(expression)
        # First-seen source entries may have been extracted after construction;
        # their rows have already passed the default exact normalization.
        for coefficient in source_row.values():
            self.normalized.setdefault(coefficient, coefficient)
        combined = {self.identity_targets[source]: coefficient for source, coefficient in source_row.items()
                    if source in self.identity_targets}
        for source, coefficient in source_row.items():
            self.check()
            if source in self.identity_targets:
                continue
            for target, value in self.replacements[source].items():
                self.check()
                combined[target] = combined.get(target, sp.S.Zero) + coefficient * value
        row = {}
        for index, value in combined.items():
            self.check()
            if value not in self.normalized:
                self.normalized[value] = _clean(value)
                coefficient = self.normalized[value]
                self.normalized.setdefault(coefficient, coefficient)
            else:
                coefficient = self.normalized[value]
            if coefficient != 0:
                row[index] = coefficient
        if native:
            result = self.row_factory.from_coefficients(
                {None if index == len(self.remaining) else self.remaining[index]: coefficient
                 for index, coefficient in row.items()}, normalized=True)
        else:
            result = _expression_from_row(row, self.remaining)
        # The exact affine expression was just constructed from this row; no
        # second extraction or external-map certification is necessary.
        self.target_terms.cache[result] = row
        self.cache[expression] = result
        self.check()
        return result


def _symmetric_entries(matrix, terms, check):
    entries = matrix.todok()
    for (row, column), value in entries.items():
        check()
        transpose_value = entries.get((column, row), sp.S.Zero)
        if value != transpose_value:
            # Expanded and factored forms can have identical certified rows.
            # Reuse those rows before constructing and expanding a long sum.
            left, right = terms.cache.get(value), terms.cache.get(transpose_value)
            if left is not None and right is not None and left == right:
                continue
            if isinstance(matrix, AffineMatrix):
                left, right = terms(value), terms(transpose_value)
                for index in left.keys() | right.keys():
                    check()
                    if _clean(left.get(index, sp.S.Zero) - right.get(index, sp.S.Zero)) != 0:
                        raise ValueError("A PSD block must be symmetric.")
                continue
            if terms(value - transpose_value):
                raise ValueError("A PSD block must be symmetric.")
    return entries


class _RowBasis:
    """Stream sparse rows into an exact echelon basis; store only the rank."""

    def __init__(self, check):
        self.rows = {}
        self.check = check

    def _subtract(self, row, pivot, source):
        factor = row.pop(pivot, sp.S.Zero)
        if factor == 0:
            return
        for column, value in source.items():
            self.check()
            if column == pivot:
                continue
            value = _clean(row.get(column, sp.S.Zero) - factor * value)
            if value == 0:
                row.pop(column, None)
            else:
                row[column] = value

    def add(self, values):
        self.check()
        row = dict(values)
        for pivot in sorted(self.rows):
            self.check()
            self._subtract(row, pivot, self.rows[pivot])
        if not row:
            return None
        pivot = min(row)
        scale = row[pivot]
        normalized = {}
        for column, value in row.items():
            self.check()
            normalized[column] = _clean(value / scale)
        self.rows[pivot] = normalized
        return pivot

    def reduced(self):
        rows = {pivot: dict(row) for pivot, row in self.rows.items()}
        pivots = sorted(rows)
        for offset in range(len(pivots) - 1, -1, -1):
            pivot = pivots[offset]
            for earlier in pivots[:offset]:
                self.check()
                self._subtract(rows[earlier], pivot, rows[pivot])
        return rows


def solve_affine_equalities(expressions, variables, check=lambda: None, *, row_factory=None):
    """Solve expressions equal to zero, preferring pivots in variable order.

    Returned substitutions contain only solved variables and are simultaneous:
    each right-hand side depends exclusively on unsolved original variables.
    """
    check()
    variables = _variables(variables)
    terms = _AffineTerms(variables, check)
    basis = _RowBasis(check)
    for expression in expressions:
        check()
        pivot = basis.add(terms(expression))
        if pivot == len(variables):
            raise ValueError("The affine equalities are inconsistent.")
    reduced = basis.reduced()
    substitutions = {}
    for pivot in sorted(reduced):
        check()
        row = reduced[pivot]
        if row_factory is not None:
            substitutions[variables[pivot]] = row_factory.from_coefficients(
                {None if column == len(variables) else variables[column]: -coefficient
                 for column, coefficient in row.items() if column != pivot})
            continue
        value = -row.get(len(variables), sp.S.Zero)
        for column, coefficient in row.items():
            if column != pivot and column < len(variables):
                value -= coefficient * variables[column]
        substitutions[variables[pivot]] = sp.expand(value)
    check()
    return substitutions, len(reduced)


def _coefficient_rows(entries_by_row, terms, variables, check):
    labels = (*map(str, variables), None)
    for index, entries in enumerate(entries_by_row):
        check()
        rows = {}
        for column, expression in entries.items():
            for coefficient, value in terms(expression).items():
                rows.setdefault(coefficient, {})[column] = value
        for coefficient in sorted(rows):
            yield (index, labels[coefficient]), rows[coefficient]


def _singleton_full_column_rank(rows, size, check):
    """Certify full column rank from singleton supports in linear work.

    A row with just one nonzero coefficient forces that kernel component to
    vanish. Removing a proved-zero component can expose another such row.
    This is an exact proof, not a numerical rank estimate. An incomplete proof
    returns False and leaves every input row untouched for the usual RREF.
    """
    check()
    if type(size) is not int or size < 0:
        return False
    certified = {}

    def nonzero(value):
        value = sp.sympify(value)
        if value not in certified:
            certified[value] = (not value.has(sp.Float) and value.is_number is True
                and value.is_real is True and value.is_finite is True and value.is_zero is False)
        return certified[value]

    known = set()
    for row in rows:
        check()
        # Do not let the fast path bypass matrix-coordinate validation. Invalid
        # coordinates retain the existing sparse-matrix error path below.
        for offset, column in enumerate(row):
            if offset % 256 == 0:
                check()
            if type(column) is not int or not 0 <= column < size:
                return False
        if len(row) == 1:
            column, value = next(iter(row.items()))
            if nonzero(value):
                known.add(column)
    if len(known) == size:
        return True

    # Counts and XOR recover the sole remaining column without copying each
    # sparse row into a mutable set. Each nonzero incidence is visited once
    # when constructed and once when its column is removed.
    counts, columns = [], []
    containing = [[] for _ in range(size)]
    queue = deque(sorted(known))
    for index, row in enumerate(rows):
        check()
        count = column_xor = 0
        for offset, (column, value) in enumerate(row.items()):
            if offset % 256 == 0:
                check()
            if value == 0:
                continue
            count += 1
            column_xor ^= column
            containing[column].append(index)
        counts.append(count)
        columns.append(column_xor)
        if count == 1 and column_xor not in known and nonzero(row[column_xor]):
            known.add(column_xor)
            queue.append(column_xor)
    while queue:
        check()
        if len(known) == size:
            return True
        column = queue.popleft()
        for offset, index in enumerate(containing[column]):
            if offset % 256 == 0:
                check()
            counts[index] -= 1
            columns[index] ^= column
            remaining = columns[index]
            if counts[index] == 1 and remaining not in known and nonzero(rows[index][remaining]):
                known.add(remaining)
                queue.append(remaining)
    return False


def _kernel_vectors(rows, size, check):
    check()
    if _singleton_full_column_rank(rows, size, check):
        check()
        return tuple(range(size)), ()
    matrix = sp.MutableSparseMatrix(len(rows), size,
        {(i, j): value for i, row in enumerate(rows) for j, value in row.items()})
    reduced, pivots = matrix.to_DM().to_sparse().rref()
    reduced = reduced.to_Matrix()
    check()
    kept = tuple(pivots)
    vectors = []
    for free in range(size):
        check()
        if free in kept:
            continue
        values = {(free, 0): sp.S.One}
        for row, pivot in enumerate(kept):
            if reduced[row, free] != 0:
                values[pivot, 0] = -reduced[row, free]
        vectors.append(sp.ImmutableSparseMatrix(size, 1, values))
    return kept, tuple(vectors)


def _numerical_row_plan(rows, size, check):
    """Propose a row basis numerically; removal still requires exact certification."""
    import numpy as np
    from scipy import linalg

    check()
    full = {"rank": size, "rows": []}
    if not rows or size == 0:
        return {"rank": 0, "rows": []}
    numeric = np.zeros((len(rows), size))
    for i, (_, row) in enumerate(rows):
        check()
        try:
            for j, value in row.items():
                numeric[i, j] = float(value)
        except (OverflowError, ValueError):
            return full
    if not np.isfinite(numeric).all():
        return full
    scales = np.max(np.abs(numeric), axis=1)
    numeric /= np.where(scales > 0, scales, 1)[:, None]
    try:
        singular = linalg.svdvals(numeric, check_finite=False)
    except (ValueError, np.linalg.LinAlgError):
        return full
    tolerance = max(numeric.shape) * np.finfo(float).eps * (singular[0] if singular.size else 0)
    rank = int(np.count_nonzero(singular > tolerance))
    check()
    if rank == size:
        return full
    if rank == 0:
        return {"rank": 0, "rows": []}
    try:
        _, _, order = linalg.qr(numeric.T, mode="economic", pivoting=True, check_finite=False)
    except (ValueError, np.linalg.LinAlgError):
        return full
    check()
    return {"rank": rank, "rows": [list(rows[int(i)][0]) for i in order[:rank]]}


def _valid_row_plan(plan, size):
    if not isinstance(plan, dict) or set(plan) != {"rank", "rows"}:
        return False
    rank, rows = plan["rank"], plan["rows"]
    if type(rank) is not int or not 0 <= rank <= size or not isinstance(rows, list):
        return False
    if rank == size:
        return rows == []
    if len(rows) != rank:
        return False
    if not all(isinstance(row, (list, tuple)) and len(row) == 2
               and type(row[0]) is int and 0 <= row[0] < size
               and (row[1] is None or isinstance(row[1], str)) for row in rows):
        return False
    return len({tuple(row) for row in rows}) == len(rows)


def _certify_kernel(entries_by_row, terms, variables, vectors, check):
    if not vectors:
        return True
    sparse_vectors = [{i: value for (i, _), value in vector.todok().items()} for vector in vectors]
    for _, row in _coefficient_rows(entries_by_row, terms, variables, check):
        for vector in sparse_vectors:
            check()
            residual = sum((value * vector[column] for column, value in row.items() if column in vector), sp.S.Zero)
            if _clean(residual) != 0:
                return False
    return True


def compress_psd_block(matrix, variables, check=lambda: None, *, row_plan=None, plan_callback=None,
                       coefficient_terms=None):
    """Certify a numerically proposed reduction, preserving its size across scans.

    Later points only test the cached selection. They never search for extra
    null directions. A failed certificate keeps the full block and leaves the
    baseline plan unchanged, so no valid PSD condition can be lost.

    A preparation may share one exact coefficient extractor across its blocks.
    Its expression cache then avoids repeating affine validation and extraction
    for identical entries, including when a cached plan retains the full block.
    First-seen entries and matrix symmetry are still checked on every call.
    """
    check()
    variables = _variables(variables)
    if not isinstance(matrix, AffineMatrix):
        matrix = sp.ImmutableSparseMatrix(matrix)
    if matrix.rows != matrix.cols:
        raise ValueError("A PSD block must be square.")
    size = matrix.rows
    if coefficient_terms is None:
        terms = _AffineTerms(variables, check)
    else:
        terms = _require_exact_terms(coefficient_terms, variables)
    entries_by_row = [{} for _ in range(size)]
    for (row, column), value in _symmetric_entries(matrix, terms, check).items():
        check()
        terms(value)
        entries_by_row[row][column] = value

    cached = _valid_row_plan(row_plan, size)
    plan = row_plan
    rows = None
    if not cached:
        rows = list(_coefficient_rows(entries_by_row, terms, variables, check))
        plan = _numerical_row_plan(rows, size, check)
    kept, nullspace = tuple(range(size)), ()
    certified = plan["rank"] == size
    if not certified:
        wanted = {tuple(label) for label in plan["rows"]}
        available = {label: row for label, row in
                     (rows if rows is not None else _coefficient_rows(entries_by_row, terms, variables, check))
                     if label in wanted}
        candidate_kept, candidate_nullspace = _kernel_vectors(
            [available.get(tuple(label), {}) for label in plan["rows"]], size, check)
        certified = (len(candidate_kept) == plan["rank"] and
                     _certify_kernel(entries_by_row, terms, variables, candidate_nullspace, check))
        if certified:
            kept, nullspace = candidate_kept, candidate_nullspace
        elif not cached:
            plan = {"rank": size, "rows": []}

    check()
    if plan_callback is not None:
        plan_callback(plan, cached and certified)
    return {"matrix": matrix if len(kept) == size else matrix.extract(kept, kept),
            "kept_indices": kept, "nullspace": nullspace,
            "original_size": size, "removed_nullity": len(nullspace)}
