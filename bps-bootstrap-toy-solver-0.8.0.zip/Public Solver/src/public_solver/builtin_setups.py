"""Packaged physics presets, kept separate from editable personal setups."""

from copy import deepcopy
from importlib.resources import files
import json

from .setups import SetupStore, _config

PRESETS = (("half-bps", "Half BPS"), ("quarter-bps", "Quarter BPS"),
           ("eighth-bps", "Eighth BPS"), ("bmn", "BMN"))


class SetupCatalog:
    def __init__(self, directory):
        self.saved = SetupStore(directory)
        self.builtins = {}
        for key, name in PRESETS:
            config = json.loads(files("public_solver").joinpath("presets", f"{key}.json").read_text(encoding="utf-8"))
            record = {"id": f"builtin-{key}", "name": name, "built_in": True,
                      "config": _config(config)}
            self.builtins[record["id"]] = record

    def list(self):
        return [{key: record[key] for key in ("id", "name", "built_in")}
                for record in self.builtins.values()] + self.saved.list()

    def get(self, setup_id):
        if isinstance(setup_id, str) and setup_id in self.builtins:
            return deepcopy(self.builtins[setup_id])
        return self.saved.get(setup_id)

    def save(self, name, config):
        return self.saved.save(name, config)
