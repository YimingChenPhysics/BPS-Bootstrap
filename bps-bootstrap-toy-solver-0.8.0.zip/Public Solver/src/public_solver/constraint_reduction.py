"""Exact staged linear reduction, independent of fixed observables and objectives."""

import ast

import sympy as sp

from .affine import _AffineTerms
from .build_cache import stable_digest


REDUCTION_VERSION = "constraint-families-v1"
FAMILY_ORDER = ("symmetry", "gauge", "supercharge")
FAMILY_LABELS = {"symmetry": "Symmetry", "gauge": "Gauge", "supercharge": "Supercharge / matrix-relation"}
INCONSISTENT = "These constraints are inconsistent with normalization and the selected moment assumptions."


def _reduce_rows(expressions, symbols, check):
    """Extract pivot relations from stored sparse entries, in fixed column order."""
    check()
    if not expressions:
        return {}
    if not symbols:
        raise ValueError(INCONSISTENT)
    a, b = sp.linear_eq_to_matrix(expressions, symbols)
    reduced, pivots = a.row_join(b).to_DM().to_sparse().rref(method="GJ")
    check()
    if len(symbols) in pivots:
        raise ValueError(INCONSISTENT)
    substitutions = {}
    convert = reduced.domain.to_sympy
    for row_index, pivot in enumerate(pivots):
        check()
        row = reduced.rep.get(row_index, {})
        substitutions[symbols[pivot]] = sp.expand(sp.Add(
            convert(row.get(len(symbols), reduced.domain.zero)),
            *(-convert(row[j]) * symbols[j] for j in sorted(row)
              if j != pivot and j < len(symbols))))
    return substitutions


def _is_zero(value, check=lambda: None):
    check()
    value = sp.expand(value)
    if value == 0:
        return True
    # The residual is affine. Check its exact scalar coefficients rather than
    # asking a general simplifier to manipulate all moment variables at once.
    symbols = tuple(sorted(value.free_symbols, key=str))
    return not _AffineTerms(symbols, check)(value)


def _verify(expressions, substitutions, check):
    seen, verified = set(), {sp.S.Zero}
    for expression in expressions:
        check()
        if expression in seen or -expression in seen:
            continue
        seen.add(expression)
        residual = sp.expand(expression.xreplace(substitutions))
        if residual in verified or -residual in verified:
            continue
        if not _is_zero(residual, check):
            raise ArithmeticError("Constraint reconstruction failed.")
        verified.add(residual)


def _parse_checkpoint_expression(source, locals_):
    """Build long saved sums once, avoiding repeated incremental Add expansion."""
    if len(source) < 256:
        return sp.sympify(source, locals=locals_)
    try:
        root = ast.parse(source, mode="eval").body
    except (SyntaxError, RecursionError):
        return sp.sympify(source, locals=locals_)
    encoded = source.encode("utf-8")
    line_offsets = [0]
    for line in encoded.splitlines(keepends=True):
        line_offsets.append(line_offsets[-1] + len(line))
    pending, terms = [(root, 1)], []
    while pending:
        node, sign = pending.pop()
        if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Sub)):
            pending.append((node.right, -sign if isinstance(node.op, ast.Sub) else sign))
            pending.append((node.left, sign))
        elif isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            pending.append((node.operand, -sign if isinstance(node.op, ast.USub) else sign))
        else:
            if node.end_lineno is None or node.end_col_offset is None:
                return sp.sympify(source, locals=locals_)
            start = line_offsets[node.lineno - 1] + node.col_offset
            end = line_offsets[node.end_lineno - 1] + node.end_col_offset
            term = encoded[start:end].decode("utf-8")
            terms.append(term if sign == 1 else f"-({term})")
    if len(terms) < 2:
        return sp.sympify(source, locals=locals_)
    name = "_checkpoint_add"
    while name in locals_:
        name += "_"
    return sp.sympify(f"{name}({','.join(terms)})", locals={**locals_, name: sp.Add})


def _restore(snapshot, symbols, previous, expressions, check, verify=False):
    """Validate a completed checkpoint before it can replace exact work."""
    if not isinstance(snapshot, dict) or not isinstance(snapshot.get("substitutions"), list):
        return None
    locals_ = {str(symbol): symbol for symbol in symbols}
    indices = {symbol: i for i, symbol in enumerate(symbols)}
    try:
        substitutions, parsed = {}, {}
        for row in snapshot["substitutions"]:
            check()
            if not isinstance(row, list) or len(row) != 2 or any(not isinstance(v, str) for v in row):
                return None
            name, value = row
            if name not in locals_ or locals_[name] in substitutions:
                return None
            symbol = locals_[name]
            if value not in parsed:
                parsed[value] = _parse_checkpoint_expression(value, locals_)
            expression = parsed[value]
            if (expression.has(sp.Float) or expression.free_symbols - indices.keys()
                    or any(indices[s] <= indices[symbol] for s in expression.free_symbols)):
                return None
            substitutions[symbol] = expression
        if (type(snapshot.get("rank")) is not int or snapshot["rank"] != len(substitutions)
                or previous.keys() - substitutions.keys()
                or any(value.free_symbols & substitutions.keys() for value in substitutions.values())):
            return None
        if verify:
            for symbol, value in previous.items():
                check()
                if not _is_zero(value.xreplace(substitutions) - substitutions[symbol], check):
                    return None
            _verify(expressions, substitutions, check)
    except (ValueError, TypeError, KeyError, AttributeError, ArithmeticError, sp.SympifyError):
        return None
    return substitutions


def reduce_linear_families(families, elimination_order, *, stage_cache=None,
                           progress=None, check_cancelled=None, verify_cached=False):
    """Reduce successive families with the same final pivots as stacked RREF.

    Every stage uses the original column priority. Composing its substitutions
    into earlier ones therefore gives the unique reduced row form for that
    priority, without choosing different free coordinates. Cache keys contain
    only exact equations, variable order and the reduction version.
    """
    check = check_cancelled or (lambda: None)
    notify = progress or (lambda _: None)
    check()
    families = {name: list(rows) for name, rows in families.items() if rows}
    free = set().union(*(row.free_symbols for rows in families.values() for row in rows))
    symbols = tuple(symbol for symbol in elimination_order if symbol in free)
    if len(set(symbols)) != len(symbols) or set(symbols) != free:
        raise ArithmeticError("The elimination order must include every constraint variable exactly once.")
    key = stable_digest({"reduction": REDUCTION_VERSION, "sympy": sp.__version__,
                         "variables": [str(symbol) for symbol in symbols]})
    substitutions = {}
    order = [name for name in FAMILY_ORDER if name in families]
    order += sorted(set(families) - set(order))
    for family in order:
        check()
        original = families[family]
        key = stable_digest({"parent": key, "family": family, "equations": [str(row) for row in original]})
        stage = "constraint_" + family
        label = FAMILY_LABELS.get(family, family)
        snapshot = stage_cache.get(stage, key) if stage_cache else None
        if snapshot is not None:
            notify({"stage": "constraints", "family": family, "phase": "restore",
                    "message": f"Loading the cached {label.lower()} reduction."})
        restored = _restore(snapshot, symbols, substitutions, original, check, verify_cached) if snapshot is not None else None
        if restored is not None:
            substitutions = restored
            notify({"stage": "constraints", "family": family, "phase": "complete", "cache": "hit",
                    "message": f"Reusing cached {label.lower()} reduction."})
            check()
            continue
        rows, seen = [], set()
        for expression in original:
            check()
            value = sp.expand(expression.xreplace(substitutions))
            if value == 0 or value in seen or -value in seen:
                continue
            seen.add(value)
            rows.append(value)
        present = set().union(*(row.free_symbols for row in rows))
        remaining = tuple(symbol for symbol in symbols if symbol in present)
        notify({"stage": "constraints", "family": family, "phase": "reduce", "cache": "miss",
                "message": f"Reducing {label.lower()} constraints exactly: {len(rows):,} equations, {len(remaining):,} variables."})
        added = _reduce_rows(rows, remaining, check)
        composed = {symbol: sp.expand(value.xreplace(added)) for symbol, value in substitutions.items()}
        composed.update(added)
        substitutions = {symbol: composed[symbol] for symbol in symbols if symbol in composed}
        notify({"stage": "constraints", "family": family, "phase": "verify",
                "message": f"Checking the {label.lower()} reduction exactly."})
        _verify(original, substitutions, check)
        check()
        if stage_cache:
            stage_cache.put(stage, key, {"rank": len(substitutions),
                "substitutions": [[str(symbol), str(value)] for symbol, value in substitutions.items()]})
        notify({"stage": "constraints", "family": family, "phase": "complete", "cache": "miss",
                "message": f"{label} reduction complete: {len(added):,} variables eliminated."})
        check()
    if verify_cached:
        notify({"stage": "constraints", "phase": "verify", "message": "Checking all system constraints exactly."})
        _verify((row for rows in families.values() for row in rows), substitutions, check)
    return substitutions, len(substitutions)
