"""Bounded browser previews, separate from the complete SDP used for solving."""

import math

import sympy as sp
from sympy.printing.precedence import precedence
from sympy.printing.str import StrPrinter

PREVIEW_ROWS = 100
PREVIEW_MATRIX_SIZE = 12
PREVIEW_EXPRESSION_LENGTH = 1000


class _AffineStrPrinter(StrPrinter):
    """Reuse affine term formatting without changing SymPy's text convention.

    SymPy orders an Add by constructing a dense exponent vector for every
    term. In an affine sum each vector has at most one nonzero element, so
    the generator's sort key supplies the same ordering directly. Coefficients
    follow the same factor decomposition and ordering used by ``as_terms``.
    Unsupported expressions use its ordinary printer.
    """

    def __init__(self):
        super().__init__()
        self._affine_keys = {}
        self._symbol_keys = {}
        self._term_text = {}
        self._number_values = {}

    def _number_value(self, value):
        # SymPy uses complex approximations only to break term-order ties.
        # Actual text still prints the original exact symbolic coefficients.
        if value not in self._number_values:
            self._number_values[value] = complex(value)
        return self._number_values[value]

    def _affine_key(self, term):
        if term in self._affine_keys:
            return self._affine_keys[term]
        key = None
        if not term.is_Add:
            rational, remainder = term.as_coeff_Mul()
            symbol, supported = None, True
            try:
                numeric = self._number_value(rational)
                for factor in sp.Mul.make_args(remainder):
                    if factor.is_number:
                        numeric *= self._number_value(factor)
                    elif isinstance(factor, sp.Symbol) and factor.is_commutative and symbol is None:
                        symbol = factor
                    else:
                        supported = False
                        break
            except (TypeError, ValueError, OverflowError):
                supported = False
            if supported:
                real, imaginary = numeric.real, numeric.imag
                if math.isfinite(real) and math.isfinite(imaginary):
                    coefficient = ((bool(imaginary), imaginary), (real, imaginary))
                    if symbol is not None:
                        if symbol not in self._symbol_keys:
                            self._symbol_keys[symbol] = sp.default_sort_key(symbol)
                        key = (0, self._symbol_keys[symbol], coefficient)
                    else:
                        key = (1, (), coefficient)
        self._affine_keys[term] = key
        return key

    def _as_ordered_terms(self, expr, order=None):
        # Preserve SymPy's special two-term order, for example ``1 - x``.
        if len(expr.args) <= 2 or order is not None or self.order is not None:
            return super()._as_ordered_terms(expr, order=order)
        keys = [self._affine_key(term) for term in expr.args]
        if any(key is None for key in keys):
            return super()._as_ordered_terms(expr, order=order)
        # Distinct symbols can have identical printed names but different
        # assumptions. Leave their generator tie-breaking to SymPy as well.
        symbols = expr.free_symbols
        if len({self._symbol_keys[symbol] for symbol in symbols}) != len(symbols):
            return super()._as_ordered_terms(expr, order=order)
        return [term for _key, term in sorted(zip(keys, expr.args), key=lambda pair: pair[0])]

    def _print_Add(self, expr, order=None):
        terms = self._as_ordered_terms(expr, order=order)
        prec = precedence(expr)
        pieces = []
        for term in terms:
            if term not in self._term_text:
                self._term_text[term] = self._print(term)
            text = self._term_text[term]
            if text.startswith("-") and not term.is_Add:
                sign, text = "-", text[1:]
            else:
                sign = "+"
            if precedence(term) < prec or term.is_Add:
                text = "(" + text + ")"
            pieces.extend((sign, text))
        sign = pieces.pop(0)
        return ("" if sign == "+" else sign) + " ".join(pieces)


class ExpressionRecords:
    """One exact text printer per explicit rendering boundary.

    Affine rows arrive already normalized. This class does no symbolic
    expansion or cross-stage reuse; markup belongs to the artifact renderer.
    """

    def __init__(self, check=lambda: None):
        self.check = check
        self._printer = _AffineStrPrinter()
        self._text = {}

    def text(self, value):
        self.check()
        value = sp.sympify(value)
        if value not in self._text:
            self._text[value] = self._printer.doprint(value)
        return self._text[value]



def expression_preview(row):
    from .affine_data import AffineRow
    value = row.get("expression", "")
    # Every distinct variable name must occur at least once in the rendered
    # sum. This lower bound can omit very large rows before reconstructing them.
    length = (sum(len(symbol.name) for symbol in value.free_symbols)
              if isinstance(value, AffineRow) else len(value))
    if length > PREVIEW_EXPRESSION_LENGTH:
        return {**row, "expression": "Long expression omitted",
                "latex": r"\text{Long expression omitted}", "preview_omitted": True}
    return row


def pack_prepared_display(result, setup):
    """Select bounded data before any exact row is reconstructed for display."""
    from .artifact import text_artifact
    display = {name: result[name] for name in
               ("model", "settings", "summary", "build_cache", "build_elapsed_seconds")}
    prepared = dict(result["preparation"])
    counts = dict(prepared.get("preview_counts", {}))
    for name in ("moment_reductions", "equalities", "reconstruction", "variables"):
        rows = prepared[name]
        counts.setdefault(name, len(rows))
        prepared[name] = [expression_preview(row) for row in rows[:PREVIEW_ROWS]]
    prepared["preview_counts"] = counts
    prepared.pop("scalar_coordinate_reduction", None)
    prepared.pop("affine_expressions", None)
    blocks = []
    for source in prepared["blocks"]:
        block = dict(source)
        size = min(PREVIEW_MATRIX_SIZE, block["size"])
        block["preview_size"] = size
        block["entries"] = [expression_preview(entry) for entry in block["entries"]
                            if entry["row"] < size and entry["col"] < size]
        for name in ("labels", "labels_latex", "kept_indices"):
            block[name] = block[name][:size]
        block.pop("nullspace", None)
        blocks.append(block)
    prepared["blocks"] = blocks
    display.update(preparation=prepared, setup=setup)
    display = text_artifact(display, preview_limit=PREVIEW_ROWS)
    prepared = display["preparation"]
    for name in ("moment_reductions", "equalities", "reconstruction", "variables"):
        prepared[name] = [expression_preview(row) for row in prepared[name]]
    for block in prepared["blocks"]:
        block["entries"] = [expression_preview(row) for row in block["entries"]]
    return display
