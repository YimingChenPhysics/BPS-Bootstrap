"""Certified removal of PSD blocks related by a basis permutation."""

from collections import Counter
from dataclasses import dataclass
from time import monotonic

import sympy as sp

from .affine import _AffineTerms, _require_exact_terms, _symmetric_entries, _variables
from .affine_data import AffineMatrix


_MAX_SEARCH_STEPS = 50_000


class _SearchLimit(Exception):
    pass


class _TimeLimit(Exception):
    pass


@dataclass(frozen=True)
class _Block:
    labels: tuple
    signatures: tuple
    fingerprint: tuple


def _block(matrix, terms, labels, check):
    if not isinstance(matrix, AffineMatrix):
        matrix = sp.ImmutableSparseMatrix(matrix)
    if matrix.rows != matrix.cols:
        raise ValueError("A PSD block must be square.")
    entries = {}
    for (row, column), value in _symmetric_entries(matrix, terms, check).items():
        check()
        signature = tuple(sorted(terms(value).items()))
        entries[row, column] = labels.setdefault(signature, len(labels))
    rows = []
    for row in range(matrix.rows):
        check()
        # Symmetry was certified above, so use one label for each undirected edge.
        rows.append(tuple(entries.get((min(row, column), max(row, column)), 0)
                          for column in range(matrix.cols)))
    rows = tuple(rows)
    signatures = []
    for i, row in enumerate(rows):
        check()
        signatures.append((rows[i][i], tuple(sorted(Counter(row).items()))))
    signatures = tuple(signatures)
    fingerprint = (matrix.rows, tuple(sorted(Counter(signatures).items())))
    check()
    return _Block(rows, signatures, fingerprint)


def _colors(left, right, check):
    """Refine both labeled graphs together so their color IDs agree."""
    signatures = left.signatures + right.signatures
    palette = {signature: i for i, signature in enumerate(sorted(set(signatures)))}
    colors = tuple(palette[signature] for signature in signatures)
    size = len(left.labels)
    while True:
        check()
        if Counter(colors[:size]) != Counter(colors[size:]):
            return None
        refined = []
        for offset, block in ((0, left), (size, right)):
            for i, row in enumerate(block.labels):
                check()
                neighbors = Counter((edge, colors[offset + j]) for j, edge in enumerate(row))
                refined.append((colors[offset + i], tuple(sorted(neighbors.items()))))
        palette = {signature: i for i, signature in enumerate(sorted(set(refined)))}
        following = tuple(palette[signature] for signature in refined)
        if len(set(following)) == len(set(colors)):
            return following[:size], following[size:]
        colors = following


def _search(left, right, colors, check):
    """Find a color-preserving permutation with a bounded, iterative search."""
    size = len(left.labels)
    left_colors, right_colors = colors
    classes = {}
    for index, color in enumerate(right_colors):
        classes.setdefault(color, []).append(index)
    assignment = [-1] * size
    used = set()
    for index, color in enumerate(left_colors):
        if len(classes[color]) == 1:
            assignment[index] = classes[color][0]
            used.add(assignment[index])
    steps = 0

    def tick():
        nonlocal steps
        check()
        steps += 1
        if steps > _MAX_SEARCH_STEPS:
            raise _SearchLimit

    def compatible(source, target):
        tick()
        for index, image in enumerate(assignment):
            if image != -1:
                tick()
                if left.labels[source][index] != right.labels[target][image]:
                    return False
        return True

    def choices():
        best = None
        for source, color in enumerate(left_colors):
            if assignment[source] != -1:
                continue
            targets = [target for target in classes[color]
                       if target not in used and compatible(source, target)]
            if best is None or len(targets) < len(best[1]):
                best = source, targets
            if len(targets) <= 1:
                break
        return best

    # A frame stores the assigned vertex, candidate images, and next alternative.
    stack = []
    while len(used) < size:
        check()
        source, targets = choices()
        if targets:
            assignment[source] = targets[0]
            used.add(targets[0])
            stack.append([source, targets, 1])
            continue
        while stack:
            check()
            source, targets, following = stack[-1]
            used.remove(assignment[source])
            assignment[source] = -1
            if following < len(targets):
                assignment[source] = targets[following]
                used.add(assignment[source])
                stack[-1][2] += 1
                break
            stack.pop()
        else:
            return None
    return tuple(assignment)


def _certified(left, right, permutation, check):
    if permutation is None or sorted(permutation) != list(range(len(left.labels))):
        return False
    # Labels are complete exact affine coefficient vectors, including constants.
    for i, row in enumerate(left.labels):
        check()
        for j, value in enumerate(row):
            check()
            if value != right.labels[permutation[i]][permutation[j]]:
                return False
    return True


def _permutation(left, right, check):
    check()
    if left.labels == right.labels:
        permutation = tuple(range(len(left.labels)))
    else:
        colors = _colors(left, right, check)
        if colors is None:
            return None
        try:
            permutation = _search(left, right, colors, check)
        except _SearchLimit:
            return None
    return permutation if _certified(left, right, permutation, check) else None


def deduplicate_psd_blocks(matrices, variables, *, check=lambda: None,
                           time_limit=None, on_timeout=lambda: None, coefficient_terms=None):
    """Return retained indices and exact simultaneous row/column permutations.

    Each certificate satisfies removed[i, j] == retained[p[i], p[j]] for every
    assignment of the supplied real variables. Variables are never renamed.
    Ambiguous searches exceeding the internal cap retain the block. Empty
    blocks are also retained so callers can preserve their existing audits.
    An optional time limit in seconds covers the whole reduction, including
    labeling and certification. On expiry, keep certified removals and retain
    every unfinished block. Cancellation always propagates to the caller.
    A shared exact extractor avoids repeating normalization in later stages;
    its variable ordering must match, and its cache survives a timed-out search.
    """
    check()
    deadline = None if time_limit is None else monotonic() + time_limit
    matrices = tuple(matrices)

    def check_budget():
        check()
        if deadline is not None and monotonic() >= deadline:
            raise _TimeLimit

    labels = {(): 0}
    groups, kept, certificates = {}, [], []
    try:
        check_budget()
        variables = _variables(variables)
        terms = (_AffineTerms(variables, check_budget) if coefficient_terms is None else
                 _require_exact_terms(coefficient_terms, variables).with_check(check_budget))
        for index, matrix in enumerate(matrices):
            check_budget()
            block = _block(matrix, terms, labels, check_budget)
            candidates = groups.setdefault(block.fingerprint, [])
            for retained_index, retained in candidates if block.labels else ():
                check_budget()
                permutation = _permutation(block, retained, check_budget)
                if permutation is not None:
                    certificates.append({"removed_index": index, "retained_index": retained_index,
                                         "permutation": list(permutation)})
                    break
            else:
                kept.append(index)
                candidates.append((index, block))
        check_budget()
    except _TimeLimit:
        # Only fully certified removals may be omitted, including when the
        # deadline interrupts verification of the current candidate.
        removed = {row["removed_index"] for row in certificates}
        kept = [index for index in range(len(matrices)) if index not in removed]
        check()
        on_timeout()
    check()
    return tuple(kept), tuple(certificates)
