"""Input validation for a real affine objective in physical trace notation."""

import sympy as sp

from .constraints import exact_coefficient


def validate_optimization(value, model, level):
    """Return a normalized objective, or None for a feasibility problem."""
    if value is None:
        return None
    if not isinstance(value, dict) or set(value) - {"mode", "objective"}:
        raise ValueError("Optimization contains a mode and, for minimize or maximize, an objective.")
    mode = value.get("mode", "feasibility")
    if not isinstance(mode, str) or mode not in {"feasibility", "minimize", "maximize"}:
        raise ValueError("Choose check feasibility, minimize, or maximize.")
    if mode == "feasibility":
        if "objective" in value:
            raise ValueError("A feasibility problem does not take an objective.")
        return None
    objective = value.get("objective")
    if not isinstance(objective, dict) or set(objective) - {"name", "terms"}:
        raise ValueError("The objective contains a name and trace terms.")
    name = objective.get("name", "")
    if not isinstance(name, str) or len(name) > 128 or any(ord(c) < 32 or c in '<>$' for c in name):
        raise ValueError("Use an objective name of at most 128 characters without $ delimiters.")
    name = name.strip() or "O"
    terms = objective.get("terms")
    if not isinstance(terms, list) or not 1 <= len(terms) <= 64:
        raise ValueError("The objective needs between 1 and 64 trace terms.")
    combined = {}
    for term in terms:
        if not isinstance(term, dict) or set(term) != {"coefficient", "word"}:
            raise ValueError("Each objective term contains coefficient and word.")
        if not isinstance(term["word"], list) or len(term["word"]) > 2 * level:
            raise ValueError("Objective trace words must have length at most 2ℓ.")
        word = model.validate_word(tuple(term["word"]))
        if model.parity(word) or any(model.charge(word)):
            raise ValueError("Each objective trace term must be bosonic and charge neutral.")
        coefficient = exact_coefficient(term["coefficient"])
        if coefficient.is_real is not True:
            raise ValueError("Objective coefficients must be real.")
        combined[word] = sp.expand(combined.get(word, 0) + coefficient)
    normalized = [{"coefficient": str(c), "word": list(w)} for w, c in combined.items() if c != 0]
    return {"mode": mode, "objective": {"name": name, "terms": normalized or [
        {"coefficient": "0", "word": []}]}}
