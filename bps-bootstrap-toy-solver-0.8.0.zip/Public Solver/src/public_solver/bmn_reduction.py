"""Pure BMN projection used once when compiling the unfixed model."""

from fractions import Fraction

import sympy as sp

from .bmn_irrep import _CHARGES, decompose_basis, project_blocks, validate_invariance
from .constraints import exact_coefficient
from .model import Model

REDUCTION_VERSION = "bmn-su3-cone-v1"
NULL_VERSION = "bmn-su3-before-coordinates-v2"


def bmn_species_mapping(model, feature="BMN SU(3) block reduction"):
    """Identify species by statistics/charges, never by their display names."""
    expected = {("fermion" if 4 <= i <= 6 else "boson", tuple(Fraction(str(v)) for v in q)): i
                for i, q in enumerate(_CHARGES, 1)}
    mapping = {i: expected.get((s.statistics, s.charges)) for i, s in enumerate(model.species, 1)}
    if len(mapping) != 7 or set(mapping.values()) != set(range(1, 8)):
        raise ValueError(f"{feature} requires the seven BMN letters and six charge columns from the BMN preset.")
    return mapping


def validate_bmn_setup(model, constraints):
    mapping = bmn_species_mapping(model)
    generators = []
    for row in constraints.get("symmetries", []):
        if row.get("kind") != "ward":
            continue
        terms = {}
        for term in row["terms"]:
            word = tuple(mapping[abs(t)] * (1 if t > 0 else -1) for t in term["word"])
            terms[word] = terms.get(word, 0) + exact_coefficient(term["coefficient"])
        generators.append({w: sp.expand(c) for w, c in terms.items() if sp.expand(c) != 0})
    for positive, negative in (((2, -1), (4, -5)), ((3, -2), (5, -6))):
        if not any(set(g) == {positive, negative} and sp.expand(g[positive]+g[negative]) == 0
                   for g in generators):
            raise ValueError("BMN SU(3) block reduction requires both SU(3) symmetry generators from the BMN preset.")
    return mapping


def build_moment_blocks(result, space, *, notify=lambda _: None, check=lambda: None):
    """Pure projection step owned by the complete compiled-model checkpoint.

    The representation-theory implementation consumes symbolic formulas at this
    algebra boundary; its output is compiled to exact rows immediately once.
    No separate projection/formula cache participates in point preparation.
    """
    from .affine_data import AffineMatrix
    mapping = validate_bmn_setup(Model.from_dict(result["model"]), result["constraints"]["config"])
    words = [tuple(mapping[abs(t)] * (1 if t > 0 else -1) for t in row["tokens"])
             for row in result["basis"]]
    expressions, entries = {}, {}
    for block in result["blocks"]:
        indices = block["basis_indices"]
        for entry in block["entries"]:
            check()
            value = space.parse(entry["expression"])
            if value not in expressions:
                expressions[value] = value.as_expr()
            entries[indices[entry["row"]], indices[entry["col"]]] = expressions[value]
    notify({"stage": "bmn_su3", "message": "Certifying exact SU(3) invariance of the BMN moment matrix."})
    certificate = validate_invariance(entries, words, check=check)
    notify({"stage": "bmn_su3", "message": "Constructing BMN SU(3) highest-weight blocks."})
    sectors = decompose_basis(words, check=check)
    projected = project_blocks(entries, sectors, check=check)
    matrices = [AffineMatrix(matrix.rows, matrix.cols,
        {position: space.rows.from_expr(value) for position, value in matrix.todok().items()})
        for matrix in projected]
    blocks = [(f"BMN SU(3) moment block {i + 1}", "moment", matrix,
               [f"v{j + 1}" for j in range(matrix.rows)],
               [f"v_{{{j + 1}}}" for j in range(matrix.rows)]) for i, matrix in enumerate(matrices)]
    info = {"enabled": True, "method": "Exact SU(3) highest-weight multiplicity blocks",
            "certificate": certificate, "coordinate_selection_unchanged": True,
            "sectors": [{key: sector[key] for key in ("grade", "weight", "irrep_dimension")}
                        for sector in sectors]}
    return blocks, info
