"""Exact leading N² graded brackets of normalized traces.

Commute the two strings past each other, keeping every contact. Reconstruct
color cycles using the same oscillator swaps, so further planar contacts are
retained. Index loops and output traces determine the large-N power. This
small indexed layer is independent of names, charges, and state constraints.
"""

from fractions import Fraction

from .canonical import Canonicalizer
from .model import Word
from .polynomial import Polynomial, add


def trace_bracket(canonical: Canonicalizer, left: Word, right: Word) -> Polynomial:
    model = canonical.model
    left, right = model.validate_word(left), model.validate_word(right)
    if not left or not right:
        return {}
    n, m = len(left), len(right)
    operators = tuple((t, i, (i + 1) % n) for i, t in enumerate(left)) + tuple(
        (t, n + i, n + (i + 1) % m) for i, t in enumerate(right))
    result: Polynomial = {}

    def signs(a, b):
        odd = model.parity((a[0],))
        mother = -1 if odd and model.parity((b[0],)) else 1
        contact = (1 if odd or a[0] < 0 else -1) if a[0] == -b[0] else 0
        return mother, contact

    def contract(ops, position):
        a, b = ops[position:position + 2]
        indices = {i for _, x, y in ops for i in (x, y)}
        parent = {i: i for i in indices}

        def find(i):
            while parent[i] != i:
                i = parent[i]
            return i

        for x, y in ((a[1], b[2]), (a[2], b[1])):
            parent[find(x)] = find(y)
        remaining = tuple((t, find(x), find(y)) for t, x, y in ops[:position] + ops[position + 2:])
        used = {i for _, x, y in remaining for i in (x, y)}
        loops = len({find(i) for i in indices} - used)
        return remaining, loops

    def assemble(ops, coefficient, contractions, loops):
        canonical.check_cancelled()
        # Make successive color-cycle followers adjacent. Moving an operator
        # uses actual oscillator swaps, not a sign-only permutation.
        start = 0
        factors = []
        while start < len(ops):
            end = start
            while ops[end][2] != ops[start][1]:
                follower = next((j for j in range(end + 1, len(ops))
                                 if ops[j][1] == ops[end][2]), None)
                if follower is None:
                    raise ArithmeticError("A contracted color cycle did not close.")
                if follower != end + 1:
                    position = follower - 1
                    mother, contact = signs(ops[position], ops[position + 1])
                    if contact:
                        daughter, extra = contract(ops, position)
                        assemble(daughter, coefficient * contact, contractions + 1, loops + extra)
                    swapped = ops[:position] + (ops[position + 1], ops[position]) + ops[position + 2:]
                    assemble(swapped, coefficient * mother, contractions, loops)
                    return
                end += 1
            factors.append(tuple(t for t, _, _ in ops[start:end + 1]))
            start = end + 1
        if len(factors) - contractions + loops == 0:
            add(result, canonical.product(tuple(factors)), Fraction(coefficient))

    # Telescoping GW = (-1)^(pG pW) WG + contact terms. The first term
    # cancels in the bracket; every emitted daughter is an exact insertion.
    ops = operators
    coefficient = 1
    for j in range(m):
        for position in range(n + j - 1, j - 1, -1):
            mother, contact = signs(ops[position], ops[position + 1])
            if contact:
                daughter, loops = contract(ops, position)
                assemble(daughter, coefficient * contact, 1, loops)
            ops = ops[:position] + (ops[position + 1], ops[position]) + ops[position + 2:]
            coefficient *= mother
    return result
