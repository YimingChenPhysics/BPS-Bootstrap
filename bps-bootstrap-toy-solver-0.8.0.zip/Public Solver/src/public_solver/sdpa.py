"""Discover and verify a native SDPA Multiprecision installation.

This checks the external tool with a small independent problem. It does not
solve a user's prepared SDP or install software.
"""

from decimal import Decimal, InvalidOperation, localcontext
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile


INSTALL_INSTRUCTION = ("Please ask your agent to install SDPA-GMP and make the sdpa_gmp command "
                       "available to this app, then return and click Check again.")
REPAIR_INSTRUCTION = ("Please ask your agent to repair the SDPA-GMP installation or its executable "
                      "setting, then return and click Check again.")

# Native form: minimize x, subject to x - 1 >= 0 and 2 - x >= 0.
_PROBLEM = "1\n2\n{1, 1}\n{1}\n0 1 1 1 1\n0 2 1 1 -2\n1 1 1 1 1\n1 2 1 1 -1\n"
_PARAMETERS = """100 maxIteration
1e-12 epsilonStar
10 lambdaStar
2 omegaStar
-100000 lowerBound
100000 upperBound
0.1 betaStar
0.2 betaBar
0.9 gammaStar
1e-12 epsilonDash
192 precision
%+90.75Fe xPrint
%+90.75Fe XPrint
%+90.75Fe YPrint
%+10.16e infPrint
"""


def _configured_executable(data_directory):
    configured = os.environ.get("SDPA_GMP_EXECUTABLE")
    settings = data_directory / "solver.json"
    if not configured and settings.exists():
        value = json.loads(settings.read_text(encoding="utf-8"))
        if not isinstance(value, dict) or set(value) - {"sdpa_executable"}:
            raise ValueError("solver.json must contain an sdpa_executable path.")
        configured = value.get("sdpa_executable")
        if "sdpa_executable" in value and (not isinstance(configured, str) or not configured.strip()):
            raise ValueError("The sdpa_executable setting must be a nonempty path.")
    if configured:
        candidate = Path(configured).expanduser()
        if not candidate.is_absolute():
            candidate = Path(shutil.which(configured) or data_directory / candidate)
        return candidate.resolve()
    for filename in ("sdpa_gmp", "sdpa_gmp.exe"):
        candidate = data_directory / "bin" / filename
        if candidate.exists():
            return candidate.resolve()
    discovered = shutil.which("sdpa_gmp")
    return Path(discovered).resolve() if discovered else None


def _run(command, directory, timeout):
    # Keep diagnostic output in a disposable file, not an unbounded memory buffer.
    with tempfile.TemporaryFile() as output:
        completed = subprocess.run(command, cwd=directory, stdin=subprocess.DEVNULL,
                                   stdout=output, stderr=subprocess.STDOUT, timeout=timeout, check=False)
        output.seek(0, os.SEEK_END)
        output.seek(max(0, output.tell() - 8192))
        text = output.read().decode("utf-8", errors="replace")
    if completed.returncode:
        raise ValueError(f"SDPA exited with code {completed.returncode}. {text.strip()[-1500:]}")
    return text


def _verify_result(text):
    if not re.search(r"^phase\.value\s*=\s*pdOPT\b", text, re.MULTILINE):
        raise ValueError("SDPA did not solve the installation test to optimality.")
    def number(pattern):
        found = re.search(pattern, text, re.MULTILINE)
        if found is None:
            raise ValueError("SDPA returned an incomplete installation-test result.")
        value = Decimal(found.group(1))
        if not value.is_finite():
            raise ValueError("SDPA returned non-finite installation-test values.")
        return value
    with localcontext() as context:
        context.prec = 90
        for label in ("objValPrimal", "objValDual"):
            value = number(r"^" + label + r"\s*=\s*(\S+)")
            if abs(value - 1) > Decimal("1e-8"):
                raise ValueError("SDPA returned an incorrect installation-test optimum.")
        x = number(r"^xVec\s*=\s*\{\s*([^\s,}]+)")
        if abs(x - 1) > Decimal("1e-8"):
            raise ValueError("SDPA returned an incorrect installation-test solution.")
        epsilon = number(r"^relative eps\s*=\s*(\S+)")
        if not 0 < epsilon <= Decimal(2) ** -192 * (1 + Decimal("1e-12")):
            raise ValueError("SDPA did not use the requested multiprecision arithmetic.")


def check_sdpa(data_directory):
    """Check fresh settings and run a disposable test; return a UI-ready status."""
    executable = None
    version = None
    try:
        executable = _configured_executable(Path(data_directory).resolve())
        if executable is None:
            return {"status": "missing", "message": "SDPA solver not installed.",
                    "instruction": INSTALL_INSTRUCTION}
        if not executable.is_file() or not os.access(executable, os.X_OK):
            raise ValueError(f"The selected SDPA executable is missing or cannot be run: {executable}")
        with tempfile.TemporaryDirectory(prefix="public-solver-sdpa-check-") as temporary:
            directory = Path(temporary)
            output = _run([str(executable), "--version"], directory, timeout=5)
            match = re.search(r"SDPA\s+(?:Multiprecision|GMP)\b[^\r\n]*", output, re.IGNORECASE)
            if match is None:
                raise ValueError("This executable is not SDPA Multiprecision. The native sdpa_gmp solver is required.")
            version = match.group(0).split(" start at ")[0].strip()
            (directory / "check.dat-s").write_text(_PROBLEM, encoding="ascii")
            (directory / "param.sdpa").write_text(_PARAMETERS, encoding="ascii")
            _run([str(executable), "-ds", "check.dat-s", "-o", "result.txt", "-p", "param.sdpa"],
                 directory, timeout=10)
            _verify_result((directory / "result.txt").read_text(encoding="utf-8"))
        return {"status": "ready", "message": "SDPA is installed and working.",
                "executable": str(executable), "version": version}
    except (OSError, ValueError, UnicodeError, InvalidOperation, subprocess.TimeoutExpired) as exc:
        details = "SDPA did not finish the installation check in time." if isinstance(exc, subprocess.TimeoutExpired) else str(exc)
        return {"status": "broken", "message": "SDPA installation needs attention.",
                "instruction": REPAIR_INSTRUCTION, "details": details,
                **({"executable": str(executable)} if executable is not None else {}),
                **({"version": version} if version else {})}
