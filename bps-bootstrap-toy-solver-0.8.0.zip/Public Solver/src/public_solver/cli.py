"""Installed entry point, local browser application, and batch generation."""

import argparse
from dataclasses import asdict
from pathlib import Path
import sys
import threading
import webbrowser

from .moments import BuildLimits
from .pipeline import build_request
from .storage import read_json, write_json


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="BPS Bootstrap: Toy Solver — local moment matrices and SDP solves.")
    parser.add_argument("--generate", type=Path, help="Generate from a request JSON without starting a browser.")
    parser.add_argument("--output", type=Path, default=Path("moment-matrix.json"), help="Batch result JSON.")
    parser.add_argument("--data-dir", type=Path, default=Path(".public-solver"), help="Build caches, saved setups, jobs and solve history.")
    parser.add_argument("--port", type=int, default=8769)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--max-basis-size", type=int, default=BuildLimits().max_basis_size,
                        help="Optional basis-word limit; no basis limit by default.")
    parser.add_argument("--max-selected-entries", type=int, default=BuildLimits().max_selected_entries,
                        help="Optional matrix-entry limit; no entry limit by default.")
    args = parser.parse_args(argv)
    try:
        limits = BuildLimits(args.max_basis_size, args.max_selected_entries)
        if args.generate is not None:
            request = read_json(args.generate)
            result = build_request(request, cache_path=args.data_dir / "cache" / "canonical.sqlite3", limits=limits)
            write_json(args.output, result)
            print(f"Saved {result['summary']['basis_size']} basis words in {result['summary']['block_count']} blocks to {args.output.resolve()}")
            return 0
        if not 0 <= args.port <= 65535:
            raise ValueError("Port must be between 0 and 65535.")
        from .server import create_server
        server = create_server(args.port, args.data_dir, limits)
    except (ValueError, OSError) as exc:
        parser.error(str(exc))
    url = f"http://127.0.0.1:{server.server_port}"
    print(f"BPS Bootstrap: Toy Solver: {url}", flush=True)
    print(f"Local cache and jobs: {args.data_dir.resolve()}", flush=True)
    print("Press Ctrl+C to stop.", flush=True)
    if not args.no_browser:
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.solves.close()
        server.jobs.close()
        server.server_close()
    return 0
