"""Exact BMN SU(3) moment-cone reduction in Public's creator convention.

Standard IDs 1,2,3 label scalar creators, 4,5,6 fermion creators, and 7 f.
Negative IDs annihilate. This module changes moment blocks, never coordinates.
"""

from collections import defaultdict
from collections.abc import Mapping

import sympy as sp


E1 = {1: (1, 2), -2: (-1, -1), 5: (-1, 4), -4: (1, -5)}
F1 = {2: (1, 1), -1: (-1, -2), 4: (-1, 5), -5: (1, -4)}
E2 = {2: (1, 3), -3: (-1, -2), 6: (-1, 5), -5: (1, -6)}
F2 = {3: (1, 2), -2: (-1, -3), 5: (-1, 6), -6: (1, -5)}
SU3_ROOTS = (("E1", E1, F1, (2, -1)), ("E2", E2, F2, (-1, 2)))
_HALF = sp.Rational(1, 2)
_CHARGES = (
    (1, 0, 0, 0, 0, 1), (0, 1, 0, 0, 0, 1), (0, 0, 1, 0, 0, 1),
    (-_HALF, _HALF, _HALF, _HALF, _HALF, 1),
    (_HALF, -_HALF, _HALF, _HALF, _HALF, 1),
    (_HALF, _HALF, -_HALF, _HALF, _HALF, 1), (0, 0, 0, 1, 1, 1),
)


def act_on_word(word, action):
    """Bosonic derivation: fermion signs are in the letter rules, not positions."""
    result = {}
    for index, token in enumerate(word):
        if token in action:
            coefficient, replacement = action[token]
            target = word[:index] + (replacement,) + word[index + 1:]
            result[target] = result.get(target, 0) + coefficient
            if result[target] == 0:
                del result[target]
    return result


def _basis_data(basis_tokens, charges, check):
    basis = tuple(tuple(word) for word in basis_tokens)
    if len(set(basis)) != len(basis):
        raise ValueError("SU(3) basis words must be unique.")
    if any(type(token) is not int or not 1 <= abs(token) <= 7 for word in basis for token in word):
        raise ValueError("BMN words require signed species IDs 1 through 7.")
    if charges is not None:
        charges = tuple(tuple(sp.sympify(q) for q in row) for row in charges)
        if len(charges) != len(basis) or any(len(row) != 6 or any(q.is_Rational is not True for q in row) for row in charges):
            raise ValueError("Provide six exact BMN charges per basis word.")
    spaces, dimensions, keys = defaultdict(list), defaultdict(int), []
    for index, word in enumerate(basis):
        check()
        charge = tuple(sum((_CHARGES[abs(t)-1][j] * (1 if t > 0 else -1) for t in word), sp.S.Zero)
                       for j in range(6))
        if charges is not None and charges[index] != charge:
            raise ValueError("BMN charges do not match the standard species mapping.")
        r1, r2, r3, j1, j2, bonus = charge
        grade = tuple(int(q) for q in (2*(r1+r2+r3), 2*j1, 2*j2, bonus))
        weight = (int(r2-r1), int(r3-r2))
        key = (grade, weight)
        spaces[key].append(index)
        dimensions[grade] += 1
        keys.append(key)
    return basis, spaces, dimensions, tuple(keys)


def action_submatrix(basis, source_indices, target_indices, action, *, check=lambda: None):
    targets = {basis[index]: row for row, index in enumerate(target_indices)}
    entries = {}
    for column, index in enumerate(source_indices):
        check()
        for word, coefficient in act_on_word(basis[index], action).items():
            if word not in targets:
                raise ValueError("The SU(3) action leaves its expected weight space.")
            entries[targets[word], column] = coefficient
    return sp.ImmutableSparseMatrix(len(target_indices), len(source_indices), entries)


def _joint_kernel(matrices, size):
    nonempty = [matrix for matrix in matrices if matrix.rows]
    if not nonempty:
        return sp.ImmutableSparseMatrix(sp.eye(size))
    stacked = sp.SparseMatrix.vstack(*nonempty)
    columns = stacked.to_DM().to_sparse().nullspace().to_Matrix().T
    entries = {}
    for column in range(columns.cols):
        first = next((columns[row, column] for row in range(size) if columns[row, column] != 0), None)
        if first is None:
            raise ArithmeticError("An SU(3) kernel basis contains a zero vector.")
        for row in range(size):
            if columns[row, column] != 0:
                entries[row, column] = sp.cancel(columns[row, column] / first)
    return sp.ImmutableSparseMatrix(size, columns.cols, entries)


def decompose_basis(basis_tokens, charges=None, *, check=lambda: None):
    """Return JSON-ready highest-weight sectors, in the supplied basis order.

    H rows correspond to global ``indices``; H columns retain every irrep copy.
    The commuting grade does not separate word lengths.
    """
    basis, spaces, dimensions, keys = _basis_data(basis_tokens, charges, check)
    indices = {word: index for index, word in enumerate(basis)}
    for index, word in enumerate(basis):
        check()
        grade, weight = keys[index]
        for _, raising, lowering, shift in SU3_ROOTS:
            for action, direction in ((raising, 1), (lowering, -1)):
                expected = (grade, tuple(q + direction*d for q, d in zip(weight, shift)))
                for target in act_on_word(word, action):
                    if target not in indices or keys[indices[target]] != expected:
                        raise ValueError("The BMN word basis is not closed under SU(3).")
    sectors, represented = [], defaultdict(int)
    for (grade, weight), source in sorted(spaces.items()):
        check()
        p, q = weight
        if p < 0 or q < 0:
            continue
        maps = [action_submatrix(basis, source, spaces.get((grade, tuple(v+d for v, d in zip(weight, shift))), ()),
                                 raising, check=check) for _, raising, _, shift in SU3_ROOTS]
        h = _joint_kernel(maps, len(source))
        if not h.cols:
            continue
        if any(matrix*h != sp.zeros(matrix.rows, h.cols) for matrix in maps):
            raise ArithmeticError("SU(3) highest-weight vectors failed exact certification.")
        dimension = (p+1)*(q+1)*(p+q+2)//2
        represented[grade] += dimension*h.cols
        sectors.append({"grade": list(grade), "weight": list(weight), "indices": list(source),
                        "irrep_dimension": dimension,
                        "H": {"rows": h.rows, "cols": h.cols,
                              "entries": [[i, j, str(value)] for (i, j), value in sorted(h.todok().items())]}})
    if dict(represented) != dict(dimensions):
        raise ArithmeticError("SU(3) multiplicities do not reconstruct every graded word space.")
    return tuple(sectors)


def moment_entries(blocks):
    """Normalize a global entry map or (global_indices, matrix) block pairs."""
    if isinstance(blocks, Mapping):
        return {position: sp.sympify(value) for position, value in blocks.items() if value != 0}
    entries, covered = {}, set()
    for indices, matrix in blocks:
        indices = tuple(indices)
        if matrix.shape != (len(indices), len(indices)) or len(set(indices)) != len(indices) or covered.intersection(indices):
            raise ValueError("Moment blocks must have disjoint, dimension-matched global indices.")
        covered.update(indices)
        entries.update({(indices[i], indices[j]): value for (i, j), value in matrix.todok().items() if value != 0})
    return entries


def _additive(expression, cache):
    if expression not in cache:
        cache[expression] = tuple(expression.as_coefficients_dict().items())
    return cache[expression]


def _combination(parts, cache):
    combined = defaultdict(lambda: sp.S.Zero)
    for outer, expression in parts:
        for term, inner in _additive(expression, cache):
            combined[term] += outer*inner
    return {term: value for term, coefficient in combined.items() if (value := sp.cancel(coefficient)) != 0}


def validate_invariance(blocks, basis_tokens, actions=SU3_ROOTS, *, charges=None, check=lambda: None):
    """Certify both exact Ward edges E.T M_target = M_source F and symmetry."""
    basis, spaces, _, keys = _basis_data(basis_tokens, charges, check)
    entries = moment_entries(blocks)
    for (i, j), value in entries.items():
        check()
        if type(i) is not int or type(j) is not int or not 0 <= i < len(basis) or not 0 <= j < len(basis):
            raise ValueError("Invalid global moment-matrix index.")
        if keys[i] != keys[j]:
            raise ValueError("SU(3) reduction requires blocks diagonal in grade and Cartan weight.")
        if value.has(sp.Float, sp.I, sp.nan, sp.zoo, sp.oo, -sp.oo):
            raise ValueError("SU(3) certification requires exact real moment entries.")
        if value != entries.get((j, i), sp.S.Zero) and sp.expand(value-entries.get((j, i), sp.S.Zero)) != 0:
            raise ValueError("SU(3) reduction requires a symmetric moment matrix.")
    cache, transitions, checked = {}, 0, 0
    for (grade, weight), source in spaces.items():
        source_words = {basis[i]: i for i in source}
        for name, raising, lowering, shift in actions:
            target = spaces.get((grade, tuple(q+d for q, d in zip(weight, shift))), ())
            target_words = {basis[i]: i for i in target}
            up = [act_on_word(basis[i], raising) for i in source]
            down = [act_on_word(basis[i], lowering) for i in target]
            if any(set(image)-target_words.keys() for image in up) or any(set(image)-source_words.keys() for image in down):
                raise ValueError("The SU(3) Ward action leaves its weight space.")
            if not any(up):
                continue
            transitions += 1
            for i, raised in zip(source, up):
                for j, lowered in zip(target, down):
                    check()
                    left = _combination(((c, entries.get((target_words[w], j), sp.S.Zero)) for w, c in raised.items()), cache)
                    right = _combination(((c, entries.get((i, source_words[w]), sp.S.Zero)) for w, c in lowered.items()), cache)
                    checked += 1
                    if left != right and sp.expand(sp.Add(*(c*t for t, c in left.items())) - sp.Add(*(c*t for t, c in right.items()))) != 0:
                        raise ValueError(f"Exact SU(3) moment invariance failed for {name} at ({i}, {j}).")
    return {"weight_spaces": len(spaces), "transitions_checked": transitions, "scalar_entries_checked": checked}


def project_blocks(blocks, sectors, *, check=lambda: None):
    """Compute H.T M_weight H by sparse exact additive accumulation.

    Call validate_invariance on the full unreduced moment form first. Auxiliary
    blocks and scalar-coordinate selection are the caller's responsibility.
    """
    entries, cache, projected = moment_entries(blocks), {}, []
    for sector in sectors:
        check()
        indices, h = sector["indices"], sector["H"]
        if h["rows"] != len(indices):
            raise ValueError("An SU(3) projection has the wrong source dimension.")
        supports = [[] for _ in range(h["cols"])]
        for i, j, text in h["entries"]:
            coefficient = sp.sympify(text)
            if not 0 <= i < h["rows"] or not 0 <= j < h["cols"] or coefficient.is_Rational is not True:
                raise ValueError("An SU(3) projection requires exact rational basis coefficients.")
            supports[j].append((indices[i], coefficient))
        output = {}
        for i, left in enumerate(supports):
            for j in range(i, len(supports)):
                check()
                values = _combination(((a*b, entries.get((row, column), sp.S.Zero))
                                       for row, a in left for column, b in supports[j]), cache)
                value = sp.Add(*(coefficient*term for term, coefficient in values.items()))
                if value != 0:
                    output[i, j] = output[j, i] = value
        projected.append(sp.ImmutableSparseMatrix(len(supports), len(supports), output))
    return tuple(projected)
