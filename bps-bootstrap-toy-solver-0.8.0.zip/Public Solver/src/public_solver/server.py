"""Offline, loopback-only browser interface; scientific work runs in a child."""

from dataclasses import asdict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import mimetypes
import os
from pathlib import Path
import re
import subprocess
import sys
import threading
from urllib.parse import parse_qs, urlparse
import uuid

from . import __version__
from .artifact import load_artifact, text_artifact
from .moments import BuildLimits, validate_request, word_basis
from .constraints import validate_constraints
from .storage import read_json, write_json
from .setups import SetupNotFoundError, SetupStorageError
from .builtin_setups import SetupCatalog
from .sdpa import check_sdpa
from .solve_runs import SolveManager
from .solver_settings import DEFAULT_SETTINGS

STATIC = Path(__file__).parent / "static"
EXAMPLE = {"model": {"species": [{"name": "X", "statistics": "boson", "charges": ["1"]}],
                      "charge_names": ["Q1"]}, "level": 2, "charge_neutral": True}


class JobManager:
    def __init__(self, directory: Path, limits: BuildLimits):
        self.directory = directory.resolve()
        self.directory.mkdir(parents=True, exist_ok=True)
        self.limits = limits
        self.processes = {}
        self.lock = threading.RLock()
        self.closed = False

    def _directory(self, job_id: str) -> Path:
        if not re.fullmatch(r"[a-f0-9]{32}", job_id):
            raise ValueError("Unknown job.")
        directory = self.directory / "jobs" / job_id
        if not (directory / "status.json").is_file():
            raise ValueError("Unknown job.")
        return directory

    def status(self, job_id: str) -> dict:
        with self.lock:
            directory = self._directory(job_id)
            status = read_json(directory / "status.json")
            running = self.processes.get(job_id)
            if running is not None and running[0].poll() is not None:
                # The child can publish completion between the initial read
                # and poll(). Its final atomic status takes precedence.
                status = read_json(directory / "status.json")
                running[1].close()
                del self.processes[job_id]
                running = None
            if running is None and status["status"] in {"queued", "running"}:
                status = {"job_id": job_id, "status": "failed",
                          "error": "The generation process stopped before completing. You can generate again; completed cache entries are retained."}
                write_json(directory / "status.json", status)
            return status

    def start(self, request: dict) -> str:
        model, level, neutral = validate_request(request)
        basis = word_basis(model, level, self.limits)
        counts = {}
        for word in basis:
            charge = model.charge(word)
            counts[charge] = counts.get(charge, 0) + 1
        entries = sum(n * n for n in counts.values())
        if self.limits.max_selected_entries is not None and entries > self.limits.max_selected_entries:
            raise ValueError(f"This request selects {entries:,} entries; the local limit is {self.limits.max_selected_entries:,}. Reduce the level or letters, or increase the server limit.")
        with self.lock:
            if self.closed:
                raise ValueError("The solver app is shutting down.")
            active = []
            for job_id in list(self.processes):
                if self.status(job_id)["status"] in {"queued", "running"}:
                    active.append(job_id)
            if active:
                raise ValueError("A generation is already running. Wait for it or cancel it first.")
            job_id = uuid.uuid4().hex
            directory = self.directory / "jobs" / job_id
            normalized = {"model": model.to_dict(), "level": level, "charge_neutral": neutral,
                          "constraints": validate_constraints(request.get("constraints"), model)}
            if "preparation" in request:
                from .preparation import validate_preparation
                normalized["preparation"] = validate_preparation(request["preparation"], model, level)
            write_json(directory / "request.json", normalized)
            write_json(directory / "status.json", {"job_id": job_id, "status": "queued",
                "progress": {"stage": "queued", "completed": 0, "total": entries,
                             "message": "Starting the build."}})
            log = (directory / "worker.log").open("w", encoding="utf-8")
            env = dict(os.environ)
            # Also supports running from an unpacked source distribution.
            package_root = str(Path(__file__).resolve().parent.parent)
            env["PYTHONPATH"] = package_root + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
            command = [sys.executable, "-m", "public_solver.worker",
                       "--directory", str(directory), "--cache", str(self.directory / "cache" / "canonical.sqlite3")]
            if self.limits.max_basis_size is not None:
                command.extend(["--max-basis-size", str(self.limits.max_basis_size)])
            if self.limits.max_selected_entries is not None:
                command.extend(["--max-selected-entries", str(self.limits.max_selected_entries)])
            try:
                process = subprocess.Popen(command,
                    stdout=log, stderr=log, stdin=subprocess.DEVNULL, env=env)
            except Exception:
                log.close()
                write_json(directory / "status.json", {"job_id": job_id, "status": "failed",
                                                       "error": "The generation process could not be started."})
                raise
            self.processes[job_id] = (process, log)
            return job_id

    def cancel(self, job_id: str) -> dict:
        with self.lock:
            status = self.status(job_id)
            record = self.processes.get(job_id)
            if record is not None and status["status"] in {"queued", "running"}:
                process, log = record
                process.terminate()
                try:
                    process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=3)
                log.close()
                del self.processes[job_id]
                status = {"job_id": job_id, "status": "cancelled",
                          "progress": {"message": "Cancelled. Completed cache entries are retained."}}
                write_json(self._directory(job_id) / "status.json", status)
            return status

    def result_path(self, job_id: str) -> Path:
        if self.status(job_id)["status"] != "complete":
            raise ValueError("This job has no completed result yet.")
        return self._directory(job_id) / "result.json"

    def close(self):
        with self.lock:
            self.closed = True
            for job_id in list(self.processes):
                self.cancel(job_id)


def create_server(port: int, data_directory: Path, limits: BuildLimits = BuildLimits()) -> ThreadingHTTPServer:
    manager = JobManager(data_directory, limits)
    setups = SetupCatalog(data_directory)

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def _local(self):
            port = self.server.server_port
            allowed_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
            if self.headers.get("Host") not in allowed_hosts:
                return False
            origin = self.headers.get("Origin")
            return origin is None or origin in {f"http://{host}" for host in allowed_hosts}

        def _send(self, data: bytes, content_type: str, status=200, filename=None):
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; script-src 'self'; connect-src 'self'; object-src 'none'; frame-ancestors 'none'")
            if filename:
                self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
            self.end_headers()
            self.wfile.write(data)

        def _json(self, data, status=200):
            self._send(json.dumps(data, ensure_ascii=False).encode(), "application/json; charset=utf-8", status)

        def do_GET(self):
            if not self._local():
                self._json({"error": "Only local same-origin requests are accepted."}, 403)
                return
            path = urlparse(self.path).path
            try:
                if path == "/api/info":
                    self._json({"version": __version__, "limits": asdict(limits), "example": EXAMPLE})
                    return
                if path == "/api/solver/status":
                    self._json({**check_sdpa(data_directory), "defaults": DEFAULT_SETTINGS})
                    return
                if path == "/api/solves":
                    self._json(solves.list())
                    return
                match = re.fullmatch(r"/api/solves/([a-f0-9]{32})(?:/(download))?", path)
                if match:
                    run_id, action = match.groups()
                    if action:
                        self._send(json.dumps(solves.download(run_id), ensure_ascii=False).encode(),
                                   "application/json; charset=utf-8", filename=f"sdpa-run-{run_id}.json")
                    else:
                        try:
                            offset = int(parse_qs(urlparse(self.path).query).get("offset", ["0"])[0])
                            if offset < 0:
                                raise ValueError()
                        except ValueError:
                            self._json({"error": "Log offset must be a nonnegative integer."}, 400)
                            return
                        self._json(solves.progress(run_id, offset))
                    return
                if path == "/api/setups":
                    self._json({"setups": setups.list()})
                    return
                match = re.fullmatch(r"/api/setups/([a-f0-9]{32}|builtin-[a-z0-9-]+)", path)
                if match:
                    self._json(setups.get(match[1]))
                    return
                match = re.fullmatch(r"/api/jobs/([a-f0-9]{32})(?:/(result|download))?", path)
                if match:
                    job_id, action = match.groups()
                    if action:
                        result_path = manager.result_path(job_id)
                        display_path = result_path.with_name("display.json")
                        if action == "result" and parse_qs(urlparse(self.path).query).get("view") == ["prepared"]:
                            if not display_path.is_file():
                                from .display import pack_prepared_display
                                native = load_artifact(read_json(result_path))
                                display = pack_prepared_display(native, read_json(result_path.with_name("request.json")))
                                write_json(display_path, display)
                            content = display_path.read_bytes()
                        else:
                            native = load_artifact(read_json(result_path))
                            public = text_artifact({key: value for key, value in native.items()
                                                    if key != "preparation"}, include_display=False)
                            if "preparation" in native:
                                public["preparation"] = text_artifact(native["preparation"])
                            content = json.dumps(public, ensure_ascii=False).encode("utf-8")
                        self._send(content, "application/json; charset=utf-8",
                                   filename=f"moment-matrix-{job_id}.json" if action == "download" else None)
                    else:
                        self._json(manager.status(job_id))
                    return
                filename = "index.html" if path == "/" else path.removeprefix("/static/").removeprefix("/")
                target = (STATIC / filename).resolve()
                if not target.is_relative_to(STATIC.resolve()) or not target.is_file():
                    self._json({"error": "Not found."}, 404)
                    return
                content_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
                self._send(target.read_bytes(), content_type + ("; charset=utf-8" if content_type.startswith("text/") else ""))
            except SetupNotFoundError as exc:
                self._json({"error": str(exc)}, 404)
            except SetupStorageError as exc:
                self._json({"error": str(exc)}, 500)
            except (ValueError, FileNotFoundError):
                self._json({"error": "Job or result not found."}, 404)
            except (BrokenPipeError, ConnectionResetError):
                return

        def do_POST(self):
            if not self._local():
                self._json({"error": "Only local same-origin requests are accepted."}, 403)
                return
            try:
                if self.headers.get("Content-Type", "").split(";")[0].strip() != "application/json":
                    raise ValueError("Requests must use application/json.")
                length = int(self.headers.get("Content-Length", "0"))
                if not 0 < length <= 65536:
                    raise ValueError("Request size must be between 1 and 65,536 bytes.")
                request = json.loads(self.rfile.read(length))
                path = urlparse(self.path).path
                if path == "/api/setups":
                    if not isinstance(request, dict) or set(request) != {"name", "config"}:
                        raise ValueError("A saved setup contains name and config.")
                    self._json(setups.save(request["name"], request["config"]))
                    return
                if path == "/api/generate":
                    self._json({"job_id": manager.start(request)}, 202)
                    return
                if path == "/api/solve":
                    self._json({"run_id": solves.start(request)}, 202)
                    return
                match = re.fullmatch(r"/api/solves/([a-f0-9]{32})/cancel", path)
                if match:
                    self._json(solves.cancel(match[1]))
                    return
                match = re.fullmatch(r"/api/jobs/([a-f0-9]{32})/cancel", path)
                if match:
                    self._json(manager.cancel(match[1]))
                    return
                self._json({"error": "Not found."}, 404)
            except SetupStorageError as exc:
                self._json({"error": str(exc)}, 500)
            except (ValueError, TypeError, UnicodeDecodeError) as exc:
                self._json({"error": str(exc)}, 400)
            except (BrokenPipeError, ConnectionResetError):
                return

    class LocalServer(ThreadingHTTPServer):
        def server_close(self):
            if hasattr(self, "solves"):
                self.solves.close()
            if hasattr(self, "jobs"):
                self.jobs.close()
            super().server_close()

    server = LocalServer(("127.0.0.1", port), Handler)
    try:
        solves = SolveManager(data_directory, manager)
    except Exception:
        server.server_close()
        raise
    server.daemon_threads = True
    server.jobs = manager
    server.solves = solves
    return server
