"""Evaluate physical objective terms at a saved validated solution."""

import sympy as sp

from .artifact import load_artifact
from .solver_engine import _context, _numeric, _text
from .solver_settings import validate_settings


def objective_components(prepared, result, settings=None):
    """Legacy artifact boundary for callers outside the native solve worker."""
    return objective_components_data(load_artifact(prepared), result, settings)


def objective_components_data(prepared, result, settings=None):
    """Keep input terms distinct, including contacts and unresolved loop freedom.

    These are values at one returned solution, not separate optimization bounds.
    A feasible solution may not have established optimality for the total.
    The representative reconstruction alone cannot determine a component along
    a direction invisible to both the PSD blocks and the total objective.
    """
    optimization = prepared.get("config", {}).get("optimization")
    if (result.get("status") not in {"optimal", "feasible"} or result.get("objective_value") is None
            or not optimization or optimization.get("mode") == "feasibility"):
        return []
    terms = [(term, sp.sympify(term["coefficient"]))
             for term in optimization["objective"]["terms"]]
    terms = [(term, coefficient) for term, coefficient in terms if coefficient != 0]
    if len(terms) < 2:
        return []
    reductions = {tuple(tuple(w) for w in row["traces"]): row
                  for row in prepared.get("moment_reductions", [])}
    variables = tuple(sp.Symbol(row["name"], real=True) for row in prepared["variables"])
    free = {sp.Symbol(row["name"], real=True) for row in prepared.get("loop_free_parameters", [])}
    mp, _, _ = _context(validate_settings(settings))
    values = {row["name"]: mp.mpf(row["value"]) for row in result.get("variables", [])}
    components = []
    for term, coefficient in terms:
        word = term["word"]
        key = (tuple(word),) if word else ()
        reduction = reductions.get(key)
        component = {"word": word, "coefficient": str(coefficient),
                     "coefficient_latex": sp.latex(coefficient),
                     "label": "1" if not word else reduction["text"] if reduction else "Trace component",
                     "status": "unavailable", "value": None, "contribution": None}
        components.append(component)
        if word and reduction is None:
            continue
        row = reduction["expression"] if word else None
        if row is not None and row.free_symbols & free:
            component["status"] = "undetermined"
            continue
        if row is not None and row.free_symbols - set(variables):
            continue
        coefficients = row.items() if row is not None else ((None, sp.S.One),)
        if any(str(symbol) not in values or not mp.isfinite(values[str(symbol)])
               for symbol, _ in coefficients if symbol is not None):
            continue
        value = mp.fsum(_numeric(c, mp) * (mp.mpf(1) if symbol is None else values[str(symbol)])
                        for symbol, c in coefficients)
        component.update(status="evaluated", value=_text(value, mp),
                         contribution=_text(_numeric(coefficient, mp) * value, mp))
    return components
