"""User-defined gauge insertions, supercharge equations, and symmetry Ward identities."""

import ast
from dataclasses import dataclass
from functools import lru_cache

import sympy as sp

from .brackets import trace_bracket
from .model import Model, adjoint_word
from .polynomial import add


def exact_coefficient(value) -> sp.Expr:
    """Parse a tiny arithmetic grammar; never evaluate user Python/SymPy code."""
    if type(value) not in (str, int):
        raise ValueError("Coefficients must be exact arithmetic strings, such as -2 or sqrt(2).")
    text = str(value).strip()
    if not text or len(text) > 128:
        raise ValueError("Use a coefficient of 1–128 characters.")
    try:
        tree = ast.parse(text, mode="eval")
    except SyntaxError as exc:
        raise ValueError("Invalid coefficient. Use numbers, i, sqrt(...), +, -, *, /, and parentheses.") from exc
    if sum(1 for _ in ast.walk(tree)) > 80:
        raise ValueError("The coefficient is too complicated.")

    def parse(node):
        if isinstance(node, ast.Constant) and type(node.value) in (int, float):
            literal = ast.get_source_segment(text, node)
            if 'e' in literal.lower() and abs(int(literal.lower().split('e')[1])) > 100:
                raise ValueError("Coefficient exponents must be between -100 and 100.")
            return sp.Rational(literal)
        if isinstance(node, ast.Name) and node.id in {"i", "I"}:
            return sp.I
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            result = parse(node.operand)
            return -result if isinstance(node.op, ast.USub) else result
        if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Sub, ast.Mult, ast.Div)):
            a, b = parse(node.left), parse(node.right)
            if isinstance(node.op, ast.Add):
                return a + b
            if isinstance(node.op, ast.Sub):
                return a - b
            if isinstance(node.op, ast.Mult):
                return a * b
            if b == 0:
                raise ValueError("A coefficient cannot divide by zero.")
            return a / b
        if (isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
                and node.func.id == "sqrt" and len(node.args) == 1 and not node.keywords):
            argument = parse(node.args[0])
            if argument.is_Rational is not True:
                raise ValueError("sqrt accepts an exact rational number, such as sqrt(2) or sqrt(1/2).")
            return sp.sqrt(argument)
        raise ValueError("Use numbers, i, sqrt(...), +, -, *, /, and parentheses in coefficients.")

    result = sp.simplify(parse(tree.body))
    if result.is_finite is not True or result.is_number is not True:
        raise ValueError("A coefficient must be a finite exact number.")
    if any(abs(int(n)).bit_length() > 2048 for n in result.atoms(sp.Integer)):
        raise ValueError("The coefficient is too large.")
    return result


def validate_constraints(value, model: Model) -> dict:
    if value is None:
        value = {}
    if not isinstance(value, dict) or set(value) - {"gauge_singlet", "supercharges", "symmetries"}:
        raise ValueError("Constraints contain gauge_singlet, supercharges, and symmetries.")
    gauge = value.get("gauge_singlet", False)
    if type(gauge) is not bool:
        raise ValueError("Gauge singlet must be true or false.")
    result = {"gauge_singlet": gauge, "supercharges": [], "symmetries": []}
    for family in ("supercharges", "symmetries"):
        generators = value.get(family, [])
        if not isinstance(generators, list) or len(generators) > 12:
            raise ValueError("Use at most 12 generators per family.")
        shared_kind = None
        for index, generator in enumerate(generators, 1):
            if not isinstance(generator, dict) or set(generator) - {"name", "kind", "terms"}:
                raise ValueError("A generator contains name, kind, and terms.")
            name = generator.get("name", "Q" if family == "supercharges" else f"J_{index}")
            if (not isinstance(name, str) or not name.strip() or len(name) > 128
                    or any(ord(c) < 32 or c in '<>$' for c in name)):
                raise ValueError("Use a generator name of 1–128 characters without $ delimiters.")
            kind = generator.get("kind", "ward")
            if kind not in {"ward", "matrix"} or (family == "symmetries" and kind != "ward"):
                raise ValueError("Choose a supercharge Ward identity or a matrix relation; symmetries use Ward identities.")
            if family == "supercharges":
                if shared_kind is not None and kind != shared_kind:
                    raise ValueError("All supercharge entries must use the same mode: Ward identities or matrix relations.")
                shared_kind = kind
            terms = generator.get("terms")
            if not isinstance(terms, list) or not 1 <= len(terms) <= 64:
                raise ValueError(f"{name}: enter between 1 and 64 terms.")
            combined = {}
            for term in terms:
                if not isinstance(term, dict) or set(term) != {"coefficient", "word"}:
                    raise ValueError("Each generator term contains coefficient and word.")
                word = term["word"]
                if not isinstance(word, list) or len(word) > 8:
                    raise ValueError("A generator word must be a list of at most 8 operators.")
                word = model.validate_word(word)
                coefficient = exact_coefficient(term["coefficient"])
                combined[word] = sp.simplify(combined.get(word, 0) + coefficient)
            combined = {w: c for w, c in combined.items() if c != 0}
            if not combined:
                raise ValueError(f"{name}: the generator is identically zero.")
            parities = {model.parity(w) for w in combined}
            if len(parities) != 1:
                raise ValueError(f"{name}: every term must have the same fermion parity.")
            if kind == "ward":
                expected = 1 if family == "supercharges" else 0
                if parities != {expected}:
                    raise ValueError(f"{name}: {'a supercharge must be fermionic' if expected else 'a symmetry generator must be bosonic'}. Use Matrix relation for a reduced polynomial equation.")
            result[family].append({"name": name.strip(), "kind": kind,
                "terms": [{"coefficient": str(c).replace('I', 'i'), "word": list(w)} for w, c in combined.items()]})
    if len(result["supercharges"]) + len(result["symmetries"]) > 12:
        raise ValueError("Use at most 12 generators in total.")
    return result


def gauge_polynomial(canonical, test_word):
    """tr(G W), including the (number of bosons − fermions) contact."""
    model = canonical.model
    result = {}
    contact = sum(-1 if s.fermionic else 1 for s in model.species)
    add(result, canonical.word(test_word), contact)
    for i, species in enumerate(model.species, 1):
        add(result, canonical.word((i, -i) + test_word))
        add(result, canonical.word((-i, i) + test_word), 1 if species.fermionic else -1)
    return result


def generator_polynomial(canonical, terms, test_word, kind="ward"):
    result = {}
    for coefficient, word in terms:
        polynomial = (trace_bracket(canonical, word, test_word) if kind == "ward"
                      else canonical.word(test_word + word if kind == "matrix_right" else word + test_word))
        add(result, polynomial, coefficient)
    return {key: sp.expand(value) for key, value in result.items() if sp.expand(value) != 0}


def _test_words(model, max_length, targets, check):
    """Prune charge-incompatible prefixes before enumerating insertions."""
    zero = tuple(0 for _ in model.charge_names)
    charges = {t: model.charge((t,)) for t in model.alphabet}

    @lru_cache(maxsize=None)
    def reachable(length, target):
        check()
        if length == 0:
            return target == zero
        return any(reachable(length - 1, tuple(a - b for a, b in zip(target, charge)))
                   for charge in set(charges.values()))

    def descend(prefix, remaining, targets_left):
        if not remaining:
            yield prefix
            return
        for token in model.alphabet:
            next_targets = frozenset(tuple(a - b for a, b in zip(target, charges[token])) for target in targets_left)
            next_targets = frozenset(t for t in next_targets if reachable(remaining - 1, t))
            if next_targets:
                yield from descend(prefix + (token,), remaining - 1, next_targets)

    for length in range(max_length + 1):
        possible = frozenset(t for t in targets if reachable(length, t))
        if not possible:
            continue
        for word in descend((), length, possible):
            check()
            yield word


@dataclass
class Equation:
    family: str
    generator: str
    test_word: tuple
    polynomial: dict


def build_equations(canonical, level, config, progress=None):
    """Produce canonical neutral equations before introducing real coordinates."""
    from .moments import neutral_factors
    model = canonical.model
    equations = []
    seen = set()
    notify = progress or (lambda _: None)
    attempted = 0

    def retain(family, name, word, polynomial):
        nonlocal attempted
        attempted += 1
        polynomial = neutral_factors(model, polynomial)
        polynomial = {k: sp.expand(v) for k, v in polynomial.items() if sp.expand(v) != 0}
        if not polynomial:
            return
        ordered = sorted(polynomial.items())
        scale = ordered[0][1]
        signature = tuple((k, sp.simplify(v / scale)) for k, v in ordered)
        if signature not in seen:
            seen.add(signature)
            equations.append(Equation(family, name, word, polynomial))
        if attempted % 100 == 0:
            notify({"stage": "constraints", "message": f"Building loop equations: {attempted:,} insertions checked."})

    if config["gauge_singlet"] and level >= 1:
        for word in _test_words(model, 2 * level - 2, {tuple(0 for _ in model.charge_names)}, canonical.check_cancelled):
            retain("gauge", "G", word, gauge_polynomial(canonical, word))
    for family, plural in (("supercharge", "supercharges"), ("symmetry", "symmetries")):
        for generator in config[plural]:
            terms = [(exact_coefficient(t["coefficient"]), tuple(t["word"])) for t in generator["terms"]]
            kind = generator["kind"]
            bound = 2 * level + (2 if kind == "ward" else 0) - max(len(w) for _, w in terms)
            if bound < 0:
                raise ValueError(f"{generator['name']} is too long at level {level}; increase the level or shorten the generator.")
            adjoint = [(sp.conjugate(c), adjoint_word(w)) for c, w in terms]
            for name, current, action in ((generator["name"], terms, kind),
                    (generator["name"] + r"^{\dagger}", adjoint, "matrix_right" if kind == "matrix" else kind)):
                targets = {tuple(-q for q in model.charge(w)) for _, w in current}
                for word in _test_words(model, bound, targets, canonical.check_cancelled):
                    retain(family, name, word, generator_polynomial(canonical, current, word, action))
    return equations


def polynomial_latex(model, polynomial):
    terms = []
    for key, coefficient in sorted(polynomial.items()):
        if key:
            factors = []
            for word in key:
                letters = ["{" + model.species[abs(t) - 1].name + "}" if t > 0
                           else r"\overline{" + model.species[-t - 1].name + "}" for t in word]
                factors.append(r"\operatorname{tr}\left(" + r"\,".join(letters) + r"\right)")
            moment = r"\left\langle " + r"\,".join(factors) + r"\right\rangle"
        else:
            moment = ""
        prefix = "" if coefficient == 1 and moment else "-" if coefficient == -1 and moment else sp.latex(coefficient)
        if coefficient.is_Add and moment:
            prefix = r"\left(" + prefix + r"\right)"
        terms.append(prefix + moment)
    return " + ".join(terms).replace("+ -", "- ") + " = 0"


def reduce_equations(equations, coordinate, elimination_order, *, stage_cache=None,
                     progress=None, check_cancelled=None):
    """Reduce exact equations using the same moment priority as Hermiticity."""
    from .constraint_reduction import reduce_linear_families
    check = check_cancelled or (lambda: None)
    families = {}
    for equation in equations:
        check()
        value = sp.expand(sum(coefficient * (coordinate[key] if key else 1)
                              for key, coefficient in equation.polynomial.items()))
        for part in value.as_real_imag():
            part = sp.expand(part)
            if part != 0:
                families.setdefault(equation.family, []).append(part)
    return reduce_linear_families(families, elimination_order, stage_cache=stage_cache,
                                 progress=progress, check_cancelled=check)
