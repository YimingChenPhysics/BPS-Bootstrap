"""One cancellable generation job, isolated from the HTTP process."""

import argparse
from pathlib import Path
import time
import traceback

from .moments import BuildLimits
from .artifact import pack_artifact
from .display import PREVIEW_ROWS, pack_prepared_display
from .pipeline import build_request_data
from .storage import read_json, write_json


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--directory", type=Path, required=True)
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--max-basis-size", type=int, default=BuildLimits().max_basis_size)
    parser.add_argument("--max-selected-entries", type=int, default=BuildLimits().max_selected_entries)
    args = parser.parse_args()
    status_path = args.directory / "status.json"
    last_update = 0.0
    last_stage = None

    def progress(value):
        nonlocal last_update, last_stage
        now = time.monotonic()
        if (value.get("stage") != last_stage or now - last_update >= 0.1
                or value.get("completed") == value.get("total")):
            write_json(status_path, {"job_id": args.directory.name, "status": "running", "progress": value})
            last_update = now
            last_stage = value.get("stage")

    try:
        request = read_json(args.directory / "request.json")
        result = build_request_data(request, cache_path=args.cache,
            limits=BuildLimits(args.max_basis_size, args.max_selected_entries), progress=progress,
            preview_limit=PREVIEW_ROWS)
        progress({"stage": "saving", "message": "Saving the prepared SDP." if "preparation" in result
                  else "Saving the moment matrix."})
        write_json(args.directory / "result.json", pack_artifact(result), compact=True)
        if "preparation" in result:
            write_json(args.directory / "display.json", pack_prepared_display(result, request))
        write_json(status_path, {"job_id": args.directory.name, "status": "complete",
            "progress": {"stage": "complete", "completed": 1, "total": 1,
                         "message": "SDP prepared and checked." if "preparation" in result else
                                    "Moment matrix generated and checked."}, "summary": result["summary"]})
        return 0
    except Exception as exc:
        write_json(status_path, {"job_id": args.directory.name, "status": "failed", "error": str(exc)})
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
