"""Exact SDP preparation, separate from the physical moment construction.

Fixed observables retain their trace definitions. Their factorization equations
are built in the trace-product catalog before affine reduction. Covariance
blocks and common-kernel compression follow the research workflow. The optional
BMN SU(3) reduction supplies smaller model blocks before point preparation.
"""

from contextlib import nullcontext
from functools import lru_cache
from itertools import combinations_with_replacement
from pathlib import Path
import sqlite3
import time

import sympy as sp

from .affine import (AffineSubstitution, _AffineTerms, _kernel_vectors, _singleton_full_column_rank,
                     compress_psd_block, solve_affine_equalities)
from .cache import ALGORITHM_VERSION, CanonicalCache
from .build_cache import BuildCache, stable_digest
from .block_reduction import deduplicate_psd_blocks
from .canonical import Canonicalizer
from .constraints import exact_coefficient
from .affine_data import AffineRow, AffineRows, AffineMatrix
from .artifact import pack_artifact, load_artifact, text_artifact
from .model import Model, adjoint_word
from .moments import _moment_elimination_key, _moment_text, neutral_factors, build_moment_data, BuildLimits
from .optimization import validate_optimization


PREPARATION_VERSION = "sdp-preparation-v8"
MODEL_EQUIVALENCE_VERSION = "model-block-equivalence-v1"
MODEL_EQUIVALENCE_TIME_LIMIT_SECONDS = 120.0
NULL_PLAN_VERSION = "numerical-null-row-plan-v2"
BMN_RELAXATION_VERSION = "bmn-relaxation-v1"
# Scan baselines have a scientific lifetime distinct from compiled artifacts.
# Keep this namespace independent of BuildCache's disposable-format version.
NULL_PLAN_CACHE_NAMESPACE = "exact-null-baselines-v1"


def validate_preparation(value, model: Model, level: int) -> dict:
    if value is None:
        value = {}
    if not isinstance(value, dict) or set(value) - {"fixed_observables", "variable_cutoff", "bmn_observable_cutoff", "optimization", "bmn_su3_reduction"}:
        raise ValueError("Unknown SDP preparation setting.")
    if value.get("variable_cutoff") is not None:
        raise ValueError("The general variable cutoff has been removed. Remove variable_cutoff and, for BMN, choose bmn_observable_cutoff explicitly.")
    if type(value.get("bmn_su3_reduction", False)) is not bool:
        raise ValueError("BMN SU(3) block reduction must be enabled or disabled.")
    optimization = validate_optimization(value.get("optimization"), model, level)
    cutoff = value.get("bmn_observable_cutoff")
    if cutoff is not None:
        try:
            cutoff = exact_coefficient(cutoff)
        except ValueError as exc:
            raise ValueError("The BMN observable cutoff Λ must be a positive exact real number.") from exc
        if cutoff.is_real is not True or cutoff.is_positive is not True:
            raise ValueError("The BMN observable cutoff Λ must be a positive exact real number.")
        _bmn_cutoff_observables(model, level)
    rows = value.get("fixed_observables", [])
    if not isinstance(rows, list) or len(rows) > 12:
        raise ValueError("Use at most 12 observable constraints.")
    result = []
    for index, row in enumerate(rows, 1):
        if not isinstance(row, dict) or set(row) - {"name", "value", "terms", "relation"}:
            raise ValueError("An observable constraint contains name, value, terms, and an optional relation.")
        relation = row.get("relation", "=")
        if relation not in ("=", "<=", ">="):
            raise ValueError("An observable relation must be =, <=, or >=.")
        name = row.get("name", "")
        if not isinstance(name, str) or len(name) > 128 or any(ord(c) < 32 or c in '<>$' for c in name):
            raise ValueError("Use an observable name of at most 128 characters without $ delimiters.")
        name = name.strip() or f"O_{index}"
        target = exact_coefficient(row.get("value", ""))
        if target.is_real is not True:
            raise ValueError(f"{name}: the constraint value must be real.")
        terms = row.get("terms")
        if not isinstance(terms, list) or not 1 <= len(terms) <= 64:
            raise ValueError(f"{name}: enter between 1 and 64 trace terms.")
        combined = {}
        for term in terms:
            if not isinstance(term, dict) or set(term) != {"coefficient", "word"}:
                raise ValueError("Each observable term contains coefficient and word.")
            if not isinstance(term["word"], list) or len(term["word"]) > 2 * level:
                raise ValueError(f"{name}: trace words must have length at most 2ℓ.")
            word = model.validate_word(tuple(term["word"]))
            if model.parity(word) or any(model.charge(word)):
                raise ValueError(f"{name}: each trace term must be bosonic and charge neutral.")
            coefficient = exact_coefficient(term["coefficient"])
            if coefficient.is_real is not True:
                raise ValueError(f"{name}: coefficients must be real.")
            combined[word] = sp.expand(combined.get(word, 0) + coefficient)
        normalized = [{"coefficient": str(c), "word": list(w)} for w, c in combined.items() if c != 0]
        result.append({"name": name, "value": str(target),
            **({"relation": relation} if relation != "=" else {}), "terms": normalized or [
            {"coefficient": "0", "word": []}]})
    config = {"fixed_observables": result}
    if value.get("bmn_su3_reduction"):
        config["bmn_su3_reduction"] = True
    if cutoff is not None:
        config["bmn_observable_cutoff"] = str(cutoff)
    if optimization is not None:
        config["optimization"] = optimization
    return config


def _word_latex(model, word):
    return " ".join((r"\overline{" + model.species[-t - 1].name + "}") if t < 0
                    else "{" + model.species[t - 1].name + "}" for t in word) or "1"


def _bmn_cutoff_observables(model, level):
    from .bmn_reduction import bmn_species_mapping
    mapping = bmn_species_mapping(model, "BMN observable cutoff")
    if level < 3:
        raise ValueError("The BMN observable cutoff requires level ℓ ≥ 3 for its length-six trace words.")
    inverse = {standard: actual for actual, standard in mapping.items()}
    rows = []
    for standard, name in ((7, "tr((f f̄)³)"), (1, "tr((φ₁ φ̄₁)³)")):
        species = inverse[standard]
        pair = (species, -species)
        rows.append({"name": name, "tokens": list(pair * 3),
            "observable_latex": r"\left\langle\operatorname{tr}\!\left((" + _word_latex(model, pair)
                + r")^3\right)\right\rangle"})
    return rows


def _expression_record(value, *_):
    return {"expression": value}


class _MomentSpace:
    """Canonical trace coordinates backed exclusively by exact sparse rows."""
    def __init__(self, result, canonical, *, rows=None):
        self.model, self.canonical = canonical.model, canonical
        self.rows = rows if rows is not None else AffineRows(check=canonical.check_cancelled)
        self.symbols = {v["name"]: sp.Symbol(v["name"], real=True) for v in result["variables"]}
        self.coordinates = {tuple(tuple(w) for w in m["traces"]): self.parse(m["real"])
                            for m in result["moments"]}
        definitions = {m["id"]: tuple(tuple(w) for w in m["traces"]) for m in result["moments"]}
        self.definitions = {self.symbols[v["name"]]: definitions[v["moment_id"]] for v in result["variables"]}
        self.added, self.cache = {}, {}

    def parse(self, value):
        return value if isinstance(value, AffineRow) else self.rows.from_expr(sp.sympify(value, locals=self.symbols))

    def combine(self, terms):
        terms = [(coefficient, self.parse(value)) for coefficient, value in terms if coefficient != 0]
        if not terms:
            return self.rows.zero
        if len(terms) == 1 and terms[0][0] == 1:
            return terms[0][1]
        coefficients = {}
        for coefficient, value in terms:
            self.canonical.check_cancelled()
            if coefficient == 0:
                continue
            for symbol, entry in self.parse(value).items():
                coefficients[symbol] = coefficients.get(symbol, sp.S.Zero) + coefficient * entry
        return self.rows.from_coefficients(coefficients)

    def polynomial(self, factors):
        return neutral_factors(self.model, self.canonical.product(tuple(factors)))

    def value(self, factors, *, extend=False):
        factors = tuple(factors)
        if factors in self.cache:
            return self.cache[factors]
        polynomial = self.polynomial(factors)
        missing = [key for key in polynomial if key and key not in self.coordinates]
        if missing and not extend:
            raise ValueError("The observable needs moments outside the generated truncation.")
        for key in missing:
            symbol = sp.Symbol(f"d{len(self.added) + 1}", real=True)
            self.coordinates[key] = self.rows.from_expr(symbol)
            self.added[key] = symbol
            self.definitions[symbol] = key
            self.symbols[str(symbol)] = symbol
        value = self.combine((sp.Rational(c.numerator, c.denominator),
                              self.coordinates[key] if key else sp.S.One) for key, c in polynomial.items())
        self.cache[factors] = value
        return value

    def adjoint_equations(self):
        equations, done = [], set()
        while pending := set(self.added) - done:
            for key in sorted(pending):
                self.canonical.check_cancelled()
                dagger = tuple(adjoint_word(word) for word in reversed(key))
                equations.append(self.combine(((1, self.coordinates[key]), (-1, self.value(dagger, extend=True)))))
                done.add(key)
        return equations

    def variables(self):
        return tuple(sorted(self.definitions, key=lambda symbol:
                            _moment_elimination_key(self.model, self.definitions[symbol])))


def _model_block_equivalence(raw_blocks, space, notify, check):
    """Compute certificates once while compiling the complete unfixed model."""
    notify({"stage": "block_reduction", "message": "Finding model-wide equivalent PSD blocks."})
    return deduplicate_psd_blocks([row[2] for row in raw_blocks], space.variables(), check=check,
        coefficient_terms=_AffineTerms(space.variables(), check),
        time_limit=MODEL_EQUIVALENCE_TIME_LIMIT_SECONDS,
        on_timeout=lambda: notify({"stage": "block_reduction", "message":
            "Reached the 2-minute block-equivalence limit. Keeping all unfinished blocks."}))


def _affine_representation(expression, words, single):
    """Represent an observable in the available factors using numeric rows."""
    factors = [{None: sp.S.One}, *(dict(single(word).items()) for word in words)]
    expression = dict(expression.items())
    symbols = sorted(set().union(*(set(value) for value in factors), set(expression)) - {None}, key=str)
    def column(value):
        return [value.get(symbol, sp.S.Zero) for symbol in (None, *symbols)]
    a = sp.Matrix.hstack(*(sp.Matrix(column(value)) for value in factors))
    try:
        solution, parameters = a.gauss_jordan_solve(sp.Matrix(column(expression)))
    except ValueError:
        return None
    solution = solution.xreplace({p: 0 for p in parameters})
    return solution[0], {word: sp.expand(solution[i + 1]) for i, word in enumerate(words) if solution[i + 1] != 0}


def _fixed_equations(space, fixed, catalog, check):
    """Propagate fixed factors using the same exact row representation."""
    initial = [space.combine(((1, expression), (-1, value))) for _, expression, value in fixed]
    substitutions, _ = solve_affine_equalities(initial, space.variables(), check=check, row_factory=space.rows)
    equations = []
    for key in tuple(space.coordinates):
        if len(key) < 2:
            continue
        check()
        constant, remaining = sp.S.One, []
        for word in key:
            value = space.rows.transform(space.value((word,)), substitutions)
            if value.free_symbols:
                remaining.append(word)
            else:
                constant *= dict(value.items()).get(None, sp.S.Zero)
        if len(remaining) < len(key):
            equations.append(space.combine(((1, space.coordinates[key]),
                (-constant, space.value(tuple(remaining), extend=True)))))
    partners = sorted({word for pair in catalog for word in pair}, key=lambda w: (len(w), space.model.word_key(w)))
    representations = {}
    for partner in partners:
        check()
        words = tuple(word for word in partners if tuple(sorted((word, partner),
                      key=lambda w: (len(w), space.model.word_key(w)))) in catalog)
        for _, expression, target in fixed:
            cache_key = (expression, words)
            if cache_key not in representations:
                representations[cache_key] = _affine_representation(expression, words, lambda w: space.value((w,)))
            representation = representations[cache_key]
            if representation is None:
                continue
            constant, coefficients = representation
            equations.append(space.combine([(constant - target, space.value((partner,))),
                *((c, space.value((word, partner), extend=True)) for word, c in coefficients.items())]))
    return initial, [e for e in dict.fromkeys(equations) if e.items()]


def _scalar_coordinates(matrices, variables, check, objective=sp.S.Zero, *, coefficient_terms=None,
                        additional_expressions=(), full_rank_sources=()):
    """Choose a coefficient-column basis, as in the original SDP preparation.

    Dropped directions are invisible to these PSD blocks, the objective and
    each additional observable. Setting their coordinates to zero chooses a
    representative, not a new physical equality.
    The nullspace is exported so full moment solutions can be reconstructed.

    ``full_rank_sources`` may contain the already-substituted pencils before
    their certified common-kernel principal compression. That compression is a
    fixed invertible change of basis to the kept block plus a zero block, so it
    preserves the kernel of the scalar coefficient columns. A cheap exact
    full-rank proof there remains valid after compression, even when the kept
    entries no longer expose singleton coefficients. Incomplete proofs leave
    the original compressed-column RREF path unchanged.
    """
    check()
    if not variables:
        return {}, (), (), ()
    terms = coefficient_terms or _AffineTerms(variables, check, normalize=False)
    source_rows, source_seen = [], set()
    for matrix in full_rank_sources:
        for (row, column), value in matrix.todok().items():
            check()
            if column > row or value in source_seen:
                continue
            source_seen.add(value)
            coefficients = terms(value)
            # Most model rows have no constant. Reuse their already-indexed
            # sparse maps instead of copying every large coefficient vector.
            if terms.constant in coefficients:
                coefficients = {index: coefficient for index, coefficient in coefficients.items()
                                if index != terms.constant}
            if coefficients:
                source_rows.append(coefficients)
    if source_rows and _singleton_full_column_rank(source_rows, len(variables), check):
        # Preserve validation of all returned expressions, including objective
        # and bound-only variables, without constructing another rank matrix.
        validated = set()
        for matrix in matrices:
            for value in matrix.todok().values():
                check()
                if value not in validated:
                    terms(value)
                    validated.add(value)
        terms(objective)
        for expression in additional_expressions:
            terms(expression)
        check()
        return {}, tuple(variables), (), tuple(variables)
    rows = {}
    seen = set()

    def include(value):
        check()
        if value in seen:
            return
        seen.add(value)
        row = tuple(sorted((index, coefficient) for index, coefficient in terms(value).items()
                           if index != terms.constant))
        if row:
            rows[row] = None

    for matrix in matrices:
        for (row, column), value in matrix.todok().items():
            check()
            if column <= row:
                include(value)
    include(objective)
    for expression in additional_expressions:
        include(expression)
    pivots, kernel = _kernel_vectors([dict(row) for row in rows], len(variables), check)
    selected = tuple(variables[i] for i in pivots)
    dropped = {symbol: sp.S.Zero for symbol in variables if symbol not in selected}
    return dropped, selected, kernel, tuple(variables)


def _reconstruction_directions(variables, substitutions, parameters, kernel, check):
    """Lift each scalar kernel vector through the sparse equality map once."""
    if not kernel:
        return []
    terms = _AffineTerms(parameters, check, normalize=False)
    rows = [{index: coefficient for index, coefficient in terms(
        substitutions.get(symbol, symbol)).items() if index != terms.constant} for symbol in variables]
    directions = []
    for vector in kernel:
        sparse = {index: value for (index, _), value in vector.todok().items()}
        lifted = []
        for row in rows:
            check()
            lifted.append(sp.expand(sum((coefficient * sparse[index]
                for index, coefficient in row.items() if index in sparse), sp.S.Zero)))
        directions.append(lifted)
    return directions


def _loop_equations(result, space, reconstruction, check, record=_expression_record,
                    preview_limit=None, required_words=(), counts=None):
    """Resolve both original matrix words and their canonical trace factors."""
    # Use the same certified coefficient substitution as the PSD blocks. A
    # reconstruction usually changes few coordinates; re-normalizing every
    # untouched coefficient of every dense moment row is unnecessary. Include
    # lifted scalar-kernel parameters, which need not be source coordinates.
    replacements = {symbol: space.parse(value) for symbol, value in reconstruction.items()}
    source_variables = space.variables()
    target_symbols = set(source_variables) - replacements.keys()
    for value in replacements.values():
        check()
        target_symbols.update(value.free_symbols)
    transform = AffineSubstitution(source_variables, tuple(sorted(target_symbols, key=str)),
                                   replacements, check=check)
    moments = {tuple(tuple(w) for w in row["traces"]): None for row in result["moments"]}
    for row in result["canonical_traces"]:
        word = tuple(row["word"])
        moments[(word,) if word else ()] = row
    keys = sorted(moments, key=lambda key: (sum(map(len, key)), len(key),
                                          tuple(space.model.word_key(w) for w in key)))
    if counts is not None:
        counts["moment_reductions"] = len(keys)
    if preview_limit is not None:
        keys = keys[:preview_limit]
        # Component values after solving need these identities even when they
        # fall outside the printed preview.
        for word in required_words:
            key = (tuple(word),) if word else ()
            if key not in keys:
                keys.append(key)
    expressions, equations = {}, []
    for key in keys:
        check()
        row = moments.get(key)
        if row is not None:
            value = row["_affine_value"]
        elif key in moments:
            value = space.coordinates[key]
        else:
            value = space.value(key)
        if value not in expressions:
            expressions[value] = record(transform(value))
        equations.append({"traces": [list(w) for w in key], "text": _moment_text(space.model, key) if key else "1",
                          **expressions[value]})
    return equations


def _relaxation_structure(result, space, level, check, *, moment_blocks=None):
    model = space.model
    raw_blocks = [] if moment_blocks is None else list(moment_blocks)
    if moment_blocks is None:
        for number, block in enumerate(result["blocks"], 1):
            check()
            n = len(block["basis_indices"])
            matrix = AffineMatrix(n, n, {(e["row"], e["col"]):
                space.parse(e["expression"]) for e in block["entries"]})
            words = [tuple(result["basis"][i]["tokens"]) for i in block["basis_indices"]]
            raw_blocks.append((f"Moment block {number}", "moment", matrix,
                               [model.word_text(w) for w in words], [_word_latex(model, w) for w in words]))
    matrix_symbols = set().union(*(row[2].free_symbols for row in raw_blocks))
    selected_pairs = [key for symbol, key in space.definitions.items()
                      if symbol in matrix_symbols and len(key) == 2]
    # Neutrality does not imply even parity for arbitrary user charges.
    # These auxiliary PSD blocks use commuting even factors. Odd factors
    # remain in the moment blocks and catalog with their graded identities.
    covariance_words = tuple(sorted({word for pair in selected_pairs for word in pair
                                     if len(word) <= level and not model.parity(word)},
                                    key=lambda w: (len(w), model.word_key(w))))
    if any(model.parity(w) or any(model.charge(w)) for w in covariance_words):
        raise ValueError("Covariance trace factors must be bosonic and separately charge neutral.")
    catalog = {key for key in space.coordinates if len(key) == 2}
    for left, right in combinations_with_replacement(covariance_words, 2):
        check()
        space.value((left, right), extend=True)
        catalog.add(tuple(sorted((left, right), key=lambda w: (len(w), model.word_key(w)))))
    m = [space.value((word,)) for word in covariance_words]
    if m:
        n = len(m)
        doubles = {(i, j): space.value((covariance_words[i], covariance_words[j]), extend=True)
                   for i in range(n) for j in range(n)}
        schur_entries = {(0, 0): space.parse(sp.S.One)}
        schur_entries.update({(0, i + 1): value for i, value in enumerate(m)})
        schur_entries.update({(i + 1, 0): value for i, value in enumerate(m)})
        schur_entries.update({(i + 1, j + 1): value for (i, j), value in doubles.items()})
        schur = AffineMatrix(n + 1, n + 1, schur_entries)
        covariance_entries = {(i, j): space.combine(((1, space.value(
            (covariance_words[i] + adjoint_word(covariance_words[j]),))), (-1, doubles[i, j])))
            for i in range(n) for j in range(n)}
        if any(value != covariance_entries[j, i] for (i, j), value in covariance_entries.items()):
            raise ArithmeticError("The covariance block failed exact symmetry.")
        covariance = AffineMatrix(n, n, covariance_entries)
        labels = [f"tr({model.word_text(w)})" for w in covariance_words]
        latex = [r"\operatorname{tr}(" + _word_latex(model, w) + ")" for w in covariance_words]
        raw_blocks.extend((("Double-trace Schur block", "schur", schur, ["1", *labels], ["1", *latex]),
                           ("Color-traceless covariance", "covariance", covariance, labels, latex)))
    for pair in selected_pairs:
        if pair[0] != pair[1] or pair[0] in covariance_words:
            continue
        word = pair[0]
        single, double = space.value((word,)), space.value(pair)
        label = f"tr({model.word_text(word)})"
        raw_blocks.append(("Identical double trace", "identical", AffineMatrix(2, 2, {(0, 0): space.parse(sp.S.One), (0, 1): single, (1, 0): single, (1, 1): double}),
                           ["1", label], ["1", r"\operatorname{tr}(" + _word_latex(model, word) + ")"]))
    return raw_blocks, covariance_words, catalog


def _apply_observable_inequalities(prepared, check):
    """Append hard observable bounds without compressing constant residuals."""
    inequalities = prepared["observable_inequalities"]
    source_count = prepared["block_reduction"]["source_block_count"]
    for index, observable in enumerate(inequalities):
        check()
        prepared["blocks"].append({
            "name": f"Observable bound: {observable['name']}", "kind": "inequality",
            "relation": observable["relation"],
            "observable": {key: value for key, value in observable.items() if key != "residual"},
            "source_index": source_count + index,
            "original_size": 1, "size": 1, "kept_indices": [0], "removed_nullity": 0,
            "labels": [observable["name"]], "labels_latex": [observable.get("latex", observable["name"])], "nullspace": [],
            "entries": [{"row": 0, "col": 0, **observable["residual"]}],
        })
    count = len(inequalities)
    prepared["block_reduction"]["source_block_count"] += count
    for key in ("block_count", "original_psd_dimension", "null_compressed_psd_dimension", "compressed_psd_dimension"):
        prepared["summary"][key] += count
    if count:
        prepared["summary"]["maximum_block_size"] = max(1, prepared["summary"]["maximum_block_size"])


def _apply_bmn_observable_cutoff(prepared, config, check):
    """Append the two physical upper bounds after point-specific reduction."""
    prepared["config"] = config
    if "bmn_observable_cutoff" not in config:
        prepared["bmn_observable_cutoff"] = {"enabled": False}
        return prepared
    info = prepared["bmn_observable_cutoff"]
    source_count = prepared["block_reduction"]["source_block_count"]
    for index, observable in enumerate(info["observables"]):
        check()
        prepared["blocks"].append({
            "name": f"BMN cutoff: {observable['name']}", "kind": "cutoff", "bound": "upper",
            "observable": {key: observable[key] for key in ("name", "tokens", "observable_latex")},
            "source_index": source_count + index,
            "original_size": 1, "size": 1, "kept_indices": [0], "removed_nullity": 0,
            "labels": [observable["name"]], "labels_latex": [observable["observable_latex"]], "nullspace": [],
            "entries": [{"row": 0, "col": 0, **observable["upper_bound"]}],
        })
    count = len(info["observables"])
    info["block_count"] = count
    prepared["block_reduction"]["source_block_count"] += count
    for key in ("block_count", "original_psd_dimension", "null_compressed_psd_dimension", "compressed_psd_dimension"):
        prepared["summary"][key] += count
    if count:
        prepared["summary"]["maximum_block_size"] = max(1, prepared["summary"]["maximum_block_size"])
    check()
    return prepared


COMPILED_MODEL_VERSION = "compiled-exact-model-v2"


def _compile_model(result, canonical, config, notify, check):
    """The sole construction algorithm for an unfixed model checkpoint."""
    space = _MomentSpace(result, canonical)
    # Native moment construction supplies the rows already used in the matrix.
    # Legacy text imports need this one conversion before entering the complete
    # checkpoint. Never recombine these dense rows at every point or preview.
    if any(not isinstance(row.get("_affine_value"), AffineRow) for row in result["canonical_traces"]):
        canonical_rows = []
        for row in result["canonical_traces"]:
            check()
            if not isinstance(row.get("_affine_value"), AffineRow):
                value = space.combine((sp.Rational(term["coefficient"]), space.coordinates[
                    tuple(tuple(word) for word in term["traces"])] if term["traces"] else sp.S.One)
                    for term in row["terms"])
                row = {**row, "_affine_value": value}
            canonical_rows.append(row)
        result = {**result, "canonical_traces": canonical_rows}
    moment_blocks, bmn_info = None, None
    if config.get("bmn_su3_reduction"):
        from .bmn_reduction import build_moment_blocks
        moment_blocks, bmn_info = build_moment_blocks(result, space, notify=notify, check=check)
    notify({"stage": "relaxation", "message": "Constructing PSD and multi-trace coefficient blocks."})
    blocks, words, catalog = _relaxation_structure(result, space, result["settings"]["level"], check,
                                                  moment_blocks=moment_blocks)
    # Close auxiliary adjoints now so every point begins with identical coordinates.
    space.adjoint_equations()
    retained, certificates = ((tuple(range(len(blocks))), ()) if bmn_info else
                             _model_block_equivalence(blocks, space, notify, check))
    return {"result": result, "blocks": [
        {"name": name, "kind": kind, "size": matrix.rows,
         "entries": [[i, j, value] for (i, j), value in matrix.todok().items()],
         "labels": labels, "latex": latex} for name, kind, matrix, labels, latex in blocks],
        "words": words, "catalog": sorted(catalog),
        "added": [[key, str(symbol)] for key, symbol in space.added.items()],
        "values": [[key, value] for key, value in space.cache.items()],
        "retained": list(retained), "certificates": list(certificates),
        "bmn": bmn_info}


def _open_compiled(compiled, canonical):
    space = _MomentSpace(compiled["result"], canonical)
    key = lambda factors: tuple(tuple(word) for word in factors)
    for factors, name in compiled["added"]:
        symbol = sp.Symbol(name, real=True)
        space.symbols[name] = symbol
        space.coordinates[key(factors)] = space.rows.from_expr(symbol)
        space.definitions[symbol] = key(factors)
        space.added[key(factors)] = symbol
    space.cache = {key(factors): value for factors, value in compiled["values"]}
    blocks = [(row["name"], row["kind"], AffineMatrix(row["size"], row["size"],
               {(i, j): value for i, j, value in row["entries"]}), row["labels"], row["latex"])
              for row in compiled["blocks"]]
    return space, blocks, tuple(tuple(word) for word in compiled["words"]), {key(pair) for pair in compiled["catalog"]}


def _model_key(request):
    return stable_digest({"version": COMPILED_MODEL_VERSION, "canonical": ALGORITHM_VERSION,
        "sympy": sp.__version__, "model": request["model"], "level": request["level"],
        "constraints": request["constraints"], "charge_neutral": request["charge_neutral"],
        "bmn_su3_reduction": request.get("preparation", {}).get("bmn_su3_reduction", False)})


def _null_model_key(compiled, canonical, check):
    """Identify the exact unfixed pencil, independently of storage versions.

    Only exact numeric coefficients are encoded here, once per distinct number
    and row. No affine formula is reconstructed or printed.
    """
    space, blocks, _, _ = _open_compiled(compiled, canonical)
    numbers, rows = {}, {}

    def row_key(row):
        if row not in rows:
            encoded = []
            for symbol, number in row.items():
                check()
                if number not in numbers:
                    numbers[number] = (["Q", str(number.p), str(number.q)] if number.is_Rational
                                       else ["exact", sp.srepr(number)])
                encoded.append([None if symbol is None else symbol.name, numbers[number]])
            rows[row] = stable_digest(encoded)
        return rows[row]

    result = compiled["result"]
    return stable_digest({
        "model": result["model"], "settings": result["settings"],
        "constraints": result.get("constraints", {}).get("config"),
        "variables": [[symbol.name, space.definitions[symbol]] for symbol in space.variables()],
        "blocks": [[kind, matrix.rows, matrix.cols,
                    [[i, j, row_key(value)] for (i, j), value in sorted(matrix.todok().items())]]
                   for _, kind, matrix, _, _ in blocks],
        "coordinates": [[key, row_key(value)] for key, value in sorted(space.coordinates.items())],
        "bmn": bool(compiled["bmn"]),
    })


def _prior_null_records(cache, stage):
    """List compact pre-migration records without reading any model payload."""
    if not cache or cache.connection is None:
        return []
    try:
        with cache.lock:
            records = cache.connection.execute(
                "SELECT stage, key FROM stage_cache WHERE stage LIKE ? ORDER BY updated_at, key",
                (f"%:{stage}",)).fetchall()
    except sqlite3.Error:
        return []
    return [(name.rsplit(":", 1)[0], key) for name, key in records
            if name != f"{NULL_PLAN_CACHE_NAMESPACE}:{stage}"]


def _legacy_null_model_key(compiled, canonical, check):
    """Recreate the historical hash only at the one-time upgrade boundary."""
    from .display import ExpressionRecords
    printer = ExpressionRecords(check)
    text = {}

    def render(value):
        if value not in text:
            text[value] = printer.text(value.as_expr())
        return text[value]

    result = compiled["result"]
    if compiled["bmn"]:
        from .bmn_reduction import REDUCTION_VERSION, bmn_species_mapping
        mapping = bmn_species_mapping(canonical.model)
        basis = [tuple(mapping[abs(t)] * (1 if t > 0 else -1) for t in row["tokens"])
                 for row in result["basis"]]
        # These are precisely the old projection-key fields. The explicit text
        # adapter preserves legacy metadata and formula formatting at this
        # migration boundary; it is never used by point preparation.
        legacy = text_artifact({key: result[key] for key in ("variables", "blocks", "moments")},
                               include_display=False)
        projection = stable_digest({"version": REDUCTION_VERSION, "canonical": ALGORITHM_VERSION,
            "sympy": sp.__version__, "basis": basis,
            "variables": legacy["variables"], "blocks": legacy["blocks"]})
        return stable_digest({"projection": projection, "model": result["model"],
            "level": result["settings"]["level"],
            "moments": [{key: row[key] for key in ("id", "traces", "real")} for row in legacy["moments"]],
            "relaxation": BMN_RELAXATION_VERSION})
    space, raw_blocks, _, _ = _open_compiled(compiled, canonical)
    expressions, indices, blocks = [], {}, []
    # The previous equivalence key preceded auxiliary-adjoint closure. Every
    # auxiliary coordinate created by relaxation occurs in its Schur/diagonal
    # blocks; closure-only coordinates must not enter this historical key.
    original_names = {row["name"] for row in result["variables"]}
    visible = set().union(*(row[2].free_symbols for row in raw_blocks))
    variables = [s.name for s in space.variables() if s.name in original_names or s in visible]
    for _, _, matrix, _, _ in raw_blocks:
        entries = []
        for (i, j), value in sorted(matrix.todok().items()):
            check()
            if value not in indices:
                indices[value] = len(expressions)
                expressions.append(render(value))
            entries.append([i, j, indices[value]])
        blocks.append([matrix.rows, matrix.cols, entries])
    return stable_digest({"version": MODEL_EQUIVALENCE_VERSION, "sympy": sp.__version__,
                          "variables": variables, "expressions": expressions, "blocks": blocks})


def _ensure_null_identity(compiled, canonical, cache, notify, check):
    """Attach stable scientific identity once, including any legacy lookup."""
    if "null_plan_identity" in compiled:
        return False
    stage = "bmn_su3_null_plan" if compiled["bmn"] else "null_direction_plan"
    identity = {"model": _null_model_key(compiled, canonical, check), "legacy_model": None}
    if _prior_null_records(cache, stage):
        notify({"stage": "cache", "message": "Preserving the existing null-direction scan baseline."})
        identity["legacy_model"] = _legacy_null_model_key(compiled, canonical, check)
    compiled["null_plan_identity"] = identity
    return True


def _load_null_plan(cache, stage, version, identity, transitional_model, fixed_terms):
    """Adopt an exact legacy match before a transitional rewrite-era record."""
    def key(model):
        return stable_digest({"version": version, "model": model, "fixed_terms": fixed_terms})
    null_key = key(identity["model"])
    saved = cache.get(stage, null_key)
    if saved is not None:
        return null_key, saved
    records = _prior_null_records(cache, stage)
    for model in (identity["legacy_model"], transitional_model):
        if model is None:
            continue
        previous_key = key(model)
        for namespace, stored_key in records:
            if stored_key != previous_key:
                continue
            current_namespace = cache.version
            try:
                cache.version = namespace
                saved = cache.get(stage, previous_key)
            finally:
                cache.version = current_namespace
            if saved is not None:
                cache.put(stage, null_key, saved)
                return null_key, saved
    return null_key, None


def prepare_request_data(request, *, cache_path=None, limits=BuildLimits(), progress=None,
                         check_cancelled=None, preview_limit=None):
    """Load one atomic model checkpoint, then run one point-preparation path."""
    notify, check = progress or (lambda _: None), check_cancelled or (lambda: None)
    model = Model.from_dict(request["model"])
    config = validate_preparation(request.get("preparation"), model, request["level"])
    key = _model_key(request)
    manager = BuildCache(Path(cache_path).with_name("build.sqlite3")) if cache_path is not None else nullcontext(None)
    canonical_cache = CanonicalCache(cache_path, model) if cache_path is not None else None
    try:
        canonical = Canonicalizer(model, canonical_cache, check)
        with manager as cache:
            def construct():
                result = build_moment_data(model, request["level"], charge_neutral=request["charge_neutral"],
                    constraints=request["constraints"], cache_path=cache_path, limits=limits,
                    progress=notify, check_cancelled=check, stage_cache=cache)
                return _compile_model(result, canonical, config, notify, check)
            compiled, state = _checkpoint(cache, key, construct, canonical, notify, check)
            result = dict(compiled["result"])
            result["preparation"] = _prepare_point(compiled, canonical, config, cache_path=cache_path,
                model_key=key, progress=notify, check_cancelled=check, preview_limit=preview_limit)
            result["preparation"]["cache"]["compiled_model"] = state
            result["build_cache"] = {"compiled_model": state}
            return result
    finally:
        if canonical_cache is not None:
            canonical_cache.close()


def prepare_sdp(result, config=None, *, cache_path=None, progress=None, check_cancelled=None,
                cache_stages=False, preview_limit=None, expression_values=None, canonical_moment_sources=False):
    """Explicit legacy text boundary around the coefficient-native algorithm.

    Historical cache/transport keywords remain accepted for Python callers.
    They do not select alternate algorithms or create formula caches.
    """
    return text_artifact(prepare_sdp_data(load_artifact(result, check=check_cancelled or (lambda: None)),
        config, cache_path=cache_path, progress=progress, check_cancelled=check_cancelled,
        preview_limit=preview_limit), preview_limit=preview_limit)


def prepare_sdp_data(result, config=None, *, cache_path=None, progress=None,
                     check_cancelled=None, preview_limit=None):
    notify, check = progress or (lambda _: None), check_cancelled or (lambda: None)
    model = Model.from_dict(result["model"])
    config = validate_preparation(config, model, result["settings"]["level"])
    canonical_cache = CanonicalCache(cache_path, model) if cache_path is not None else None
    manager = BuildCache(Path(cache_path).with_name("build.sqlite3")) if cache_path is not None else nullcontext(None)
    try:
        canonical = Canonicalizer(model, canonical_cache, check)
        # External moments may be edited: identify their exact contents at this
        # boundary. Normal build requests use their much smaller input key.
        key = stable_digest({"version": COMPILED_MODEL_VERSION,
            "base": pack_artifact(result, check=check)["digest"],
            "bmn": config.get("bmn_su3_reduction", False)}) if cache_path is not None else None
        with manager as cache:
            compiled, state = _checkpoint(cache, key,
                lambda: _compile_model(result, canonical, config, notify, check), canonical, notify, check)
        prepared = _prepare_point(compiled, canonical, config, cache_path=cache_path, model_key=key,
            progress=notify, check_cancelled=check, preview_limit=preview_limit)
        prepared["cache"]["compiled_model"] = state
        return prepared
    finally:
        if canonical_cache is not None:
            canonical_cache.close()


def _validate_compiled(compiled, canonical):
    """Validate the complete structural record before any cached removal."""
    if not isinstance(compiled, dict) or set(compiled) - {"null_plan_identity"} != {
            "result", "blocks", "words", "catalog", "added", "values", "retained", "certificates", "bmn"}:
        raise ValueError("Invalid compiled-model schema.")
    if "null_plan_identity" in compiled:
        identity = compiled["null_plan_identity"]
        if (not isinstance(identity, dict) or set(identity) != {"model", "legacy_model"}
                or any(not isinstance(value, str) or len(value) != 64
                       or any(c not in "0123456789abcdef" for c in value)
                       for value in (identity["model"],) + (
                           () if identity["legacy_model"] is None else (identity["legacy_model"],)))):
            raise ValueError("Invalid null-plan model identity.")
    if compiled["result"]["model"] != canonical.model.to_dict():
        raise ValueError("Compiled model mismatch.")
    if any(not isinstance(row.get("_affine_value"), AffineRow)
           for row in compiled["result"]["canonical_traces"]):
        raise ValueError("Compiled canonical traces require exact coefficient rows.")
    blocks, retained, certificates = compiled["blocks"], compiled["retained"], compiled["certificates"]
    if not isinstance(blocks, list) or not isinstance(retained, list) or not isinstance(certificates, list):
        raise ValueError("Invalid compiled block metadata.")
    count = len(blocks)
    if (any(type(i) is not int or not 0 <= i < count for i in retained)
            or retained != sorted(set(retained))):
        raise ValueError("Invalid retained blocks.")
    matrices = []
    for block in blocks:
        canonical.check_cancelled()
        size = block["size"]
        if (type(size) is not int or size < 0 or not isinstance(block["labels"], list)
                or not isinstance(block["latex"], list)
                or len(block["labels"]) != size or len(block["latex"]) != size
                or any(not isinstance(label, str) for label in (*block["labels"], *block["latex"]))):
            raise ValueError("Invalid compiled block labels or dimensions.")
        entries = {(i, j): value for i, j, value in block["entries"]}
        if len(entries) != len(block["entries"]):
            raise ValueError("Duplicate compiled matrix position.")
        matrices.append(AffineMatrix(size, size, entries))
    seen = set(retained)
    for certificate in certificates:
        canonical.check_cancelled()
        removed, kept, permutation = (certificate[key] for key in ("removed_index", "retained_index", "permutation"))
        if (type(removed) is not int or not 0 <= removed < count or removed in seen
                or type(kept) is not int or kept not in retained
                or blocks[removed]["size"] != blocks[kept]["size"]
                or not isinstance(permutation, list)
                or any(type(i) is not int for i in permutation)
                or sorted(permutation) != list(range(blocks[removed]["size"]))):
            raise ValueError("Invalid block-equivalence certificate.")
        inverse = {target: source for source, target in enumerate(permutation)}
        permuted = {(inverse[i], inverse[j]): value
                    for (i, j), value in matrices[kept].todok().items()}
        if matrices[removed].todok() != permuted:
            raise ValueError("A cached permutation does not certify equal PSD blocks.")
        seen.add(removed)
    if seen != set(range(count)):
        raise ValueError("Incomplete block-equivalence coverage.")
    _open_compiled(compiled, canonical)


def _checkpoint(cache, key, construct, canonical, notify, check):
    """Only cache decision: restore a complete model or build it completely."""
    saved = cache.get("compiled_model", key) if cache else None
    compiled = None
    if saved is not None:
        try:
            compiled = load_artifact(saved, check=check)
            _validate_compiled(compiled, canonical)
        except (KeyError, TypeError, ValueError, IndexError, AttributeError):
            compiled = None
    if compiled is not None:
        if cache and _ensure_null_identity(compiled, canonical, cache, notify, check):
            cache.put("compiled_model", key, pack_artifact(compiled, check=check))
        notify({"stage": "cache", "message": "Loaded the complete exact model checkpoint."})
        return compiled, "hit"
    compiled = construct()
    check()
    if cache:
        _ensure_null_identity(compiled, canonical, cache, notify, check)
        notify({"stage": "saving_model", "message": "Saving the complete exact model checkpoint."})
        encoded = pack_artifact(compiled, check=check)
        check()
        cache.put("compiled_model", key, encoded)
    return compiled, "miss" if cache else "disabled"


def _prepare_point(compiled, canonical, config, *, cache_path=None, model_key=None,
                   progress=None, check_cancelled=None, preview_limit=None):
    """Apply point constraints and reduce exact coefficient rows; never format."""
    started = time.perf_counter()
    result = compiled["result"]
    model, level = canonical.model, result["settings"]["level"]
    notify, check = progress or (lambda _: None), check_cancelled or (lambda: None)
    space, raw_blocks, covariance_words, catalog = _open_compiled(compiled, canonical)
    retained, before_certificates, bmn_info = compiled["retained"], compiled["certificates"], compiled["bmn"]
    cache_info = {}
    notify({"stage": "factorization", "message": "Preparing the fixed-observable and adjoint equations."})
    fixed, inequalities = [], []
    for row in config["fixed_observables"]:
        expression = space.combine((exact_coefficient(term["coefficient"]),
                                  space.value((tuple(term["word"]),))) for term in row["terms"])
        destination = fixed if row.get("relation", "=") == "=" else inequalities
        destination.append((row, expression, exact_coefficient(row["value"])))
    optimization = config.get("optimization")
    objective = space.rows.zero if optimization is None else space.combine(
        (exact_coefficient(term["coefficient"]), space.value((tuple(term["word"]),)))
        for term in optimization["objective"]["terms"])
    cutoff_observables = (_bmn_cutoff_observables(model, level)
                          if "bmn_observable_cutoff" in config else [])
    cutoff_expressions = [space.value((tuple(row["tokens"]),)) for row in cutoff_observables]
    fixed_terms = [row["terms"] for row, _, _ in fixed]
    fixed_equations, factorization = _fixed_equations(space, fixed, catalog, check)
    adjoint_equations = space.adjoint_equations()
    all_equations = fixed_equations + factorization + adjoint_equations
    variables = space.variables()
    substitutions, rank = solve_affine_equalities(all_equations, variables, check=check, row_factory=space.rows)
    notify({"stage": "factorization", "message": "Applying the fixed-observable equations to PSD blocks."})
    remaining = tuple(v for v in variables if v not in substitutions)
    source_terms = _AffineTerms(variables, check)
    coefficient_terms = source_terms if remaining == variables else _AffineTerms(remaining, check)
    substitute = AffineSubstitution(variables, remaining, substitutions,
        source_terms=source_terms, target_terms=coefficient_terms, check=check)
    compressed, full_rank_sources = [], []
    plan_manager = (BuildCache(Path(cache_path).with_name("build.sqlite3"))
                    if model_key is not None and cache_path is not None else nullcontext(None))
    with plan_manager as plan_cache:
        if plan_cache:
            plan_cache.version = NULL_PLAN_CACHE_NAMESPACE
        null_version, null_stage = NULL_PLAN_VERSION, "null_direction_plan"
        if bmn_info:
            from .bmn_reduction import NULL_VERSION
            null_version, null_stage = NULL_VERSION, "bmn_su3_null_plan"
        null_key, saved = None, None
        if plan_cache:
            _ensure_null_identity(compiled, canonical, plan_cache, notify, check)
            null_key, saved = _load_null_plan(plan_cache, null_stage, null_version,
                compiled["null_plan_identity"], model_key, fixed_terms)
        saved_blocks = saved.get("blocks", {}) if isinstance(saved, dict) else {}
        plans = ({str(i): saved_blocks[str(i)] for i in retained if str(i) in saved_blocks}
                 if isinstance(saved_blocks, dict) else {})
        had_plans, reused_count, rejected_count = bool(plans), 0, 0
        for completed, source_index in enumerate(retained, 1):
            check()
            block_key = str(source_index)
            notify({"stage": "null_directions", "completed": completed - 1, "total": len(retained),
                    "message": (f"Checking cached reduction for PSD block {completed} of {len(retained)}."
                                if block_key in plans else f"Reducing PSD block {completed} of {len(retained)}.")})
            name, kind, original, labels, latex = raw_blocks[source_index]
            matrix = original.applyfunc(substitute)
            full_rank_sources.append(matrix)
            def save_plan(rows, reused):
                nonlocal reused_count, rejected_count
                reused_count += int(reused)
                rejected_count += int(not reused and block_key in plans and plans[block_key] == rows)
                if plans.get(block_key) != rows:
                    plans[block_key] = rows
                    if plan_cache:
                        plan_cache.put(null_stage, null_key, {"blocks": plans})
            item = compress_psd_block(matrix, remaining, check=check,
                row_plan=plans.get(block_key), plan_callback=save_plan,
                coefficient_terms=coefficient_terms)
            item.update(name=name, kind=kind, source_index=source_index,
                        labels=[labels[i] for i in item["kept_indices"]],
                        labels_latex=[latex[i] for i in item["kept_indices"]])
            compressed.append(item)
        cache_info["null_direction_plan"] = ("disabled" if not plan_cache else
            "hit" if had_plans and reused_count == len(retained) else
            "partial" if reused_count else "retained_full" if rejected_count else
            "rebuilt" if had_plans else "miss")
        if bmn_info:
            cache_info["bmn_su3_null_plan"] = cache_info["null_direction_plan"]
    notify({"stage": "scalar_coordinates", "message": "Selecting independent SDP variables."})
    dropped, selected, scalar_kernel, parameter_order = _scalar_coordinates(
        [item["matrix"] for item in compressed], remaining, check, substitute(objective),
        coefficient_terms=coefficient_terms, full_rank_sources=full_rank_sources,
        additional_expressions=[substitute(expression) for expression in
            [*cutoff_expressions, *(expression for _, expression, _ in inequalities)]])
    notify({"stage": "preparation_output", "message": "Assembling the prepared coefficient blocks."})
    record = _expression_record

    @lru_cache(maxsize=None)
    def select_coordinates(value):
        value = space.parse(value)
        return space.rows.select(value, selected) if dropped else value

    blocks, relaxation_index = [], 0
    for completed, item in enumerate(compressed, 1):
        check()
        notify({"stage": "preparation_output", "completed": completed - 1,
                "total": len(compressed),
                "message": f"Assembling PSD block {completed} of {len(compressed)}."})
        matrix = item["matrix"].applyfunc(select_coordinates)
        name = item["name"]
        if item["kind"] != "moment":
            relaxation_index += 1
            name = f"Multitrace relaxation block {relaxation_index}"
        blocks.append({"name": name, "kind": item["kind"], "source_index": item["source_index"],
            **({"su3": bmn_info["sectors"][item["source_index"]]} if bmn_info and item["kind"] == "moment" else {}),
            "original_size": item["original_size"],
            "size": matrix.rows, "kept_indices": list(item["kept_indices"]),
            "removed_nullity": item["removed_nullity"], "labels": item["labels"], "labels_latex": item["labels_latex"],
            "nullspace": [[str(value) for value in vector] for vector in item["nullspace"]],
            "entries": [{"row": i, "col": j, **record(value)}
                        for (i, j), value in sorted(matrix.todok().items()) if value]})
        notify({"stage": "preparation_output", "completed": completed,
                "total": len(compressed),
                "message": f"Assembled PSD block {completed} of {len(compressed)}."})
    sizes = {item["source_index"]: item["matrix"].rows for item in compressed}
    for certificate in before_certificates:
        sizes[certificate["removed_index"]] = sizes[certificate["retained_index"]]
    original_dimension = sum(row[2].rows for row in raw_blocks)
    null_compressed_dimension = sum(sizes.values())
    final_dimension = sum(b["size"] for b in blocks)
    def certificate_record(certificate, indices):
        return {"removed_source_index": indices[certificate["removed_index"]],
                "retained_source_index": indices[certificate["retained_index"]],
                "permutation": list(certificate["permutation"])}
    block_reduction = {
        "source_block_count": len(raw_blocks),
        "before_compression": [certificate_record(c, tuple(range(len(raw_blocks)))) for c in before_certificates],
        "after_compression": [],
        "omitted_compressed_blocks": [],
    }
    if bmn_info:
        block_reduction["method"] = "BMN SU(3)"
    notify({"stage": "moment_reconstruction",
            "message": "Preparing the moment reconstruction and observable expressions."})
    representatives = {symbol: select_coordinates(substitutions.get(symbol, symbol)) for symbol in variables}
    reconstruction = [{"symbol": str(symbol), **record(representatives[symbol],
        preview_limit is None or i < preview_limit)} for i, symbol in enumerate(variables)]
    lifted_kernel = _reconstruction_directions(variables, substitutions, parameter_order, scalar_kernel, check)
    reconstruction_nullspace = [[str(value) for value in vector] for vector in lifted_kernel]
    free_parameters = [sp.Symbol(f"t{i + 1}", real=True) for i in range(len(scalar_kernel))]
    full_reconstruction = {symbol: space.combine([(1, representatives[symbol]),
        *((vector[i], parameter) for vector, parameter in zip(lifted_kernel, free_parameters))])
        for i, symbol in enumerate(variables)}
    preview_counts = {}
    loop_equations = _loop_equations(result, space, full_reconstruction, check, record,
        preview_limit=None, counts=preview_counts,
        required_words=([term["word"] for term in optimization["objective"]["terms"]] if optimization else [])
            + [row["tokens"] for row in cutoff_observables]
            + [term["word"] for row, _, _ in inequalities for term in row["terms"]])
    equalities = []
    for equation in dict.fromkeys(all_equations):
        if equation:
            row = record(equation, preview_limit is None or len(equalities) < preview_limit)
            equalities.append({**row, **({"latex": row["latex"] + " = 0"} if "latex" in row else {})})
    final_objective = select_coordinates(substitute(objective))
    inequality_records = []
    for row, expression, target in inequalities:
        expression = select_coordinates(substitute(expression))
        residual = space.combine(((1, target), (-1, expression))) if row["relation"] == "<=" else space.combine(((1, expression), (-1, target)))
        inequality_records.append({"name": row["name"], "value": str(target),
            "value_latex": sp.latex(target), "relation": row["relation"],
            **record(expression), "residual": record(residual)})
    cutoff_info = {"enabled": bool(cutoff_observables)}
    if cutoff_observables:
        cutoff = exact_coefficient(config["bmn_observable_cutoff"])
        for row, expression in zip(cutoff_observables, cutoff_expressions):
            expression = select_coordinates(substitute(expression))
            upper_bound = space.combine(((1, cutoff), (-1, expression)))
            row.update(record(expression), upper_bound=record(upper_bound))
        cutoff_info.update(value=str(cutoff), value_latex=sp.latex(cutoff), observables=cutoff_observables)
    prepared = {"status": "prepared", "config": config,
        "bmn_observable_cutoff": cutoff_info,
        "observable_inequalities": inequality_records,
        **({"bmn_su3_reduction": {k: v for k, v in bmn_info.items() if k != "sectors"}} if bmn_info else {}),
        "optimization": {"mode": "feasibility" if optimization is None else optimization["mode"],
            **({"name": optimization["objective"]["name"]} if optimization else {}),
            **record(final_objective)},
        "summary": {"original_variable_count": len(variables), "remaining_variable_count": len(selected),
            "equality_rank": rank, "factorization_equation_count": len(factorization),
            "covariance_word_count": len(covariance_words), "block_count": sum(b["size"] > 0 for b in blocks),
            "original_psd_dimension": original_dimension,
            "null_compressed_psd_dimension": null_compressed_dimension,
            "compressed_psd_dimension": final_dimension,
            "redundant_block_count": len(before_certificates),
            "removed_redundant_psd_dimension": null_compressed_dimension - final_dimension,
            "maximum_block_size": max((b["size"] for b in blocks), default=0),
            "removed_nullity": original_dimension - null_compressed_dimension,
            "removed_scalar_directions": len(dropped), "elapsed_seconds": time.perf_counter() - started},
        "variables": [{"name": str(s), "meaning": _moment_text(model, space.definitions[s]),
            "meaning_latex": r"\left\langle " + " ".join(r"\operatorname{tr}(" + _word_latex(model, w) + ")"
                for w in space.definitions[s]) + r"\right\rangle"} for s in selected],
        "fixed_observables": [{"name": row["name"], "value": str(target), "value_latex": sp.latex(target),
                               **record(expression)} for row, expression, target in fixed],
        "covariance_words": [{"tokens": list(word), "text": model.word_text(word)} for word in covariance_words],
        "equalities": equalities,
        "reconstruction": reconstruction, "blocks": blocks, "block_reduction": block_reduction,
        "moment_reductions": loop_equations,
        **({"preview_counts": preview_counts} if preview_limit is not None else {}),
        "loop_free_parameters": [{"name": str(s), "latex": sp.latex(s)} for s in free_parameters],
        "scalar_coordinate_reduction": {"representative": "Dropped PSD-invisible parameters are set to zero only to select coordinates.",
            "parameter_order": [str(s) for s in parameter_order],
            "nullspace": [[str(value) for value in vector] for vector in scalar_kernel],
            "reconstruction_symbol_order": [str(s) for s in variables],
            "reconstruction_nullspace": reconstruction_nullspace},
        "scope": "Exact affine PSD preparation; no numerical feasibility or optimization has been performed."}
    prepared["cache"] = cache_info
    _apply_observable_inequalities(prepared, check)
    if "bmn_observable_cutoff" in config:
        notify({"stage": "bmn_observable_cutoff", "message": "Adding the two BMN observable upper bounds."})
        check()
    _apply_bmn_observable_cutoff(prepared, config, check)
    prepared["summary"]["elapsed_seconds"] = time.perf_counter() - started
    return prepared
