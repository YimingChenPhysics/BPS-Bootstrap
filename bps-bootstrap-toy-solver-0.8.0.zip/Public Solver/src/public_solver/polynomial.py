"""Sparse exact linear combinations of normalized trace products.

A product key labels one multi-trace expectation, not a nonlinear product of
single-trace expectation values. The empty product is the scalar identity.
"""

from fractions import Fraction
from typing import Mapping

from .model import Model, Word

TraceProduct = tuple[Word, ...]
Polynomial = dict[TraceProduct, Fraction]


def add(target: Polynomial, source: Mapping[TraceProduct, Fraction], scale: Fraction = Fraction(1)) -> None:
    for key, coefficient in source.items():
        value = target.get(key, Fraction(0)) + scale * coefficient
        if value:
            target[key] = value
        else:
            target.pop(key, None)


def ordered_product(model: Model, factors: TraceProduct) -> tuple[TraceProduct, int]:
    """Leading large-N trace products supercommute; odd factors keep their signs."""
    factors = tuple(w for w in factors if w)
    order = lambda w: (len(w), model.word_key(w))
    sign = 1
    for i, left in enumerate(factors):
        if not model.parity(left):
            continue
        for right in factors[i + 1:]:
            if model.parity(right):
                if left == right:
                    return (), 0
                if order(left) > order(right):
                    sign = -sign
    return tuple(sorted(factors, key=order)), sign


def multiply(model: Model, left: Polynomial, right: Polynomial) -> Polynomial:
    result: Polynomial = {}
    for a, ca in left.items():
        for b, cb in right.items():
            key, sign = ordered_product(model, a + b)
            if sign:
                add(result, {key: ca * cb * sign})
    return result


def encode(polynomial: Polynomial) -> list:
    return [{"traces": [list(w) for w in key], "coefficient": str(value)}
            for key, value in sorted(polynomial.items())]


def decode(value: list, model: Model) -> Polynomial:
    if not isinstance(value, list):
        raise ValueError("Invalid polynomial cache.")
    result: Polynomial = {}
    for term in value:
        if set(term) != {"traces", "coefficient"}:
            raise ValueError("Invalid polynomial term.")
        key = tuple(model.validate_word(tuple(w)) for w in term["traces"])
        ordered, sign = ordered_product(model, key)
        if key != ordered or sign != 1:
            raise ValueError("Invalid cached trace order.")
        add(result, {key: Fraction(term["coefficient"])})
    return result

