"""The six generic controls exposed by the numerical solver interface."""

from decimal import Decimal, InvalidOperation
import math


DEFAULT_SETTINGS = {"precision": 384, "epsilon": "1e-14", "lambda_star": "2",
                    "beta_star": "0.1", "beta_bar": "0.2", "max_iterations": 500}


def validate_settings(raw=None):
    if raw is None:
        raw = {}
    if not isinstance(raw, dict) or set(raw) - DEFAULT_SETTINGS.keys():
        raise ValueError("Unknown numerical solver settings.")
    result = {**DEFAULT_SETTINGS, **raw}
    for key, lower, upper in (("precision", 32, 4096), ("max_iterations", 1, 100000)):
        value = result[key]
        if isinstance(value, bool) or not isinstance(value, (int, str)):
            raise ValueError(f"{key} must be an integer between {lower} and {upper}.")
        try:
            number = int(value)
        except (ValueError, TypeError) as exc:
            raise ValueError(f"Invalid {key}.") from exc
        if str(value).strip() != str(number) or not lower <= number <= upper:
            raise ValueError(f"{key} must be an integer between {lower} and {upper}.")
        result[key] = number
    numbers = {}
    for key in ("epsilon", "lambda_star", "beta_star", "beta_bar"):
        value = result[key]
        if isinstance(value, bool) or not isinstance(value, (str, int, float)) or len(str(value)) > 128:
            raise ValueError(f"{key} must be a positive finite number.")
        try:
            number = Decimal(str(value))
            machine_value = float(number)
        except (InvalidOperation, ValueError, OverflowError) as exc:
            raise ValueError(f"Invalid {key}.") from exc
        if not number.is_finite() or number <= 0 or not math.isfinite(machine_value) or machine_value <= 0:
            raise ValueError(f"{key} must be positive and representable as a finite solver control.")
        numbers[key] = number
        result[key] = str(value).strip()
    if not 0 < numbers["beta_star"] <= numbers["beta_bar"] < 1:
        raise ValueError("Require 0 < beta_star <= beta_bar < 1.")
    return result
