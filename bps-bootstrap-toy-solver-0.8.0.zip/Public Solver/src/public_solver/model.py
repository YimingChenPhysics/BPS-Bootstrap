"""Immutable user definitions; positive tokens create, negative tokens annihilate.

Names are presentation data. Neither case nor the presence of a bar determines
the oscillator action internally. No process-global species registry is used.
"""

from dataclasses import dataclass
from fractions import Fraction
import hashlib
import json
import re
from typing import Any

Word = tuple[int, ...]
_NUMBER = re.compile(r"[+-]?(?:\d+/[+-]?\d+|(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)\Z")


def exact_charge(value: Any) -> Fraction:
    if isinstance(value, bool) or not isinstance(value, (str, int, Fraction)):
        raise ValueError("Charges must be integers or exact number strings, such as '1/2'.")
    text = str(value).strip()
    if len(text) > 2048 or not _NUMBER.fullmatch(text):
        raise ValueError(f"Invalid charge {text!r}; use a number such as 0, -1, or 1/2.")
    if "e" in text.lower() and abs(int(text.lower().split("e")[1])) > 100:
        raise ValueError("Charge exponents must lie between -100 and 100.")
    try:
        result = Fraction(*(int(part) for part in text.split("/"))) if "/" in text else Fraction(text)
    except (ValueError, ZeroDivisionError) as exc:
        raise ValueError(f"Invalid charge {text!r}.") from exc
    if result.numerator.bit_length() > 1024 or result.denominator.bit_length() > 1024:
        raise ValueError("Charge numerators and denominators must fit within 1024 bits.")
    return result


@dataclass(frozen=True)
class Species:
    name: str
    statistics: str
    charges: tuple[Fraction, ...] = ()

    def __post_init__(self) -> None:
        # A display name is LaTeX, never an algebra token or executable input.
        # The browser validates supported LaTeX; batch/Python clients preserve it.
        if (not isinstance(self.name, str) or not 1 <= len(self.name.strip()) <= 128
                or any(ord(c) < 32 or c in "<>$" for c in self.name)
                or not any(c.isalpha() for c in self.name)):
            raise ValueError(r"Use a LaTeX letter name of 1–128 characters, such as X or \psi_{1}, without $ delimiters.")
        object.__setattr__(self, "name", self.name.strip())
        if self.statistics not in {"boson", "fermion"}:
            raise ValueError("Statistics must be 'boson' or 'fermion'.")
        object.__setattr__(self, "charges", tuple(exact_charge(x) for x in self.charges))

    @property
    def fermionic(self) -> bool:
        return self.statistics == "fermion"


@dataclass(frozen=True)
class Model:
    species: tuple[Species, ...]
    charge_names: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "species", tuple(self.species))
        object.__setattr__(self, "charge_names", tuple(self.charge_names))
        if not 1 <= len(self.species) <= 24 or not all(isinstance(s, Species) for s in self.species):
            raise ValueError("Define between 1 and 24 letters.")
        if len({s.name for s in self.species}) != len(self.species):
            raise ValueError("Letter names must be unique.")
        if len(self.charge_names) > 8:
            raise ValueError("At most 8 charges are supported by this interface.")
        if any(not isinstance(x, str) or not x.strip() or len(x) > 24 for x in self.charge_names):
            raise ValueError("Charge names must be nonempty strings of at most 24 characters.")
        if len(set(self.charge_names)) != len(self.charge_names):
            raise ValueError("Charge names must be unique.")
        if any(len(s.charges) != len(self.charge_names) for s in self.species):
            raise ValueError("Every letter must specify one value for each charge.")

    @classmethod
    def from_dict(cls, value: dict) -> "Model":
        if not isinstance(value, dict) or set(value) - {"species", "charge_names"}:
            raise ValueError("A model contains only species and charge_names.")
        rows = value.get("species")
        names = value.get("charge_names", [])
        if not isinstance(rows, list) or not isinstance(names, list):
            raise ValueError("species and charge_names must be lists.")
        species = []
        for row in rows:
            if not isinstance(row, dict) or set(row) != {"name", "statistics", "charges"}:
                raise ValueError("Each letter requires name, statistics, and charges.")
            if not isinstance(row["charges"], list):
                raise ValueError("Letter charges must be a list.")
            species.append(Species(row["name"], row["statistics"], tuple(row["charges"])))
        return cls(tuple(species), tuple(names))

    def to_dict(self) -> dict:
        return {"species": [{"name": s.name, "statistics": s.statistics,
                             "charges": [str(x) for x in s.charges]} for s in self.species],
                "charge_names": list(self.charge_names)}

    @property
    def alphabet(self) -> tuple[int, ...]:
        return tuple(t for i in range(1, len(self.species) + 1) for t in (i, -i))

    def validate_word(self, word: Word) -> Word:
        word = tuple(word)
        if any(type(t) is not int or t == 0 or abs(t) > len(self.species) for t in word):
            raise ValueError("A word must contain signed, nonzero species IDs from this model.")
        return word

    def parity(self, word: Word) -> int:
        return sum(self.species[abs(t) - 1].fermionic for t in word) % 2

    def charge(self, word: Word) -> tuple[Fraction, ...]:
        total = [Fraction(0) for _ in self.charge_names]
        for t in word:
            for j, q in enumerate(self.species[abs(t) - 1].charges):
                total[j] += q if t > 0 else -q
        return tuple(total)

    def word_key(self, word: Word) -> tuple:
        return tuple((t < 0, abs(t)) for t in word)

    def word_text(self, word: Word) -> str:
        return " ".join(self.species[abs(t) - 1].name if t > 0 else
                        f"bar({self.species[-t - 1].name})" for t in word) or "1"

    def fingerprint(self) -> str:
        return hashlib.sha256(json.dumps(self.to_dict(), sort_keys=True).encode()).hexdigest()


def adjoint_word(word: Word) -> Word:
    return tuple(-t for t in reversed(word))
