"""One self-contained exact affine artifact, with text only at its boundaries.

The coefficient rows are the mathematical authority. Formula strings are
accepted only by the legacy importer and produced only by the renderer.
"""

import hashlib
import json
import math

import sympy as sp

from .affine import _validated_number
from .affine_data import AffineRow, AffineRows


ARTIFACT_VERSION = "exact-affine-artifact-v1"
_ROW = "$affine_row"
_DICT = "$mapping"
_CONSTANTS = {"pi": sp.pi, "E": sp.E, "I": sp.I, "EulerGamma": sp.EulerGamma,
              "Catalan": sp.Catalan, "GoldenRatio": sp.GoldenRatio}
_FUNCTIONS = {function.__name__: function for function in (
    sp.Abs, sp.exp, sp.log, sp.sin, sp.cos, sp.tan, sp.asin, sp.acos, sp.atan,
    sp.atan2, sp.sinh, sp.cosh, sp.tanh, sp.asinh, sp.acosh, sp.atanh,
    sp.erf, sp.erfc, sp.gamma, sp.loggamma)}


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
        separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()


def pack_artifact(data, *, check=lambda: None):
    """Intern exact numbers and affine rows once across the complete artifact."""
    if not isinstance(data, dict):
        raise ValueError("An exact artifact must contain an object.")
    rows, row_indices, symbols = [], {}, set()

    def collect(value):
        check()
        if isinstance(value, AffineRow):
            if value not in row_indices:
                row_indices[value] = len(rows)
                rows.append(value)
                symbols.update(value.free_symbols)
        elif isinstance(value, dict):
            for key, child in value.items():
                if not isinstance(key, str):
                    raise ValueError("Artifact mapping keys must be strings.")
                collect(child)
        elif isinstance(value, (list, tuple)):
            for child in value:
                collect(child)
        elif value is not None and type(value) not in (str, int, float, bool):
            raise ValueError("Unsupported artifact metadata value.")
        elif isinstance(value, float) and not math.isfinite(value):
            raise ValueError("Artifact metadata must be finite.")

    collect(data)
    names = sorted(str(symbol) for symbol in symbols)
    if len(set(names)) != len(symbols) or any(symbol.is_real is not True for symbol in symbols):
        raise ValueError("Artifact symbols must have distinct real names.")
    columns = {name: index for index, name in enumerate(names)}
    nodes, node_indices = [], {}

    def number(value):
        check()
        if value in node_indices:
            return node_indices[value]
        if value.is_Rational:
            node = ["Q", str(value.p), str(value.q)]
        elif value in _CONSTANTS.values():
            node = ["C", next(name for name, constant in _CONSTANTS.items() if value == constant)]
        elif value.func in (sp.Add, sp.Mul, sp.Pow):
            node = [{sp.Add: "A", sp.Mul: "M", sp.Pow: "P"}[value.func],
                    *[number(argument) for argument in value.args]]
        elif _FUNCTIONS.get(value.func.__name__) is value.func:
            node = ["F", value.func.__name__, *[number(argument) for argument in value.args]]
        else:
            raise ValueError("Unsupported exact numeric coefficient.")
        index = len(nodes)
        node_indices[value] = index
        nodes.append(node)
        return index

    table = []
    for row in rows:
        check()
        table.append([[-1 if symbol is None else columns[str(symbol)], number(coefficient)]
                      for symbol, coefficient in row.items()])

    def encode(value):
        check()
        if isinstance(value, AffineRow):
            return {_ROW: row_indices[value]}
        if isinstance(value, dict):
            if set(value) in ({_ROW}, {_DICT}):
                return {_DICT: [[key, encode(child)] for key, child in value.items()]}
            return {key: encode(child) for key, child in value.items()}
        if isinstance(value, (list, tuple)):
            return [encode(child) for child in value]
        return value

    body = {"symbols": names, "numbers": nodes, "rows": table, "data": encode(data)}
    check()
    return {"format": ARTIFACT_VERSION, "body": body, "digest": _digest(body)}


def _artifact_body(payload, check):
    check()
    if (set(payload) != {"format", "body", "digest"} or payload["format"] != ARTIFACT_VERSION
            or not isinstance(payload["body"], dict) or not isinstance(payload["digest"], str)
            or _digest(payload["body"]) != payload["digest"]):
        raise ValueError("Invalid exact artifact version or checksum.")
    body = payload["body"]
    if set(body) != {"symbols", "numbers", "rows", "data"}:
        raise ValueError("Invalid exact artifact tables.")
    names, encoded_numbers, encoded_rows = body["symbols"], body["numbers"], body["rows"]
    if (not isinstance(names, list) or any(not isinstance(name, str) for name in names)
            or len(set(names)) != len(names) or not isinstance(encoded_numbers, list)
            or not isinstance(encoded_rows, list)):
        raise ValueError("Invalid exact artifact tables.")
    return body


def _decode_artifact(payload, check):
    body = _artifact_body(payload, check)
    names, encoded_numbers, encoded_rows = body["symbols"], body["numbers"], body["rows"]
    symbols = [sp.Symbol(name, real=True) for name in names]
    numbers = []
    for index, node in enumerate(encoded_numbers):
        check()
        if not isinstance(node, list) or not node or not isinstance(node[0], str):
            raise ValueError("Invalid exact numeric node.")
        kind = node[0]
        if kind == "Q":
            if (len(node) != 3 or any(not isinstance(v, str) for v in node[1:])
                    or str(int(node[1])) != node[1] or str(int(node[2])) != node[2]
                    or int(node[2]) <= 0):
                raise ValueError("Invalid exact rational coefficient.")
            value = sp.Rational(int(node[1]), int(node[2]))
        elif kind in {"A", "M", "P"}:
            if ((kind == "P" and len(node) != 3) or (kind != "P" and len(node) < 3)
                    or any(type(reference) is not int or not 0 <= reference < index for reference in node[1:])):
                raise ValueError("Invalid or cyclic exact numeric node.")
            value = {"A": sp.Add, "M": sp.Mul, "P": sp.Pow}[kind](*(numbers[i] for i in node[1:]))
        elif kind == "C":
            if len(node) != 2 or not isinstance(node[1], str) or node[1] not in _CONSTANTS:
                raise ValueError("Unsupported exact numeric constant.")
            value = _CONSTANTS[node[1]]
        elif kind == "F":
            if (len(node) < 3 or not isinstance(node[1], str) or node[1] not in _FUNCTIONS
                    or any(type(reference) is not int or not 0 <= reference < index for reference in node[2:])):
                raise ValueError("Invalid exact numeric function.")
            try:
                value = _FUNCTIONS[node[1]](*(numbers[i] for i in node[2:]))
            except (TypeError, ValueError) as exc:
                raise ValueError("Invalid exact numeric function arguments.") from exc
        else:
            raise ValueError("Unsupported exact numeric node.")
        if value.is_number is not True or value.is_finite is not True:
            raise ValueError("Exact numeric nodes must be finite numbers.")
        numbers.append(value)
    factory = AffineRows(check=check)
    rows = []
    validated = {}
    for encoded in encoded_rows:
        check()
        if not isinstance(encoded, list):
            raise ValueError("Invalid affine row.")
        coefficients, seen = {}, set()
        for pair in encoded:
            check()
            if (not isinstance(pair, list) or len(pair) != 2 or type(pair[0]) is not int
                    or not -1 <= pair[0] < len(symbols) or pair[0] in seen
                    or type(pair[1]) is not int or not 0 <= pair[1] < len(numbers)):
                raise ValueError("Invalid affine coefficient reference.")
            seen.add(pair[0])
            if pair[1] not in validated:
                validated[pair[1]] = _validated_number(numbers[pair[1]])
            coefficient = validated[pair[1]]
            if coefficient == 0:
                raise ValueError("An affine row must not store zero coefficients.")
            coefficients[None if pair[0] == -1 else symbols[pair[0]]] = coefficient
        rows.append(factory.from_coefficients(coefficients, normalized=True))

    def decode(value):
        check()
        if isinstance(value, dict):
            if any(not isinstance(key, str) for key in value):
                raise ValueError("Artifact mapping keys must be strings.")
            if set(value) == {_ROW}:
                index = value[_ROW]
                if type(index) is not int or not 0 <= index < len(rows):
                    raise ValueError("Invalid affine row reference.")
                return rows[index]
            if set(value) == {_DICT}:
                pairs = value[_DICT]
                if (not isinstance(pairs, list) or any(not isinstance(pair, list) or len(pair) != 2
                        or not isinstance(pair[0], str) for pair in pairs)
                        or len({pair[0] for pair in pairs}) != len(pairs)):
                    raise ValueError("Invalid escaped artifact mapping.")
                return {key: decode(child) for key, child in pairs}
            return {key: decode(child) for key, child in value.items()}
        if isinstance(value, list):
            return [decode(child) for child in value]
        if value is not None and type(value) not in (str, int, float, bool):
            raise ValueError("Unsupported artifact metadata value.")
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError("Artifact metadata must be finite.")
        return value

    data = decode(body["data"])
    if not isinstance(data, dict):
        raise ValueError("An exact artifact must contain an object.")
    return data


def select_artifact(payload, *path, check=lambda: None):
    """Copy a self-contained subtree by remapping references, never coefficients.

    The source checksum and reference graph are checked here. Mathematical
    numeric validation happens at the consumer's single decode boundary.
    Legacy text is migrated once before selection.
    """
    if not isinstance(payload, dict):
        raise ValueError("An exact artifact must be an object.")
    if not ("format" in payload and ("body" in payload or "digest" in payload)):
        payload = pack_artifact(import_legacy(payload, check=check), check=check)
    body = _artifact_body(payload, check)
    selected = body["data"]
    for key in path:
        check()
        if not isinstance(selected, dict) or key not in selected:
            raise ValueError("The requested artifact section is missing.")
        selected = selected[key]
    if not isinstance(selected, dict):
        raise ValueError("The requested artifact section must be an object.")
    row_ids = set()

    def visit(value, row_map=None):
        check()
        if isinstance(value, dict):
            if any(not isinstance(key, str) for key in value):
                raise ValueError("Artifact mapping keys must be strings.")
            if set(value) == {_ROW}:
                index = value[_ROW]
                if type(index) is not int or not 0 <= index < len(body["rows"]):
                    raise ValueError("Invalid affine row reference.")
                if row_map is None:
                    row_ids.add(index)
                return {_ROW: index if row_map is None else row_map[index]}
            if set(value) == {_DICT}:
                pairs = value[_DICT]
                if (not isinstance(pairs, list) or any(not isinstance(pair, list) or len(pair) != 2
                        or not isinstance(pair[0], str) for pair in pairs)
                        or len({pair[0] for pair in pairs}) != len(pairs)):
                    raise ValueError("Invalid escaped artifact mapping.")
                if row_map is None:
                    for _, child in pairs:
                        visit(child)
                    return None
                return {_DICT: [[key, visit(child, row_map)] for key, child in pairs]}
            if row_map is None:
                for child in value.values():
                    visit(child)
                return None
            return {key: visit(child, row_map) for key, child in value.items()}
        if isinstance(value, list):
            if row_map is None:
                for child in value:
                    visit(child)
                return None
            return [visit(child, row_map) for child in value]
        if (value is not None and type(value) not in (str, int, float, bool)
                or isinstance(value, float) and not math.isfinite(value)):
            raise ValueError("Invalid artifact metadata.")
        return value

    visit(selected)
    number_ids, symbol_ids = set(), set()
    for index in row_ids:
        check()
        row, seen = body["rows"][index], set()
        if not isinstance(row, list):
            raise ValueError("Invalid affine row.")
        for pair in row:
            if (not isinstance(pair, list) or len(pair) != 2 or type(pair[0]) is not int
                    or not -1 <= pair[0] < len(body["symbols"]) or pair[0] in seen
                    or type(pair[1]) is not int or not 0 <= pair[1] < len(body["numbers"])):
                raise ValueError("Invalid affine coefficient reference.")
            seen.add(pair[0])
            if pair[0] >= 0:
                symbol_ids.add(pair[0])
            number_ids.add(pair[1])
    pending, visited = list(number_ids), set()
    while pending:
        check()
        index = pending.pop()
        if index in visited:
            continue
        visited.add(index)
        node = body["numbers"][index]
        if not isinstance(node, list) or not node or not isinstance(node[0], str):
            raise ValueError("Invalid exact numeric node.")
        kind = node[0]
        if kind == "Q":
            if len(node) != 3 or any(not isinstance(value, str) for value in node[1:]):
                raise ValueError("Invalid exact rational coefficient.")
            references = ()
        elif kind == "C":
            if len(node) != 2 or not isinstance(node[1], str) or node[1] not in _CONSTANTS:
                raise ValueError("Unsupported exact numeric constant.")
            references = ()
        elif kind in {"A", "M", "P", "F"}:
            if (len(node) < 3 or kind == "P" and len(node) != 3
                    or kind == "F" and (not isinstance(node[1], str) or node[1] not in _FUNCTIONS)):
                raise ValueError("Invalid exact numeric node.")
            references = node[2:] if kind == "F" else node[1:]
            if any(type(reference) is not int or not 0 <= reference < index for reference in references):
                raise ValueError("Invalid or cyclic exact numeric node.")
        else:
            raise ValueError("Unsupported exact numeric node.")
        pending.extend(references)
    number_ids = sorted(visited)
    row_ids, symbol_ids = sorted(row_ids), sorted(symbol_ids)
    number_map = {old: new for new, old in enumerate(number_ids)}
    row_map = {old: new for new, old in enumerate(row_ids)}
    symbol_map = {old: new for new, old in enumerate(symbol_ids)}
    numbers = []
    for index in number_ids:
        node = body["numbers"][index]
        offset = 1 if node[0] in {"A", "M", "P"} else 2 if node[0] == "F" else len(node)
        numbers.append([*node[:offset], *(number_map[reference] for reference in node[offset:])])
    rows = [[[(-1 if column == -1 else symbol_map[column]), number_map[number]]
             for column, number in body["rows"][index]] for index in row_ids]
    selected_body = {"symbols": [body["symbols"][index] for index in symbol_ids],
                     "numbers": numbers, "rows": rows, "data": visit(selected, row_map)}
    check()
    return {"format": ARTIFACT_VERSION, "body": selected_body, "digest": _digest(selected_body)}


def load_artifact(payload, *, check=lambda: None):
    """Decode current artifacts, or import authoritative legacy formulas once."""
    if not isinstance(payload, dict):
        raise ValueError("An exact artifact must be an object.")
    if "format" in payload and ("body" in payload or "digest" in payload):
        return _decode_artifact(payload, check)
    return import_legacy(payload, check=check)


def import_legacy(data, *, check=lambda: None):
    """One migration boundary; optional legacy coefficient copies are ignored."""
    names = set()

    def collect(value, key=None):
        check()
        if isinstance(value, AffineRow):
            names.update(str(symbol) for symbol in value.free_symbols)
        elif isinstance(value, dict):
            for name, child in value.items():
                if name == "affine_expressions":
                    continue
                if name == "symbol" and isinstance(child, str):
                    names.add(child)
                elif name in {"variables", "loop_free_parameters"} and isinstance(child, list):
                    names.update(row["name"] for row in child if isinstance(row, dict) and isinstance(row.get("name"), str))
                collect(child, name)
        elif isinstance(value, (list, tuple)):
            if key in {"parameter_order", "reconstruction_symbol_order"}:
                names.update(name for name in value if isinstance(name, str))
            for child in value:
                collect(child)

    collect(data)
    symbols = {name: sp.Symbol(name, real=True) for name in names}
    factory, parsed = AffineRows(check=check), {}

    def formula(value):
        check()
        if isinstance(value, AffineRow):
            return value
        if not isinstance(value, str):
            raise ValueError("A legacy mathematical formula must be exact text.")
        if value not in parsed:
            from .solver_engine import _parse_export_expression
            expression = _parse_export_expression(value, symbols)
            if expression.free_symbols - set(symbols.values()):
                raise ValueError("An affine expression contains an unknown variable.")
            parsed[value] = factory.from_expr(expression)
        return parsed[value]

    def convert(value, key=None):
        check()
        if isinstance(value, AffineRow):
            return value
        if isinstance(value, dict):
            return {name: (formula(child) if name in {"expression", "real", "imag"} else convert(child, name))
                    for name, child in value.items() if name != "affine_expressions"}
        if isinstance(value, (list, tuple)):
            return [convert(child, key) for child in value]
        return value

    return convert(data)


def text_artifact(data, *, include_display=True, preview_limit=None):
    """Render an explicit human-readable boundary without changing the rows."""
    from .display import ExpressionRecords, PREVIEW_EXPRESSION_LENGTH, PREVIEW_MATRIX_SIZE
    formatter = ExpressionRecords()
    expressions, texts, latex, mathmls = {}, {}, {}, {}

    def render(row):
        if row not in expressions:
            expressions[row] = row.as_expr()
            texts[row] = formatter.text(expressions[row])
        return texts[row]

    def walk(value, path=(), prepared=False):
        if isinstance(value, AffineRow):
            return render(value)
        if isinstance(value, list):
            return [walk(child, (*path, index), prepared) for index, child in enumerate(value)]
        if not isinstance(value, dict):
            return value
        prepared = prepared or value.get("status") == "prepared" or "preparation" in path
        result = {key: walk(child, (*path, key), prepared) for key, child in value.items()
                  if key != "_affine_value"}
        for key, row in value.items():
            if not isinstance(row, AffineRow) or key not in {"expression", "real", "imag"}:
                continue
            if not include_display or key == "imag":
                continue
            if prepared and preview_limit is not None:
                if (len(path) >= 2 and path[-2] in {"reconstruction", "equalities", "moment_reductions"}
                        and isinstance(path[-1], int) and path[-1] >= preview_limit):
                    continue
                if ("blocks" in path and "entries" in path
                        and (value.get("row", 0) >= PREVIEW_MATRIX_SIZE
                             or value.get("col", 0) >= PREVIEW_MATRIX_SIZE)):
                    continue
            source = texts[row]
            prefix = (key + "_") if key == "real" or (not prepared and "relations" in path) else ""
            if preview_limit is not None and len(source) > PREVIEW_EXPRESSION_LENGTH:
                result[prefix + "latex"] = r"\text{Long expression omitted}"
                continue
            if row not in latex:
                latex[row] = sp.latex(expressions[row])
            result[prefix + "latex"] = latex[row] + (" = 0" if prepared and "equalities" in path else "")
            if not prepared:
                if row not in mathmls:
                    from .moments import _mathml
                    mathmls[row] = _mathml(expressions[row])
                result[prefix + "mathml"] = mathmls[row]
        if include_display and value.get("kind") == "inequality" and "observable" in result:
            observable = result["observable"]
            result["labels_latex"] = [observable.get("latex", observable["name"])]
        return result

    result = walk(data)
    if include_display and isinstance(result, dict) and "model" in result and "constraints" in result:
        from .constraints import polynomial_latex
        from .model import Model
        model = Model.from_dict(result["model"])
        for row in result["constraints"].get("equations", []):
            polynomial = {tuple(model.validate_word(tuple(word)) for word in term["traces"]):
                          sp.sympify(term["coefficient"]) for term in row["terms"]}
            row["latex"] = polynomial_latex(model, polynomial)
    return result
