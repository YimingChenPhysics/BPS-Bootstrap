"""Disposable, bounded JSON cache for complete stages of an SDP build."""

import hashlib
import json
import logging
import math
import os
from pathlib import Path
import sqlite3
import tempfile
import threading
import time


BUILD_CACHE_VERSION = "sdp-build-v1"
_LOG = logging.getLogger(__name__)


def _json(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def stable_digest(value):
    """SHA256 of a deterministic, finite JSON representation."""
    return hashlib.sha256(_json(value).encode("utf-8")).hexdigest()


def _reject_nonfinite(value):
    raise ValueError(f"Non-finite JSON number: {value}")


def _finite_float(value):
    result = float(value)
    if not math.isfinite(result):
        _reject_nonfinite(value)
    return result


def _corrupt(error):
    code = getattr(error, "sqlite_errorcode", 0)
    # Python 3.10 does not expose SQLite result codes on exceptions.
    return ((isinstance(code, int) and code & 0xFF in (11, 26))
            or str(error).lower() in {"file is not a database", "database disk image is malformed"})


class BuildCache:
    def __init__(self, path, max_entries=16):
        if type(max_entries) is not int or max_entries < 1:
            raise ValueError("The per-stage cache limit must be a positive integer.")
        self.path = Path(path)
        self.max_entries = max_entries
        self.version = BUILD_CACHE_VERSION
        self.connection = None
        self.lock = threading.RLock()
        self.hits = 0
        self.misses = 0
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            if not self.path.is_symlink():
                if self.path.exists() and self._has_journal():
                    with self.path.open("rb") as handle:
                        if handle.read(16) != b"SQLite format 3\x00":
                            return
                self.connection = self._connect(self.path)
        except (sqlite3.Error, OSError) as error:
            if isinstance(error, sqlite3.Error) and _corrupt(error):
                self._recover()

    @staticmethod
    def _connect(path):
        connection = sqlite3.connect(path, timeout=1, check_same_thread=False)
        try:
            with connection:
                connection.execute("""CREATE TABLE IF NOT EXISTS stage_cache (
                    stage TEXT NOT NULL, key TEXT NOT NULL, body TEXT NOT NULL,
                    digest TEXT NOT NULL, updated_at INTEGER NOT NULL,
                    PRIMARY KEY (stage, key)
                )""")
                connection.execute("SELECT stage, key, body, digest, updated_at FROM stage_cache LIMIT 0")
            return connection
        except sqlite3.Error:
            connection.close()
            raise

    def _disconnect(self):
        connection, self.connection = self.connection, None
        if connection is not None:
            try:
                connection.close()
            except sqlite3.Error:
                pass

    def _has_journal(self):
        return any(Path(str(self.path) + suffix).exists() for suffix in ("-wal", "-shm", "-journal"))

    def _recover(self):
        """Atomically replace only this disposable database, never its neighbors."""
        self._disconnect()
        temporary = None
        try:
            if self.path.is_symlink() or self.path.is_dir():
                return
            # Leave possible live SQLite journals alone and disable the cache.
            if self._has_journal():
                return
            with tempfile.NamedTemporaryFile(dir=self.path.parent, prefix=".build-cache-", suffix=".sqlite3",
                                             delete=False) as handle:
                temporary = Path(handle.name)
            connection = self._connect(temporary)
            connection.close()
            os.replace(temporary, self.path)
            self.connection = self._connect(self.path)
        except (sqlite3.Error, OSError):
            self._disconnect()
        finally:
            if temporary is not None:
                try:
                    temporary.unlink(missing_ok=True)
                except OSError:
                    pass

    def _storage_error(self, error):
        self._disconnect()
        if _corrupt(error):
            self._recover()

    def _stage(self, stage, key):
        if not isinstance(stage, str) or not isinstance(key, str):
            raise TypeError("Cache stages and keys must be strings.")
        return f"{self.version}:{stage}"

    def get(self, stage, key):
        stage = self._stage(stage, key)
        with self.lock:
            self.misses += 1
            if self.connection is None:
                return None
            try:
                row = self.connection.execute("SELECT body, digest FROM stage_cache WHERE stage=? AND key=?",
                                              (stage, key)).fetchone()
            except sqlite3.Error as error:
                self._storage_error(error)
                return None
            if row is None:
                return None
            body, digest = row
            try:
                if (not isinstance(body, str) or not isinstance(digest, str)
                        or hashlib.sha256(body.encode("utf-8")).hexdigest() != digest):
                    return None
                value = json.loads(body, parse_constant=_reject_nonfinite, parse_float=_finite_float)
                if not isinstance(value, (dict, list)):
                    return None
            except (ValueError, TypeError, UnicodeError, RecursionError):
                return None
            self.misses -= 1
            self.hits += 1
            return value

    def put(self, stage, key, payload):
        stage = self._stage(stage, key)
        if not isinstance(payload, (dict, list)):
            raise TypeError("Build cache payloads must be JSON objects or arrays.")
        body = _json(payload)
        digest = hashlib.sha256(body.encode("utf-8")).hexdigest()
        with self.lock:
            if self.connection is None:
                return
            try:
                with self.connection:
                    self.connection.execute("BEGIN IMMEDIATE")
                    previous = self.connection.execute(
                        "SELECT COALESCE(MAX(updated_at), 0) FROM stage_cache WHERE stage=?", (stage,)).fetchone()[0]
                    updated_at = max(time.time_ns(), previous + 1)
                    self.connection.execute("""INSERT INTO stage_cache (stage, key, body, digest, updated_at)
                        VALUES (?, ?, ?, ?, ?) ON CONFLICT(stage, key) DO UPDATE SET
                        body=excluded.body, digest=excluded.digest, updated_at=excluded.updated_at""",
                        (stage, key, body, digest, updated_at))
                    self.connection.execute("""DELETE FROM stage_cache WHERE stage=? AND key NOT IN (
                        SELECT key FROM stage_cache WHERE stage=? ORDER BY updated_at DESC, key LIMIT ?
                    )""", (stage, stage, self.max_entries))
            except (sqlite3.Error, OverflowError) as error:
                _LOG.warning("Could not save cache stage %s; existing completed checkpoints are retained: %s",
                             stage, error)
                self._storage_error(error)

    def close(self):
        with self.lock:
            self._disconnect()

    def __bool__(self):
        return self.connection is not None

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()
