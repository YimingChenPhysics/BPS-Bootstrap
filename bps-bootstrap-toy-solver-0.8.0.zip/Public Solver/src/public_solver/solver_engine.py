"""Exact affine SDP export and independent multiprecision result checks.

Numerical statuses are tolerance-based assessments, not rigorous certificates.
The subprocess and its cancellation/logging belong to the worker.
"""

import ast
import math
from pathlib import Path
import re

import mpmath
import sympy as sp

from .affine import _clean
from .affine_data import AffineMatrix, AffineRow, AffineRows
from .artifact import load_artifact
from .solver_settings import validate_settings


_NUMBER = re.compile(r"(?<![A-Za-z0-9_.])[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?")
_HARD_BOUND_KINDS = frozenset({"cutoff", "inequality"})


def _parse_export_expression(source, local_symbols):
    """Assemble long exact sums once, avoiding repeated growing SymPy additions."""
    if (not isinstance(source, str) or len(source) < 512 or not source.isascii()
            or "\n" in source or "\r" in source):
        return sp.sympify(source, locals=local_symbols)
    try:
        tree = ast.parse(source, mode="eval")
    except (SyntaxError, ValueError, RecursionError):
        return sp.sympify(source, locals=local_symbols)
    allowed = (ast.Expression, ast.BinOp, ast.UnaryOp, ast.Add, ast.Sub, ast.Mult,
               ast.Div, ast.Pow, ast.UAdd, ast.USub, ast.Call, ast.Name, ast.Load, ast.Constant)
    # Floats and alternative Python/SymPy syntax retain their original parsing
    # and rounding behavior. ASCII single-line text makes AST byte offsets safe.
    if any(not isinstance(node, allowed) or (isinstance(node, ast.Constant) and type(node.value) is not int)
           for node in ast.walk(tree)):
        return sp.sympify(source, locals=local_symbols)
    if not (isinstance(tree.body, ast.UnaryOp) or
            isinstance(tree.body, ast.BinOp) and isinstance(tree.body.op, (ast.Add, ast.Sub))):
        return sp.sympify(source, locals=local_symbols)
    pending, leaves = [(tree.body, 1)], []
    while pending:
        node, sign = pending.pop()
        if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Sub)):
            pending.append((node.right, -sign if isinstance(node.op, ast.Sub) else sign))
            pending.append((node.left, sign))
        elif isinstance(node, ast.UnaryOp):
            pending.append((node.operand, -sign if isinstance(node.op, ast.USub) else sign))
        else:
            leaves.append(("-" if sign == -1 else "") + "(" + source[node.col_offset:node.end_col_offset] + ")")
    # A tuple parses the leaves together without left-associated symbolic sums
    # or a generated function name that could collide with a coordinate name.
    values = sp.sympify("(" + ",".join(leaves) + ",)", locals=local_symbols)
    if not isinstance(values, tuple) or any(not isinstance(value, sp.Expr) or value.has(sp.Float) for value in values):
        return sp.sympify(source, locals=local_symbols)
    return sp.Add(*values)


def _result(mode, status="unresolved", message="The numerical result could not be validated."):
    return {"status": status, "mode": mode, "message": message, "objective_value": None,
            "objective_lower": None, "objective_upper": None, "margin_value": None,
            "margin_lower": None, "margin_upper": None, "iterations": None,
            "diagnostics": {"rigorous_certificate": False}, "variables": []}


def _context(settings):
    effective = 64 * ((settings["precision"] + 63) // 64)
    digits = math.ceil(effective * math.log10(2)) + 25
    mp = mpmath.mp.clone()
    mp.dps = digits + 20
    return mp, effective, digits


def _numeric(value, mp):
    return mp.mpf(str(sp.N(value, mp.dps)))


def _text(value, mp, digits=None):
    return mp.nstr(value, n=digits or mp.dps - 10, strip_zeros=False)


def _matrix_metrics(matrices, mp):
    minimum, violation, symmetry = mp.inf, mp.mpf(0), mp.mpf(0)
    for matrix in matrices:
        scale = max(mp.mpf(1), max((abs(v) for v in matrix), default=mp.mpf(0)))
        symmetry = max(symmetry, max((abs(matrix[i, j] - matrix[j, i]) / scale
                                     for i in range(matrix.rows) for j in range(i)), default=mp.mpf(0)))
        if all(matrix[i, j] == 0 for i in range(matrix.rows) for j in range(i)):
            eigenvalues = [matrix[i, i] for i in range(matrix.rows)]
        else:
            eigenvalues = list(mp.eigsy((matrix + matrix.T) / 2, eigvals_only=True))
        smallest = min(eigenvalues)
        spectral_scale = max(mp.mpf(1), max(abs(v) for v in eigenvalues))
        minimum = min(minimum, smallest)
        violation = max(violation, max(mp.mpf(0), -smallest) / spectral_scale)
    return minimum, violation, symmetry


def _constant_result(problem, settings):
    """Materialize only constant numeric matrices for exact PSD certification."""
    constant = []
    for matrix in problem["physical_blocks"]:
        if matrix.free_symbols:
            constant.append(None)
            continue
        exact = sp.ImmutableSparseMatrix(matrix.rows, matrix.cols, {
            position: dict(row.items()).get(None, sp.S.Zero)
            for position, row in matrix.todok().items()})
        if exact.is_positive_semidefinite is False:
            result = _result(problem["mode"], "infeasible", "A constant PSD block is inconsistent.")
            result["diagnostics"]["exact_constant_check"] = True
            return result
        constant.append(exact)
    if any(matrix is None for matrix in constant):
        return None
    mp, _, _ = _context(settings)
    properties = [matrix.is_positive_semidefinite for matrix in constant]
    numeric = [mp.matrix([[_numeric(v, mp) for v in matrix.row(i)] for i in range(matrix.rows)])
               for matrix in constant]
    minimum, violation, _ = _matrix_metrics(numeric, mp)
    if any(value is False for value in properties):
        result = _result(problem["mode"], "infeasible", "The constant PSD constraints are inconsistent.")
    elif not all(value is True for value in properties):
        result = _result(problem["mode"], message="The constant PSD constraints could not be certified exactly.")
    elif problem["mode"] == "feasibility":
        result = _result("feasibility", "feasible", "The constant PSD constraints hold exactly.")
        physical = [matrix for matrix, kind in zip(numeric, problem["block_kinds"])
                    if kind not in _HARD_BOUND_KINDS]
        margin, _, _ = _matrix_metrics(physical, mp)
        if mp.isfinite(margin):
            result["margin_value"] = _text(margin, mp)
    elif any(problem["physical_objective_coefficients"]):
        result = _result(problem["mode"], "unbounded", "The objective varies along an unrestricted coordinate.")
    else:
        result = _result(problem["mode"], "optimal", "The feasible objective is fixed exactly.")
        value = _text(_numeric(problem["physical_objective_constant"], mp), mp)
        result.update(objective_value=value, objective_lower=value, objective_upper=value)
    result["diagnostics"].update(exact_constant_check=all(value is not None for value in properties),
                                  maximum_relative_psd_violation=_text(violation, mp))
    if result["status"] in {"feasible", "optimal", "unbounded"}:
        result["variables"] = [{"name": str(symbol), "value": "0"} for symbol in problem["physical_variables"]]
    return result


def write_problem(prepared, settings, directory, *, progress=None, check_cancelled=None):
    """Legacy/import boundary; the exporter itself consumes exact rows only."""
    check = check_cancelled or (lambda: None)
    return write_problem_data(load_artifact(prepared, check=check), settings, directory,
                              progress=progress, check_cancelled=check)


def write_problem_data(prepared, settings, directory, *, progress=None, check_cancelled=None):
    """Write native SDPA files directly from the authoritative affine rows."""
    notify = progress or (lambda value: None)
    check = check_cancelled or (lambda: None)
    check()
    settings = validate_settings(settings)
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    optimization = prepared.get("optimization", {"mode": "feasibility"})
    mode = optimization["mode"]
    if mode not in {"feasibility", "minimize", "maximize"}:
        raise ValueError("Unknown optimization mode.")
    names = [row["name"] for row in prepared["variables"]]
    if any(not isinstance(name, str) for name in names) or len(names) != len(set(names)):
        raise ValueError("Optimization variables must have distinct names.")
    variables = tuple(sp.Symbol(name, real=True) for name in names)
    indices = {symbol: index for index, symbol in enumerate(variables)}
    factory = AffineRows(variables, check=check)
    zero = factory.from_coefficients({})
    indexed = {}

    def columns(row):
        check()
        if not isinstance(row, AffineRow):
            raise ValueError("Prepared formulas must be exact affine rows.")
        if row not in indexed:
            if row.free_symbols - indices.keys():
                raise ValueError("An affine expression contains an unknown variable.")
            indexed[row] = {len(variables) if symbol is None else indices[symbol]: coefficient
                            for symbol, coefficient in row.items()}
        return indexed[row]

    matrices, kinds, coefficients = [], [], []
    total = sum(len(block["entries"]) for block in prepared["blocks"])
    completed = 0
    symmetry_checked = set()

    def entry_progress():
        notify({"stage": "export_entries", "completed": completed, "total": total,
                "message": f"Preparing SDPA input: {completed:,} of {total:,} matrix entries."})

    entry_progress()
    for block in prepared["blocks"]:
        check()
        size = block["size"]
        if type(size) is not int or size < 0:
            raise ValueError("Invalid PSD block size.")
        if size == 0:
            continue
        entries, entry_terms = {}, {}
        for entry in block["entries"]:
            check()
            i, j = entry["row"], entry["col"]
            if type(i) is not int or type(j) is not int or not 0 <= i < size or not 0 <= j < size or (i, j) in entries:
                raise ValueError("Invalid or duplicate PSD matrix entry.")
            row = entry["expression"]
            entry_terms[i, j] = columns(row)
            entries[i, j] = row
            completed += 1
            if completed % 128 == 0:
                entry_progress()
        for (i, j), row in entries.items():
            check()
            other = entries.get((j, i), zero)
            if row == other or (row, other) in symmetry_checked:
                continue
            left, right = columns(row), columns(other)
            if any(_clean(left.get(index, sp.S.Zero) - right.get(index, sp.S.Zero)) != 0
                   for index in left.keys() | right.keys()):
                raise ValueError("A PSD block must be symmetric.")
            symmetry_checked.add((row, other))
            symmetry_checked.add((other, row))
        matrices.append(AffineMatrix(size, size, entries))
        coefficients.append({position: row for position, row in entry_terms.items() if row})
        kinds.append(block.get("kind", "moment"))
        entry_progress()
    physical_objective = zero if mode == "feasibility" else optimization["expression"]
    objective_terms = columns(physical_objective)
    problem = {"mode": mode, "physical_variables": variables, "physical_blocks": tuple(matrices),
               "block_kinds": tuple(kinds), "physical_objective_constant": objective_terms.get(len(variables), sp.S.Zero),
               "physical_objective_coefficients": tuple(objective_terms.get(i, sp.S.Zero) for i in range(len(variables)))}
    notify({"stage": "export_constants", "message": "Preparing SDPA input: checking constant blocks."})
    check()
    problem["direct_result"] = _constant_result(problem, settings)
    if problem["direct_result"] is not None:
        return problem
    margin_index = None
    objective_constant = objective_terms.get(len(variables), sp.S.Zero)
    if mode == "feasibility" and any(kind not in _HARD_BOUND_KINDS for kind in kinds):
        margin_index = len(variables)
        margin_name = "_solver_margin"
        while margin_name in names:
            margin_name += "_"
        margin = sp.Symbol(margin_name, real=True)
        variables += (margin,)
        shifted_factory = AffineRows(variables, check=check)
        shifted_cache = {}
        shifted_matrices, shifted_coefficients = [], []
        for matrix, kind, values in zip(matrices, kinds, coefficients):
            check()
            entries = matrix.todok()
            if kind not in _HARD_BOUND_KINDS:
                for i in range(matrix.rows):
                    entries.setdefault((i, i), zero)
            shifted = {}
            for (i, j), expression in entries.items():
                check()
                diagonal = i == j and kind not in _HARD_BOUND_KINDS
                key = (expression, diagonal)
                if key not in shifted_cache:
                    row = {len(variables) if index == margin_index else index: value
                           for index, value in values.get((i, j), {}).items()}
                    if diagonal:
                        row[margin_index] = -sp.S.One
                    native = (shifted_factory.from_coefficients(
                        {**dict(expression.items()), margin: -sp.S.One}, normalized=True)
                        if diagonal else expression)
                    shifted_cache[key] = row, native
                shifted[i, j], entries[i, j] = shifted_cache[key]
            shifted_coefficients.append(shifted)
            shifted_matrices.append(AffineMatrix(matrix.rows, matrix.cols, entries))
        coefficients, matrices = shifted_coefficients, shifted_matrices
        objective_terms = {margin_index: sp.S.One}
        objective_constant = sp.S.Zero
    direction = 1 if mode == "minimize" else -1
    cost = tuple(direction * objective_terms.get(i, sp.S.Zero) for i in range(len(variables)))
    mp, effective_bits, digits = _context(settings)
    numeric_cache = {}

    def token(value):
        check()
        if value not in numeric_cache:
            numeric_cache[value] = _text(_numeric(value, mp), mp, digits)
        return numeric_cache[value]

    lines = ['"BPS Bootstrap exact affine SDP"', str(len(variables)), str(len(matrices)),
             "{" + ",".join(str(matrix.rows) for matrix in matrices) + "}",
             "{" + ",".join(token(value) for value in cost) + "}"]
    for block, entries in enumerate(coefficients, 1):
        notify({"stage": "export_write", "completed": block - 1, "total": len(coefficients),
                "message": f"Writing SDPA input: block {block} of {len(coefficients)}."})
        for (i, j), values in sorted(entries.items()):
            check()
            if i > j:
                continue
            for index, value in sorted(values.items()):
                column = 0 if index == len(variables) else index + 1
                coefficient = -value if column == 0 else value
                lines.append(f"{column} {block} {i + 1} {j + 1} {token(coefficient)}")
    check()
    (directory / "problem.dat-s").write_text("\n".join(lines) + "\n", encoding="utf-8")
    format_ = f"%+{digits + 12}.{digits}Fe"
    controls = [(settings["max_iterations"], "maxIteration"), (settings["epsilon"], "epsilonStar"),
                (settings["lambda_star"], "lambdaStar"), ("2", "omegaStar"), ("-1e20", "lowerBound"),
                ("1e20", "upperBound"), (settings["beta_star"], "betaStar"), (settings["beta_bar"], "betaBar"),
                ("0.9", "gammaStar"), (settings["epsilon"], "epsilonDash"), (settings["precision"], "precision"),
                (format_, "xPrint"), (format_, "XPrint"), (format_, "YPrint"), ("%+10.16e", "infPrint")]
    (directory / "param.sdpa").write_text("\n".join(f"{value} {name}" for value, name in controls) + "\n", encoding="utf-8")
    problem.update(variables=variables, native_blocks=tuple(matrices), coefficients=tuple(coefficients),
                   cost=cost, objective_constant=objective_constant, direction=direction, margin_index=margin_index,
                   effective_precision=effective_bits, decimal_digits=digits)
    notify({"stage": "export_complete", "message": "SDPA input is ready."})
    return problem


def _field(text, label):
    found = re.search(r"^\s*" + re.escape(label) + r"\s*=\s*(\S+)", text, re.MULTILINE)
    return found.group(1) if found else None


def _section(text, start, end):
    begin = text.find(start)
    finish = text.find(end, begin + len(start)) if begin >= 0 else -1
    if begin < 0 or finish < 0:
        return ()
    return tuple(_NUMBER.findall(text[begin + len(start):finish]))


def _equalities(prepared, values, mp, numeric=None):
    numeric = numeric or (lambda value: _numeric(value, mp))
    reconstructed = dict(values)
    reconstructed_rows = {}
    for relation in prepared.get("reconstruction", []):
        row = relation["expression"]
        if row not in reconstructed_rows:
            reconstructed_rows[row] = mp.fsum(
                numeric(coefficient) * (mp.mpf(1) if symbol is None else values[str(symbol)])
                for symbol, coefficient in row.items())
        reconstructed[relation["symbol"]] = reconstructed_rows[row]
    residual = mp.mpf(0)
    checked = set()
    for relation in prepared.get("equalities", []):
        row = relation["expression"]
        if row in checked:
            continue
        checked.add(row)
        components = [numeric(coefficient) * (mp.mpf(1) if symbol is None else reconstructed[str(symbol)])
                      for symbol, coefficient in row.items()]
        residual = max(residual, abs(mp.fsum(components)) / max(mp.mpf(1), mp.fsum(abs(v) for v in components)))
    return residual, reconstructed


def _separating_ray(duals, coefficients, stationarity, constants, mp):
    """Optionally remove a small stationarity defect, then check the ray anew."""
    scale = max(mp.mpf(1), max((abs(v) for matrix in duals for v in matrix), default=mp.mpf(0)))
    ray = [matrix / scale for matrix in duals]
    residual = [value / scale for value in stationarity]
    projected = False
    count = len(stationarity)
    if any(residual) and count <= 256:
        gram = mp.matrix(count)
        for entries in coefficients:
            for row in entries.values():
                terms = [(index, value) for index, value in row.items() if index < count]
                for i, left in terms:
                    for j, right in terms:
                        gram[i, j] += left * right
        active = [i for i in range(count) if gram[i, i] != 0]
        try:
            if active:
                correction = mp.lu_solve(mp.matrix([[gram[i, j] for j in active] for i in active]),
                                         mp.matrix([residual[i] for i in active]))
                weights = dict(zip(active, correction))
                for matrix, entries in zip(ray, coefficients):
                    for (i, j), row in entries.items():
                        matrix[i, j] -= sum((weights.get(index, 0) * value for index, value in row.items()
                                             if index < count), mp.mpf(0))
                projected = True
        except (ValueError, ZeroDivisionError):
            pass
    scale = max(mp.mpf(1), max((abs(v) for matrix in ray for v in matrix), default=mp.mpf(0)))
    ray = [matrix / scale for matrix in ray]
    residual = [mp.mpf(0) for _ in range(count)]
    for matrix, entries in zip(ray, coefficients):
        for (i, j), row in entries.items():
            for index, value in row.items():
                if index < count:
                    residual[index] += value * matrix[i, j]
    separation = -sum((sum((a * b for a, b in zip(constant, matrix)), mp.mpf(0))
                       for constant, matrix in zip(constants, ray)), mp.mpf(0))
    _, violation, symmetry = _matrix_metrics(ray, mp)
    return max(map(abs, residual), default=mp.mpf(0)), violation, symmetry, separation, projected


def read_result(prepared, problem, settings, directory):
    """Legacy artifact boundary for standalone callers."""
    return read_result_data(load_artifact(prepared), problem, settings, directory)


def read_result_data(prepared, problem, settings, directory):
    """Validate native vectors and return conservative JSON-ready conclusions."""
    if problem.get("direct_result") is not None:
        return problem["direct_result"]
    settings = validate_settings(settings)
    result = _result(problem["mode"])
    diagnostics = result["diagnostics"]
    diagnostics["variable_cutoff_applied"] = "cutoff" in problem["block_kinds"]
    diagnostics["observable_inequalities_applied"] = "inequality" in problem["block_kinds"]
    mp, effective, _ = _context(settings)
    numeric_cache = {}

    def numeric(value):
        if value not in numeric_cache:
            numeric_cache[value] = _numeric(value, mp)
        return numeric_cache[value]

    try:
        text = (Path(directory) / "result.txt").read_text(encoding="utf-8")
        phase = _field(text, "phase.value")
        iterations = _field(text, "Iteration")
        result["iterations"] = int(iterations) if iterations is not None else None
        diagnostics.update(native_phase=phase, iteration_limit_reached=(result["iterations"] is not None
                           and result["iterations"] >= settings["max_iterations"]))
        elapsed = _field(text, "total time")
        if elapsed is not None and math.isfinite(float(elapsed)):
            result["elapsed_seconds"] = float(elapsed)
        reported = _field(text, "relative eps")
        precision_ok = reported is not None and abs(mp.mpf(reported) / mp.power(2, -effective) - 1) <= mp.mpf("1e-12")
        diagnostics.update(requested_precision_bits=settings["precision"], effective_precision_bits=effective,
                           reported_relative_epsilon=reported, precision_verified=bool(precision_ok))
        if not phase or result["iterations"] is None or not precision_ok:
            result["message"] = "The solver output did not verify its status and requested GMP precision."
            return result
        x_tokens = _section(text, "xVec =", "xMat =")
        slack_tokens = _section(text, "xMat =", "yMat =")
        dual_tokens = _section(text, "yMat =", "main loop time")
        sizes = [matrix.rows for matrix in problem["native_blocks"]]
        positions = sum(size * size for size in sizes)
        diagnostics["vector_lengths"] = {"variables": len(x_tokens), "slack": len(slack_tokens), "dual": len(dual_tokens)}
        if len(x_tokens) != len(problem["variables"]) or len(slack_tokens) != positions or len(dual_tokens) != positions:
            result["message"] = "The solver returned incomplete solution vectors."
            return result
        x = tuple(mp.mpf(value) for value in x_tokens)
        slack_values = tuple(mp.mpf(value) for value in slack_tokens)
        dual_values = tuple(mp.mpf(value) for value in dual_tokens)
        if not all(mp.isfinite(value) for value in (*x, *slack_values, *dual_values)):
            raise ValueError("Nonfinite numerical output.")
        offset, slacks, duals, evaluated, constants = 0, [], [], [], []
        stationarity = [mp.mpf(0) for _ in x]
        cost = [numeric(value) for value in problem["cost"]]
        dual_objective = mp.mpf(0)
        primal_residual = mp.mpf(0)
        numeric_coefficients = []
        for size, entries in zip(sizes, problem["coefficients"]):
            slack = mp.matrix(size); dual = mp.matrix(size); matrix = mp.matrix(size); constant = mp.matrix(size)
            for i in range(size):
                for j in range(size):
                    slack[i, j] = slack_values[offset + i * size + j]
                    dual[i, j] = dual_values[offset + i * size + j]
            offset += size * size
            numeric_entries = {}
            for (i, j), coefficients in entries.items():
                numeric_entries[i, j] = {index: numeric(value) for index, value in coefficients.items()}
                components = []
                for index, value in numeric_entries[i, j].items():
                    if index == len(x):
                        constant[i, j] = value
                        dual_objective -= value * dual[i, j]
                        components.append(value)
                    else:
                        stationarity[index] += value * dual[i, j]
                        components.append(value * x[index])
                matrix[i, j] = sum(components)
            for i in range(size):
                for j in range(size):
                    primal_residual = max(primal_residual, abs(matrix[i, j] - slack[i, j]) /
                                          max(mp.mpf(1), abs(matrix[i, j]), abs(slack[i, j])))
            slacks.append(slack); duals.append(dual); evaluated.append(matrix); constants.append(constant)
            numeric_coefficients.append(numeric_entries)
        stationarity_residual = max((abs(lhs - rhs) / max(mp.mpf(1), abs(rhs))
                                     for lhs, rhs in zip(stationarity, cost)), default=mp.mpf(0))
        primal_minimum, primal_violation, _ = _matrix_metrics(evaluated, mp)
        _, slack_violation, slack_symmetry = _matrix_metrics(slacks, mp)
        dual_minimum, dual_violation, dual_symmetry = _matrix_metrics(duals, mp)
        if problem["margin_index"] is None:
            physical_violation = primal_violation
        else:
            physical = [matrix + (x[problem["margin_index"]] * mp.eye(matrix.rows)
                                  if kind not in _HARD_BOUND_KINDS else mp.zeros(matrix.rows))
                        for matrix, kind in zip(evaluated, problem["block_kinds"])]
            _, physical_violation, _ = _matrix_metrics(physical, mp)
        values = {str(symbol): x[i] for i, symbol in enumerate(problem["physical_variables"])}
        equality_residual, reconstructed = _equalities(prepared, values, mp, numeric)
        epsilon = mp.mpf(settings["epsilon"])
        tolerance = max(mp.mpf("1e-12"), min(mp.mpf("1e-8"), 100 * epsilon))
        guard = max(mp.mpf("1e-8"), 10 * tolerance)
        gap_tolerance = max(mp.mpf("1e-10"), min(mp.mpf("1e-6"), 1000 * epsilon))
        primal_valid = max(primal_violation, slack_violation, slack_symmetry, primal_residual, equality_residual) <= tolerance
        dual_valid = max(dual_violation, dual_symmetry, stationarity_residual) <= tolerance
        primal_objective = sum((c * value for c, value in zip(cost, x)), mp.mpf(0))
        gap = primal_objective - dual_objective
        relative_gap = abs(gap) / max(mp.mpf(1), abs(primal_objective), abs(dual_objective))
        ordered = gap >= -gap_tolerance * max(mp.mpf(1), abs(primal_objective), abs(dual_objective))
        constant = numeric(problem["objective_constant"])
        candidate = constant + problem["direction"] * primal_objective
        dual_bound = constant + problem["direction"] * dual_objective
        lower, upper = (dual_bound, candidate) if problem["direction"] == 1 else (candidate, dual_bound)
        if ordered and lower > upper:
            lower, upper = upper, lower
        diagnostics.update({key: _text(value, mp) for key, value in {
            "validation_tolerance": tolerance, "boundary_guard": guard, "relative_gap": relative_gap,
            "minimum_shifted_eigenvalue": primal_minimum, "minimum_dual_eigenvalue": dual_minimum,
            "maximum_relative_psd_violation": physical_violation, "maximum_relative_shifted_psd_violation": primal_violation,
            "maximum_relative_equality_residual": equality_residual, "native_primal_residual": primal_residual,
            "native_dual_residual": stationarity_residual, "dual_psd_violation": dual_violation}.items()})
        diagnostics.update(primal_valid=bool(primal_valid), dual_valid=bool(dual_valid), paired_interval_valid=bool(primal_valid and dual_valid and ordered))
        diagnostics["values_satisfy_physical_psd"] = bool(physical_violation <= tolerance)
        if primal_valid:
            result["variables"] = [{"name": name, "value": _text(value, mp)} for name, value in values.items()]
            result["reconstructed_variables"] = [{"name": name, "value": _text(value, mp)} for name, value in reconstructed.items()]
        if problem["mode"] == "feasibility":
            if problem["margin_index"] is not None:
                result["margin_value"] = _text(candidate, mp) if primal_valid else None
                result["margin_lower"] = _text(lower, mp) if primal_valid else None
                result["margin_upper"] = _text(upper, mp) if dual_valid else None
                if primal_valid and dual_valid and ordered and lower > guard and physical_violation <= tolerance:
                    result.update(status="feasible", message="A positive margin and the returned moment values passed numerical validation.")
                elif primal_valid and dual_valid and ordered and upper < -guard:
                    result.update(status="infeasible", message="A negative margin interval and separating dual matrices passed numerical validation.")
                else:
                    result["message"] = "The margin is near the boundary or its numerical validation is inconclusive."
            elif primal_valid and physical_violation <= tolerance:
                result.update(status="feasible", message="The returned values satisfy the scalar constraints within numerical tolerances.")
        else:
            result["objective_value"] = _text(candidate, mp) if primal_valid else None
            result["objective_lower"] = _text(lower, mp) if (dual_valid if problem["direction"] == 1 else primal_valid) else None
            result["objective_upper"] = _text(upper, mp) if (primal_valid if problem["direction"] == 1 else dual_valid) else None
            if primal_valid and dual_valid and ordered and relative_gap <= gap_tolerance:
                result.update(status="optimal", message="The primal and dual objective values agree within the validated numerical tolerances.")
            elif primal_valid:
                result.update(status="feasible", message="A feasible point passed numerical checks; optimality remains unresolved.")
        # Native labels alone are insufficient: test a homogeneous ray before
        # reporting unboundedness or infeasibility from a nonoptimal phase.
        if phase in {"pUNBD", "pINF_dFEAS", "pFEAS_dINF", "dUNBD", "pdINF"}:
            ray_residual, ray_violation, ray_symmetry, separation, projected = _separating_ray(
                duals, numeric_coefficients, stationarity, constants, mp)
            diagnostics["separating_ray"] = {"projected": projected, "stationarity_residual": _text(ray_residual, mp),
                "psd_violation": _text(ray_violation, mp), "separation": _text(separation, mp)}
            if max(ray_violation, ray_symmetry, ray_residual) <= tolerance and separation > guard:
                result.update(status="infeasible", message="A numerical separating dual ray passed independent checks.")
            elif (problem["mode"] != "feasibility" and primal_valid and physical_violation <= tolerance
                  and not _HARD_BOUND_KINDS.intersection(problem["block_kinds"]) and any(x)):
                # Normalize even tiny directions before testing the recession
                # cone. A small point alone is not an improving ray.
                scale = max(abs(v) for v in x)
                homogeneous = [(matrix - constant_matrix) / scale for matrix, constant_matrix in zip(evaluated, constants)]
                _, ray_violation, _ = _matrix_metrics(homogeneous, mp)
                diagnostics["recession_ray"] = {"psd_violation": _text(ray_violation, mp),
                    "objective_slope": _text(primal_objective / scale, mp)}
                if ray_violation <= tolerance and primal_objective / scale < -guard:
                    result.update(status="unbounded", message="A feasible point and improving numerical recession ray passed independent checks.")
        if diagnostics["iteration_limit_reached"]:
            result["message"] += " The solver reached its iteration limit."
        if diagnostics["variable_cutoff_applied"]:
            result["message"] += " This conclusion includes the selected cutoff bounds."
        if diagnostics["observable_inequalities_applied"]:
            result["message"] += " This conclusion includes the selected observable inequalities."
        if result["status"] in {"infeasible", "unbounded"}:
            result.update(objective_value=None, objective_lower=None, objective_upper=None)
        return result
    except (OSError, ValueError, TypeError, KeyError, IndexError, ArithmeticError, RuntimeError) as exc:
        result["message"] = "The solver output is incomplete or failed numerical validation."
        diagnostics["validation_error"] = str(exc)
        return result
