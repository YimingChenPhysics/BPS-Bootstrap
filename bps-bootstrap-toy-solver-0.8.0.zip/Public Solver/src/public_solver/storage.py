"""Atomic portable JSON artifacts shared by CLI and local jobs."""

import json
import os
from pathlib import Path
import tempfile


def write_json(path: Path, value: object, *, compact: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent,
                                         prefix=path.name + ".", suffix=".tmp", delete=False) as handle:
            temporary = Path(handle.name)
            if compact:
                # Coefficient tables are machine artifacts: use the C encoder
                # once, without indentation or millions of tiny writes.
                handle.write(json.dumps(value, ensure_ascii=False, separators=(",", ":")))
            else:
                json.dump(value, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        temporary.replace(path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))

