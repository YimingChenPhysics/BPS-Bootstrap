"""Coefficient-native exact affine rows and sparse pencils.

SymPy expressions enter through ``AffineRows.from_expr`` and leave only through
an explicit ``as_expr`` call. Between those boundaries a row is an immutable,
interned tuple of exact numbers, not a formula that needs extracting again.
"""

from dataclasses import dataclass, field
from types import MappingProxyType

import sympy as sp


@dataclass(frozen=True, slots=True, init=False)
class AffineRow:
    """An immutable exact affine row; ``None`` is its constant coefficient."""

    _items: tuple
    _symbols: frozenset = field(compare=False, repr=False)
    _hash: int = field(compare=False, repr=False)

    def __init__(self, coefficients=()):
        # Public construction is a validation boundary too. The factory uses
        # _validated below after validating and canonicalizing the coefficients.
        mapping = coefficients if hasattr(coefficients, "items") else dict(coefficients)
        row = AffineRows().from_coefficients(mapping)
        object.__setattr__(self, "_items", row._items)
        object.__setattr__(self, "_symbols", row._symbols)
        object.__setattr__(self, "_hash", row._hash)

    @classmethod
    def _validated(cls, items):
        row = object.__new__(cls)
        object.__setattr__(row, "_items", items)
        object.__setattr__(row, "_symbols", frozenset(symbol for symbol, _ in items
                                                    if symbol is not None))
        object.__setattr__(row, "_hash", hash(items))
        return row

    def __hash__(self):
        return self._hash

    def __bool__(self):
        return bool(self._items)

    def items(self):
        return self._items

    @property
    def free_symbols(self):
        return self._symbols

    def as_expr(self):
        """Explicitly reconstruct an expanded expression at an output boundary."""
        return sp.Add(*(part if symbol is None else part * symbol
                        for symbol, coefficient in self._items
                        for part in sp.Add.make_args(coefficient)))


class AffineRows:
    """Validate, normalize and intern rows once within a model or point.

    An optional variable list restricts the accepted symbol scope. Row storage
    sorts symbols by name; this never selects elimination pivots, which still
    follow the ordered variable list supplied to the affine algorithms.
    """

    def __init__(self, variables=None, *, check=lambda: None):
        from .affine import _variables

        self.check = check
        self.variables = None if variables is None else _variables(variables)
        if self.variables is not None and len({v.name for v in self.variables}) != len(self.variables):
            raise ValueError("Affine variables must have distinct names.")
        self._allowed = None if self.variables is None else frozenset(self.variables)
        self._symbols_by_name = {} if self.variables is None else {v.name: v for v in self.variables}
        self._rows = {}
        self._owned_rows = {}
        self._expressions = {}
        self._normalized_numbers = {}
        self._validated_numbers = {}
        self.zero = self._intern_items(())

    def _symbol(self, symbol):
        if symbol is None:
            return
        if not isinstance(symbol, sp.Symbol) or symbol.is_real is False:
            raise ValueError("Affine variables must be real symbols.")
        if self._allowed is not None and symbol not in self._allowed:
            raise ValueError("An affine expression contains an unknown variable.")
        known = self._symbols_by_name.setdefault(symbol.name, symbol)
        if known != symbol:
            raise ValueError("Affine variables must have distinct names.")

    def _number(self, value, *, normalized=False):
        from .affine import _clean, _validated_number

        self.check()
        value = sp.sympify(value)
        # A Float must not hit a numerically equal cached integer/rational key.
        if value.has(sp.Float):
            raise ValueError("Affine coefficients must be finite exact real numbers.")
        cache = self._validated_numbers if normalized else self._normalized_numbers
        if value not in cache:
            result = (_validated_number if normalized else _clean)(value)
            cache[value] = result
            self._validated_numbers[result] = result
            if not normalized:
                self._normalized_numbers.setdefault(result, result)
        return cache[value]

    def _intern_items(self, items):
        row = self._rows.get(items)
        if row is None:
            row = AffineRow._validated(items)
            self._rows[items] = row
            self._owned_rows[row] = row
        return row

    def intern(self, row):
        self.check()
        if not isinstance(row, AffineRow):
            raise TypeError("Only a validated AffineRow can be interned.")
        known = self._owned_rows.get(row)
        if known is not None:
            return known
        for symbol in row.free_symbols:
            self.check()
            self._symbol(symbol)
        return self._intern_items(row.items())

    def from_coefficients(self, coefficients, *, normalized=False):
        """Validate a coefficient map; normalized rows skip simplification only."""
        self.check()
        if isinstance(coefficients, AffineRow):
            return self.intern(coefficients)
        values = []
        for symbol, coefficient in coefficients.items():
            self.check()
            self._symbol(symbol)
            coefficient = self._number(coefficient, normalized=normalized)
            if coefficient != 0:
                values.append((symbol, coefficient))
        values.sort(key=lambda item: (item[0] is not None, "" if item[0] is None else item[0].name))
        return self._intern_items(tuple(values))

    def from_expr(self, expression):
        """Perform the sole formula-to-coefficient conversion at algebra input."""
        from .affine import _AffineTerms

        self.check()
        if isinstance(expression, AffineRow):
            return self.intern(expression)
        expression = sp.sympify(expression)
        if expression in self._expressions:
            return self._expressions[expression]
        variables = (tuple(sorted(expression.free_symbols, key=lambda symbol: symbol.name))
                     if self.variables is None else self.variables)
        for variable in variables:
            self._symbol(variable)
        terms = _AffineTerms(variables, self.check, cleaner=self._number)
        coefficients = terms(expression)
        items = [(None if index == len(variables) else variables[index], coefficient)
                 for index, coefficient in coefficients.items()]
        items.sort(key=lambda item: (item[0] is not None, "" if item[0] is None else item[0].name))
        row = self._intern_items(tuple(items))
        self._expressions[expression] = row
        return row

    def transform(self, row, replacements):
        """Compose simultaneous affine replacements without rebuilding a formula."""
        self.check()
        if not isinstance(row, AffineRow):
            raise TypeError("Affine transformation requires an AffineRow.")
        changed = {}
        for symbol, coefficient in row.items():
            self.check()
            if symbol is None or symbol not in replacements:
                continue
            replacement = replacements[symbol]
            if replacement == symbol or (isinstance(replacement, AffineRow)
                                          and replacement.items() == ((symbol, sp.S.One),)):
                continue
            changed[symbol] = self.from_expr(replacement)
        if not changed:
            return self.intern(row)
        combined = dict(row.items())
        for symbol, replacement in changed.items():
            self.check()
            coefficient = combined.pop(symbol)
            # Remove every changed source before adding the simultaneous targets.
            changed[symbol] = (coefficient, replacement)
        for coefficient, replacement in changed.values():
            for target, value in replacement.items():
                self.check()
                combined[target] = combined.get(target, sp.S.Zero) + coefficient * value
        return self.from_coefficients(combined)

    def select(self, row, kept_symbols):
        """Set omitted coordinates to zero, retaining already-certified numbers."""
        self.check()
        if not isinstance(row, AffineRow):
            raise TypeError("Affine coordinate selection requires an AffineRow.")
        kept = frozenset(kept_symbols)
        for symbol in kept:
            self.check()
            self._symbol(symbol)
        if row.free_symbols <= kept:
            return self.intern(row)
        items = tuple((symbol, coefficient) for symbol, coefficient in row.items()
                      if symbol is None or symbol in kept)
        return self._intern_items(items)


class AffineMatrix:
    """An immutable sparse matrix whose entries are certified affine rows."""

    __slots__ = ("_rows", "_cols", "_entries", "_symbols", "_zero")

    def __init__(self, rows, cols, entries):
        if type(rows) is not int or type(cols) is not int or rows < 0 or cols < 0:
            raise ValueError("Affine matrix dimensions must be nonnegative integers.")
        values = {}
        for position, row in entries.items():
            if (not isinstance(position, tuple) or len(position) != 2
                    or any(type(index) is not int for index in position)
                    or not 0 <= position[0] < rows or not 0 <= position[1] < cols):
                raise ValueError("An affine matrix entry has an invalid coordinate.")
            if not isinstance(row, AffineRow):
                raise TypeError("Affine matrix entries must be validated AffineRows.")
            if row:
                values[position] = row
        object.__setattr__(self, "_rows", rows)
        object.__setattr__(self, "_cols", cols)
        object.__setattr__(self, "_entries", MappingProxyType(values))
        object.__setattr__(self, "_symbols", frozenset().union(*(row.free_symbols for row in set(values.values()))))
        object.__setattr__(self, "_zero", AffineRow._validated(()))

    def __setattr__(self, name, value):
        raise AttributeError("AffineMatrix is immutable.")

    def __eq__(self, other):
        if not isinstance(other, AffineMatrix):
            return NotImplemented
        return self.shape == other.shape and self._entries == other._entries

    @property
    def rows(self):
        return self._rows

    @property
    def cols(self):
        return self._cols

    @property
    def shape(self):
        return self.rows, self.cols

    @property
    def free_symbols(self):
        return self._symbols

    def todok(self):
        return dict(self._entries)

    def __getitem__(self, position):
        if (not isinstance(position, tuple) or len(position) != 2
                or any(type(index) is not int for index in position)
                or not 0 <= position[0] < self.rows or not 0 <= position[1] < self.cols):
            raise IndexError("Invalid affine matrix coordinate.")
        return self._entries.get(position, self._zero)

    def extract(self, rows, cols):
        rows, cols = tuple(rows), tuple(cols)
        if (any(type(i) is not int or not 0 <= i < self.rows for i in rows)
                or any(type(i) is not int or not 0 <= i < self.cols for i in cols)):
            raise IndexError("Invalid affine matrix extraction index.")
        row_map, col_map = {}, {}
        for target, source in enumerate(rows):
            row_map.setdefault(source, []).append(target)
        for target, source in enumerate(cols):
            col_map.setdefault(source, []).append(target)
        entries = {(i, j): value for (row, col), value in self._entries.items()
                   for i in row_map.get(row, ()) for j in col_map.get(col, ())}
        return AffineMatrix(len(rows), len(cols), entries)

    def applyfunc(self, function):
        mapped = {row: function(row) for row in set(self._entries.values())}
        # Match matrix applyfunc even for a function with f(0) != 0.
        zero = function(self._zero)
        if not isinstance(zero, AffineRow) or any(not isinstance(row, AffineRow) for row in mapped.values()):
            raise TypeError("Affine matrix transformations must return AffineRows.")
        if zero:
            entries = {(i, j): mapped.get(self._entries.get((i, j)), zero)
                       for i in range(self.rows) for j in range(self.cols)}
        else:
            entries = {position: mapped[row] for position, row in self._entries.items()}
        return AffineMatrix(self.rows, self.cols, entries)

    def as_expr(self):
        """Explicitly reconstruct a SymPy sparse matrix at a legacy boundary."""
        converted = {row: row.as_expr() for row in set(self._entries.values())}
        return sp.ImmutableSparseMatrix(self.rows, self.cols,
                                       {position: converted[row] for position, row in self._entries.items()})
