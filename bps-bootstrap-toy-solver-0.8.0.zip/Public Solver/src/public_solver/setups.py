"""Named editor configurations, persisted independently of generated results."""

from contextlib import contextmanager
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import sqlite3
import threading
import unicodedata
import uuid

from .constraints import exact_coefficient, validate_constraints
from .moments import validate_request


class SetupStorageError(RuntimeError):
    """Stored setups are unavailable; callers must not replace the store."""


class SetupNotFoundError(LookupError):
    pass


def _name(value):
    if not isinstance(value, str):
        raise ValueError("Enter a setup name of 1–80 characters.")
    name = unicodedata.normalize("NFC", value.strip())
    if not 1 <= len(name) <= 80 or any(unicodedata.category(c) == "Cc" for c in name):
        raise ValueError("Enter a setup name of 1–80 characters without control characters.")
    return name


def _config(value, *, allow_legacy_cutoff=False):
    validation = value
    preparation = value.get("preparation") if isinstance(value, dict) else None
    if allow_legacy_cutoff and isinstance(preparation, dict) and "variable_cutoff" in preparation:
        # Historical setups must remain readable after removing this feature.
        # Validate the former setting, then ignore it only for current-schema
        # validation. Return the original record; never reinterpret its bounds.
        cutoff = preparation["variable_cutoff"]
        if cutoff is not None:
            cutoff = exact_coefficient(cutoff)
            if cutoff.is_real is not True or cutoff.is_positive is not True:
                raise ValueError("The legacy variable cutoff must be a positive exact real number.")
        validation = {**value, "preparation": {
            key: item for key, item in preparation.items() if key != "variable_cutoff"}}
    model, _, _ = validate_request(validation)
    validate_constraints(validation.get("constraints"), model)
    # Keep editor spelling and ordering, including exact coefficient strings.
    return json.loads(json.dumps(value, ensure_ascii=False, allow_nan=False))


class SetupStore:
    def __init__(self, directory: Path):
        self.path = directory.resolve() / "setups.sqlite3"
        self.lock = threading.RLock()

    @contextmanager
    def _connection(self):
        connection = None
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            connection = sqlite3.connect(self.path, timeout=15)
            # SQLite also serializes writers in separate server processes.
            connection.execute("BEGIN IMMEDIATE")
            version = connection.execute("PRAGMA user_version").fetchone()[0]
            if version == 0:
                if connection.execute("SELECT name FROM sqlite_master").fetchone():
                    raise SetupStorageError("Saved setups use an unrecognized storage format. Existing data was not replaced.")
                connection.execute("""CREATE TABLE setups (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    name_key TEXT NOT NULL UNIQUE,
                    updated_at TEXT NOT NULL,
                    config TEXT NOT NULL
                )""")
                connection.execute("PRAGMA user_version = 1")
            elif version != 1:
                raise SetupStorageError("Saved setups use an unsupported storage version. Existing data was not replaced.")
            yield connection
            connection.commit()
        except (sqlite3.Error, OSError) as exc:
            raise SetupStorageError("Saved setups storage could not be read or written. Existing data was not replaced.") from exc
        finally:
            if connection is not None:
                connection.close()

    def _records(self, connection):
        records = []
        try:
            for setup_id, name, name_key, updated_at, config in connection.execute(
                    "SELECT id, name, name_key, updated_at, config FROM setups"):
                if (not isinstance(setup_id, str) or not re.fullmatch(r"[a-f0-9]{32}", setup_id)
                        or _name(name) != name or name.casefold() != name_key
                        or not isinstance(updated_at, str) or not updated_at.endswith("Z")):
                    raise ValueError("Invalid saved setup metadata.")
                datetime.fromisoformat(updated_at.removesuffix("Z") + "+00:00")
                records.append({"id": setup_id, "name": name, "updated_at": updated_at,
                                "config": _config(json.loads(config), allow_legacy_cutoff=True)})
        except (ValueError, TypeError, UnicodeError) as exc:
            raise SetupStorageError("Saved setups contain invalid data. Existing data was not replaced.") from exc
        return sorted(records, key=lambda record: (record["updated_at"], record["id"]), reverse=True)

    def list(self):
        with self.lock, self._connection() as connection:
            return [{key: record[key] for key in ("id", "name", "updated_at")}
                    for record in self._records(connection)]

    def get(self, setup_id):
        if not isinstance(setup_id, str) or not re.fullmatch(r"[a-f0-9]{32}", setup_id):
            raise SetupNotFoundError("Saved setup not found.")
        with self.lock, self._connection() as connection:
            for record in self._records(connection):
                if record["id"] == setup_id:
                    return record
        raise SetupNotFoundError("Saved setup not found.")

    def save(self, name, config):
        name, config = _name(name), _config(config)
        with self.lock, self._connection() as connection:
            existing = next((record for record in self._records(connection)
                             if record["name"].casefold() == name.casefold()), None)
            record = {"id": existing["id"] if existing else uuid.uuid4().hex, "name": name,
                      "updated_at": datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z"),
                      "config": config}
            connection.execute("""INSERT INTO setups (id, name, name_key, updated_at, config)
                VALUES (?, ?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET
                name=excluded.name, name_key=excluded.name_key,
                updated_at=excluded.updated_at, config=excluded.config""",
                (record["id"], name, name.casefold(), record["updated_at"],
                 json.dumps(config, ensure_ascii=False, allow_nan=False)))
            return record
