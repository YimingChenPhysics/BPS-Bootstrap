"""Run native SDPA in isolation, streaming its output to a persistent log."""

import argparse
import errno
import os
from pathlib import Path
import signal
import subprocess
import time
import traceback

from .artifact import load_artifact, text_artifact
from .display import expression_preview
from .objective_values import objective_components_data
from .solver_engine import read_result_data, write_problem_data
from .solver_settings import validate_settings
from .storage import read_json, write_json


class Cancelled(Exception):
    pass


def run_native(command, directory, cancelled):
    """A terminal keeps native stdio line-buffered; the browser reads the file."""
    process = None
    master = slave = None
    with (directory / "console.log").open("ab", buffering=0) as log:
        try:
            if os.name == "posix":
                import pty
                import select
                master, slave = pty.openpty()
                process = subprocess.Popen(command, cwd=directory, stdin=subprocess.DEVNULL,
                                           stdout=slave, stderr=slave)
                os.close(slave)
                slave = None
                while True:
                    if cancelled():
                        raise Cancelled()
                    if select.select([master], [], [], 0.1)[0]:
                        try:
                            chunk = os.read(master, 65536)
                        except OSError as exc:
                            if exc.errno != errno.EIO:
                                raise
                            chunk = b""
                        if not chunk:
                            break
                        log.write(chunk)
                    elif process.poll() is not None:
                        break
            else:
                # Windows native builds write directly to a file. The parent
                # continues checking cancellation even between output flushes.
                process = subprocess.Popen(command, cwd=directory, stdin=subprocess.DEVNULL,
                                           stdout=log, stderr=subprocess.STDOUT)
                while process.poll() is None:
                    if cancelled():
                        raise Cancelled()
                    time.sleep(0.1)
            code = process.wait()
            if code:
                raise ValueError(f"SDPA stopped with exit code {code}. See the iteration log for details.")
        finally:
            if process is not None and process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=2)
            for descriptor in (master, slave):
                if descriptor is not None:
                    os.close(descriptor)


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--directory", type=Path, required=True)
    directory = parser.parse_args(argv).directory.resolve()
    interrupted = False

    def stop(*_):
        nonlocal interrupted
        interrupted = True

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)

    def cancelled():
        return interrupted or (directory / "cancel").exists()

    last_check = last_update = 0.0
    last_stage = None

    def check_cancelled():
        nonlocal last_check
        now = time.monotonic()
        if interrupted or (now - last_check >= 0.1 and cancelled()):
            raise Cancelled()
        if now - last_check >= 0.1:
            last_check = now

    def progress(value):
        nonlocal last_update, last_stage
        check_cancelled()
        now = time.monotonic()
        if (value.get("stage") != last_stage or now - last_update >= 0.1
                or value.get("completed") == value.get("total")):
            write_json(directory / "status.json", {"status": "running", "progress": value})
            last_update, last_stage = now, value.get("stage")

    started = time.monotonic()
    try:
        if cancelled():
            raise Cancelled()
        run = read_json(directory / "run.json")
        progress({"stage": "loading", "message": "Loading the prepared SDP."})
        prepared = load_artifact(read_json(directory / "prepared.json"), check=check_cancelled)
        settings = validate_settings(run["settings"])
        if run.get("summary", {}).get("mode") != "feasibility" and run.get("summary", {}).get("objective") is None:
            optimization = expression_preview(prepared.get("optimization", {}))
            run.setdefault("summary", {})["objective"] = expression_preview(
                text_artifact(optimization, preview_limit=1))
            write_json(directory / "run.json", run)
        problem = write_problem_data(prepared, settings, directory,
                                progress=progress, check_cancelled=check_cancelled)
        if cancelled():
            raise Cancelled()
        result = problem.get("direct_result")
        if result is None:
            progress({"stage": "native", "message": "Running SDPA."})
            run_native([run["executable"], "-ds", str(directory / "problem.dat-s"),
                        "-o", str(directory / "result.txt"), "-p", str(directory / "param.sdpa")],
                       directory, cancelled)
            if cancelled():
                raise Cancelled()
            progress({"stage": "validation", "message": "Checking the SDPA result."})
            result = read_result_data(prepared, problem, settings, directory)
        else:
            (directory / "console.log").write_text("No numerical iterations needed: an exact check resolved the prepared SDP.\n", encoding="utf-8")
        if cancelled():
            raise Cancelled()
        result["objective_components"] = objective_components_data(prepared, result, settings)
        result["elapsed_seconds"] = time.monotonic() - started
        write_json(directory / "result.json", result)
        write_json(directory / "status.json", {"status": "complete"})
        return 0
    except Cancelled:
        write_json(directory / "status.json", {"status": "cancelled"})
        return 0
    except Exception as exc:
        traceback.print_exc()
        if cancelled():
            write_json(directory / "status.json", {"status": "cancelled"})
        else:
            write_json(directory / "status.json", {"status": "failed", "error": str(exc)})
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
