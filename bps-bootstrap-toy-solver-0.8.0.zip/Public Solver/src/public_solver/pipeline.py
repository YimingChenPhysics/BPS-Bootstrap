"""One native exact build pipeline, with an explicit public text adapter."""

import time

from .constraints import validate_constraints
from .moments import BuildLimits, build_moment_data, validate_request, word_basis


def build_request_data(request: dict, *, cache_path=None, limits=BuildLimits(),
                       progress=None, check_cancelled=None, preview_limit=None) -> dict:
    """Build coefficient-native data without formatting mathematical formulas.

    Prepared requests own one complete unfixed-model checkpoint in preparation;
    there is no independently cached text matrix or optional coefficient sidecar.
    Canonical algebra and constraint-elimination recovery remain available to
    both prepared requests and moment-only builds.
    """
    started = time.perf_counter()
    notify = progress or (lambda _: None)
    check = check_cancelled or (lambda: None)
    model, level, neutral = validate_request(request)
    constraints = validate_constraints(request.get("constraints"), model)
    if isinstance(request.get("preparation"), dict) and request["preparation"].get("bmn_su3_reduction"):
        from .bmn_reduction import validate_bmn_setup
        validate_bmn_setup(model, constraints)
    check()
    # Admission checks are independent of whether a compiled model is cached.
    # No enumeration is needed when the user has not selected resource limits.
    # The builder enumerates the ordered basis once; a complete checkpoint
    # already contains it. Admission must not construct a second full copy.
    if limits.max_basis_size is not None or limits.max_selected_entries is not None:
        counts = {}
        for word in word_basis(model, level, limits):
            check()
            charge = model.charge(word)
            counts[charge] = counts.get(charge, 0) + 1
        entries = sum(n * n for n in counts.values())
        if limits.max_selected_entries is not None and entries > limits.max_selected_entries:
            raise ValueError(f"This request selects {entries:,} matrix entries, above the local limit of {limits.max_selected_entries:,}.")

    if "preparation" in request:
        from .preparation import prepare_request_data
        normalized = {**request, "model": model.to_dict(), "level": level,
                      "charge_neutral": neutral, "constraints": constraints}
        result = prepare_request_data(normalized, cache_path=cache_path, limits=limits,
            progress=notify, check_cancelled=check, preview_limit=preview_limit)
    else:
        result = build_moment_data(model, level, charge_neutral=neutral, constraints=constraints,
            cache_path=cache_path, limits=limits, progress=notify, check_cancelled=check)
        result["build_cache"] = {"compiled_model": "disabled"}
    check()
    result["build_elapsed_seconds"] = time.perf_counter() - started
    return result


def build_request(request: dict, *, cache_path=None, limits=BuildLimits(),
                  progress=None, check_cancelled=None, preview_limit=None) -> dict:
    """Return the established complete text/JSON result of the native pipeline.

    Browser workers and numerical solvers use ``build_request_data`` directly.
    This adapter materializes mathematical text only for callers requesting the
    public legacy representation; it does not select another scientific path.
    """
    from .artifact import text_artifact
    data = build_request_data(request, cache_path=cache_path, limits=limits,
        progress=progress, check_cancelled=check_cancelled, preview_limit=preview_limit)
    result = text_artifact({key: value for key, value in data.items() if key != "preparation"},
                           include_display=False)
    if "preparation" in data:
        result["preparation"] = text_artifact(data["preparation"], include_display=True,
                                             preview_limit=preview_limit)
    return result
