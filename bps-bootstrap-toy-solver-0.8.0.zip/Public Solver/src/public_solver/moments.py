"""Neutral-factor moment construction with real Hermitian-conjugate moments."""

from dataclasses import dataclass
from contextlib import nullcontext
from html.entities import html5
from itertools import product
from pathlib import Path
import re
import time
from typing import Callable

import sympy as sp
from sympy.printing.mathml import mathml

from .cache import ALGORITHM_VERSION, CanonicalCache
from .canonical import Canonicalizer
from .model import Model, Word, adjoint_word
from .polynomial import Polynomial, TraceProduct, encode

Progress = Callable[[dict], None]


@dataclass(frozen=True)
class BuildLimits:
    """Optional, explicitly chosen resource limits; None leaves a size uncapped."""
    max_basis_size: int | None = None
    max_selected_entries: int | None = None

    def __post_init__(self):
        if any(value is not None and (type(value) is not int or value < 1)
               for value in (self.max_basis_size, self.max_selected_entries)):
            raise ValueError("Build limits must be positive.")


def validate_request(value: dict) -> tuple[Model, int, bool]:
    if not isinstance(value, dict) or set(value) - {"model", "level", "charge_neutral", "constraints", "preparation"}:
        raise ValueError("A request contains model, level, charge_neutral, and optional constraints and preparation.")
    model = Model.from_dict(value.get("model", {}))
    level = value.get("level", 2)
    charge_neutral = value.get("charge_neutral", True)
    if type(level) is not int or not 0 <= level <= 12:
        raise ValueError("The level must be an integer between 0 and 12.")
    if charge_neutral is not True:
        raise ValueError("Charge neutrality is automatic and cannot be disabled.")
    from .constraints import validate_constraints
    validate_constraints(value.get("constraints"), model)
    if "preparation" in value:
        from .preparation import validate_preparation
        validate_preparation(value["preparation"], model, level)
    return model, level, True


def word_basis(model: Model, level: int, limits: BuildLimits) -> tuple[Word, ...]:
    if type(level) is not int or not 0 <= level <= 12:
        raise ValueError("The level must be an integer between 0 and 12.")
    size = sum(len(model.alphabet) ** k for k in range(level + 1))
    if limits.max_basis_size is not None and size > limits.max_basis_size:
        raise ValueError(f"This request has {size:,} basis words, above the local limit of "
                         f"{limits.max_basis_size:,}. Reduce the level/letters or increase the server limit.")
    return tuple(word for k in range(level + 1) for word in product(model.alphabet, repeat=k))


def _moment_text(model: Model, key: TraceProduct) -> str:
    return "<" + " ".join(f"tr({model.word_text(w)})" for w in key) + ">"


def neutral_factors(model: Model, polynomial: Polynomial) -> Polynomial:
    """Large-N charge selection: every trace factor must be neutral.

    Canonical algebra and its cache stay independent of state assumptions.
    Apply this projection after reduction, including adjoint contact terms.
    Surviving multi-traces remain symbolic at this stage.
    """
    return {key: coefficient for key, coefficient in polynomial.items()
            if all(not any(model.charge(word)) for word in key)}


def _mathml(expression: sp.Expr) -> str:
    # SymPy emits HTML names such as &InvisibleTimes;, but the browser parses
    # these fragments as XML. Numeric entities work in both formats.
    return re.sub(r"&([A-Za-z][A-Za-z0-9]+);",
                  lambda match: "".join(f"&#{ord(c)};" for c in html5[match[1] + ";"])
                  if match[1] + ";" in html5 else match[0],
                  mathml(expression, printer="presentation"))


def _moment_elimination_key(model: Model, key: TraceProduct) -> tuple:
    """Preserve the research reducer's preference for normal-ordered traces.

    Eliminate non-normal single traces, then multi-traces, then normal single
    traces. Within each single-trace class, eliminate shorter words first.
    Normal ordering puts creators before annihilators and sorts species in
    the user's definition order; display names never affect this choice.
    """
    if len(key) != 1:
        return (1, 0, tuple(model.word_key(word) for word in key))
    word = key[0]
    order = model.word_key(word)
    normal = order == tuple(sorted(order))
    return (2 if normal else 0, len(word), order)


def _hermitian_coordinates(keys: set[TraceProduct], canonical: Canonicalizer,
                           check: Callable[[], None]) -> tuple:
    """Identify each moment with its canonical Hermitian conjugate.

Canonicalizing an adjoint can create lower-degree contacts. Imposing merely
real symbols, or pairing labels without those contacts, is insufficient.
The real-moment assumption and all adjoint contact relations are imposed
together, after the neutral-factor projection.
"""
    daggers = {}
    pending = set(keys)
    while pending:
        key = pending.pop()
        check()
        transformed = neutral_factors(canonical.model, canonical.adjoint(key))
        daggers[key] = transformed
        for new in transformed:
            if new and new not in keys:
                keys.add(new)
                pending.add(new)
    ordered = tuple(sorted(keys, key=lambda k: (sum(map(len, k)), len(k),
                                                tuple(canonical.model.word_key(w) for w in k))))
    reals = {key: sp.Symbol(f"r{i}", real=True) for i, key in enumerate(ordered, 1)}

    def component(poly):
        return sp.Add(*(sp.Rational(c.numerator, c.denominator) *
                        (reals[k] if k else 1) for k, c in poly.items()))

    equations = [reals[key] - component(daggers[key]) for key in ordered]
    variables = tuple(reals[key] for key in sorted(
        ordered, key=lambda key: _moment_elimination_key(canonical.model, key)))
    if variables:
        a, b = sp.linear_eq_to_matrix(equations, variables)
        rref, pivots = a.row_join(b).to_DM().to_sparse().rref(method="GJ")
        if len(variables) in pivots:
            raise ArithmeticError("The canonical adjoint relations are inconsistent.")
        substitutions = {}
        for row_index, pivot in enumerate(pivots):
            row = rref.rep.get(row_index, {})
            from_domain = rref.domain.to_sympy
            substitutions[variables[pivot]] = sp.Add(
                from_domain(row.get(len(variables), rref.domain.zero)),
                *(-from_domain(v) * variables[j] for j, v in row.items()
                  if j != pivot and j < len(variables)))
    else:
        substitutions = {}

    resolved_real = {k: sp.expand(v.xreplace(substitutions)) for k, v in reals.items()}
    for equation in equations:
        if sp.expand(equation.xreplace(substitutions)) != 0:
            raise ArithmeticError("Hermitian coordinate reconstruction failed.")

    coordinate = resolved_real
    free = set().union(*(v.free_symbols for v in coordinate.values())) if coordinate else set()
    moments = [{"id": f"m{i}", "traces": [list(w) for w in k],
                "text": _moment_text(canonical.model, k),
                "imag": sp.S.Zero, "real": resolved_real[k]}
               for i, k in enumerate(ordered, 1)]
    records = []
    for i, k in enumerate(ordered, 1):
        symbol = reals[k]
        if symbol in free:
            records.append({"name": str(symbol), "component": "real", "moment_id": f"m{i}",
                            "meaning": _moment_text(canonical.model, k)})
    relations = [{"symbol": str(k), "expression": v}
                 for k, v in substitutions.items()]
    return coordinate, moments, records, relations, variables


def build_moment_data(model: Model, level: int, *, charge_neutral: bool = True,
                        constraints: dict | None = None,
                        cache_path: str | Path | None = None,
                        limits: BuildLimits = BuildLimits(),
                        progress: Progress | None = None,
                        check_cancelled: Callable[[], None] | None = None,
                        stage_cache=None, affine_rows=None) -> dict:
    """Build M_ij=<tr(A_i A_j†)> with neutral factors and real moments.

    Charge selection is automatic, including each factor in multi-traces.
    Optional system constraints are applied as exact linear equations.
    Neutral multi-traces are retained symbolically, not replaced by products.
    Formula fields contain exact sparse ``AffineRow`` values. Mathematical text
    and display markup are produced only by explicit public-output adapters.
    """
    if charge_neutral is not True:
        raise ValueError("Charge neutrality is automatic and cannot be disabled.")
    started = time.perf_counter()
    notify = progress or (lambda _: None)
    check = check_cancelled or (lambda: None)
    from .affine_data import AffineRows
    rows = affine_rows if affine_rows is not None else AffineRows(check=check)
    from .constraints import build_equations, reduce_equations, validate_constraints
    constraint_config = validate_constraints(constraints, model)
    basis = word_basis(model, level, limits)
    charges = tuple(model.charge(w) for w in basis)
    sectors: dict[tuple, list[int]] = {}
    for i, charge in enumerate(charges):
        sectors.setdefault(charge, []).append(i)
    selected_entries = sum(len(s) ** 2 for s in sectors.values())
    if limits.max_selected_entries is not None and selected_entries > limits.max_selected_entries:
        raise ValueError(f"This request selects {selected_entries:,} matrix entries, above the local limit of "
                         f"{limits.max_selected_entries:,}. Reduce the level/letters "
                         "or increase the server limit.")
    cache = CanonicalCache(cache_path, model) if cache_path is not None else None
    canonical = Canonicalizer(model, cache, check)
    try:
        notify({"stage": "canonicalization", "completed": 0, "total": selected_entries,
                "message": f"Canonicalizing {selected_entries:,} selected entries."})
        block_polynomials = []
        canonical_words = {}
        keys: set[TraceProduct] = set()
        completed = 0
        for charge, indices in sectors.items():
            entries = []
            for row, i in enumerate(indices):
                for col, j in enumerate(indices):
                    check()
                    raw_word = basis[i] + adjoint_word(basis[j])
                    polynomial = neutral_factors(model, canonical.word(raw_word))
                    canonical_words[raw_word] = polynomial
                    keys.update(k for k in polynomial if k)
                    entries.append((row, col, polynomial))
                    completed += 1
                    if completed % 100 == 0 or completed == selected_entries:
                        notify({"stage": "canonicalization", "completed": completed,
                                "total": selected_entries, "message": "Reducing traces with graded signs and contacts."})
            block_polynomials.append((charge, indices, entries))
        notify({"stage": "constraints", "message": "Building loop equations and symmetry constraints."})
        equations = build_equations(canonical, level, constraint_config, notify)
        keys.update(key for equation in equations for key in equation.polynomial if key)
        notify({"stage": "hermiticity", "completed": 0, "total": len(keys),
                "message": "Identifying Hermitian-conjugate moments in real coordinates."})
        coordinate, moments, variables, relations, elimination_order = _hermitian_coordinates(
            keys, canonical, check)
        notify({"stage": "constraints", "message": "Reducing the system constraints exactly."})
        from .build_cache import BuildCache
        reduction_cache = (BuildCache(Path(cache_path).with_name("build.sqlite3"))
                           if stage_cache is None and cache_path is not None else nullcontext(stage_cache))
        with reduction_cache as checkpoints:
            substitutions, constraint_rank = reduce_equations(equations, coordinate, elimination_order,
                stage_cache=checkpoints, progress=notify, check_cancelled=check)
        if substitutions:
            resolved_values = {}
            for value in coordinate.values():
                if value not in resolved_values:
                    check()
                    resolved_values[value] = sp.expand(value.xreplace(substitutions))
            coordinate = {key: resolved_values[value] for key, value in coordinate.items()}
            free = set().union(*(v.free_symbols for v in coordinate.values())) if coordinate else set()
            variables = [v for v in variables if sp.Symbol(v["name"], real=True) in free]
            for moment in moments:
                value = coordinate[tuple(tuple(w) for w in moment["traces"])]
                moment["real"] = value
            by_symbol = {"r" + moment["id"][1:]: coordinate[tuple(tuple(w) for w in moment["traces"])]
                         for moment in moments}
            for relation in relations:
                relation["expression"] = by_symbol[relation["symbol"]]
            relations.extend({"symbol": str(symbol), "expression": value}
                             for symbol, value in substitutions.items())
        # Cross the symbolic-elimination boundary once. Downstream preparation
        # receives coefficients directly and never parses our own display text.
        coordinate = {key: rows.from_expr(value) for key, value in coordinate.items()}
        for moment in moments:
            check()
            moment["real"] = coordinate[tuple(tuple(w) for w in moment["traces"])]
            moment["imag"] = rows.zero
        for relation in relations:
            check()
            relation["expression"] = rows.from_expr(relation["expression"])
        check()
        expressions = {}

        def expression(poly: Polynomial):
            cache_key = tuple(sorted(poly.items()))
            if cache_key not in expressions:
                if len(poly) == 1:
                    key, weight = next(iter(poly.items()))
                    if key and weight == 1:
                        expressions[cache_key] = coordinate[key]
                        return expressions[cache_key]
                coefficients = {}
                for key, value in poly.items():
                    check()
                    weight = sp.Rational(value.numerator, value.denominator)
                    if not key:
                        coefficients[None] = coefficients.get(None, sp.S.Zero) + weight
                    else:
                        for symbol, coefficient in coordinate[key].items():
                            coefficients[symbol] = coefficients.get(symbol, sp.S.Zero) + weight * coefficient
                expressions[cache_key] = rows.from_coefficients(coefficients)
            return expressions[cache_key]

        blocks = []
        hermitian_pairs = set()
        notify({"stage": "matrix", "completed": 0, "total": len(sectors),
                "message": "Assembling and checking Hermitian blocks."})
        for charge, indices, entries in block_polynomials:
            check()
            resolved = {(i, j): expression(poly) for i, j, poly in entries}
            for (i, j), value in resolved.items():
                other = resolved[j, i]
                if (value, other) not in hermitian_pairs:
                    check()
                    # Every row has validated real coefficients and variables;
                    # its exact adjoint is itself. Compare coefficients without
                    # rebuilding and expanding the same large formulas again.
                    if value != other:
                        raise ArithmeticError("Moment matrix failed its exact Hermiticity check.")
                    hermitian_pairs.add((value, other))
                    hermitian_pairs.add((other, value))
            blocks.append({"charge": [str(q) for q in charge], "basis_indices": indices,
                "entries": [{"row": i, "col": j, "expression": value}
                            for (i, j), value in resolved.items() if value]})
            notify({"stage": "matrix", "completed": len(blocks), "total": len(sectors),
                    "message": "Exact Hermiticity verified."})
        return {
            "schema_version": 3,
            "algorithm_version": ALGORITHM_VERSION,
            "model": model.to_dict(), "model_fingerprint": model.fingerprint(),
            "settings": {"level": level, "charge_neutral": True,
                         "neutral_trace_factors": True, "real_moments": True},
            "normalization": "Each matrix letter is divided by sqrt(N); tr=Tr/N; only leading large-N terms are retained.",
            "assumptions": {"creation_operators": "unbarred", "annihilation_operators": "barred",
                "annihilator_charges": "negative of creator charges", "moments": "real; Hermitian-conjugate moments identified exactly",
                "multi_traces": "only individually neutral trace factors survive; surviving multi-traces remain symbolic",
                "charged_factor_selection": True, "factorization": "neutral-factor selection at large N",
                "product_substitution": False, "gauge_constraints": constraint_config["gauge_singlet"],
                "bps_constraints": bool(constraint_config["supercharges"]),
                "flavor_symmetry": bool(constraint_config["symmetries"]), "irrep_reduction": False},
            "summary": {"basis_size": len(basis), "block_count": len(blocks),
                "selected_entries": selected_entries, "moment_count": len(moments),
                "real_variable_count": len(variables), "cache_hits": cache.hits if cache else 0,
                "constraint_count": len(equations), "constraint_rank": constraint_rank,
                "cache_misses": cache.misses if cache else canonical.computed,
                "memory_cache_hits": canonical.memory_hits, "elapsed_seconds": time.perf_counter() - started},
            "basis": [{"tokens": list(w), "text": model.word_text(w),
                       "charge": [str(q) for q in charge]} for w, charge in zip(basis, charges)],
            "blocks": blocks, "moments": moments, "variables": variables, "relations": relations,
            "constraints": {"config": constraint_config, "rank": constraint_rank,
                "counts": {family: sum(e.family == family for e in equations)
                           for family in ("gauge", "supercharge", "symmetry")},
                "equations": [{"family": e.family, "generator": e.generator, "test_word": list(e.test_word),
                               "terms": encode(e.polynomial)} for e in equations]},
            "canonical_trace_scope": "Expectation identities after individual-factor charge selection; the reusable algebra cache is unprojected.",
            "canonical_traces": [{"word": list(w), "terms": encode(poly),
                                  "_affine_value": expression(poly)}
                                 for w, poly in sorted(canonical_words.items(), key=lambda x: (len(x[0]), x[0]))],
        }
    finally:
        if cache is not None:
            cache.close()


def build_moment_matrix(model: Model, level: int, *, charge_neutral: bool = True,
                        constraints: dict | None = None,
                        cache_path: str | Path | None = None,
                        limits: BuildLimits = BuildLimits(),
                        progress: Progress | None = None,
                        check_cancelled: Callable[[], None] | None = None,
                        stage_cache=None, include_display: bool = True) -> dict:
    """Public text/JSON adapter over the single exact moment-building algorithm."""
    from .artifact import text_artifact
    data = build_moment_data(model, level, charge_neutral=charge_neutral,
        constraints=constraints, cache_path=cache_path, limits=limits, progress=progress,
        check_cancelled=check_cancelled, stage_cache=stage_cache)
    return text_artifact(data, include_display=include_display)
