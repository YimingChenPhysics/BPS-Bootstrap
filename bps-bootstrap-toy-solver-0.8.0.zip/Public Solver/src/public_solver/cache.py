"""Versioned, checksummed JSON cache. No executable pickle data is loaded."""

import hashlib
import json
from pathlib import Path
import sqlite3

from .model import Model, Word
from .polynomial import Polynomial, decode, encode

ALGORITHM_VERSION = "graded-cyclic-planar-v1"


class CanonicalCache:
    def __init__(self, path: str | Path, model: Model):
        self.model = model
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(path, timeout=30)
        self.connection.execute("PRAGMA journal_mode=WAL")
        self.connection.execute("CREATE TABLE IF NOT EXISTS canonical (namespace TEXT, word TEXT, body TEXT, digest TEXT, PRIMARY KEY(namespace, word))")
        # Canonical algebra depends on ordered statistics, not names or charges.
        self.namespace = hashlib.sha256(json.dumps({"algorithm": ALGORITHM_VERSION,
            "statistics": [s.statistics for s in model.species]}).encode()).hexdigest()
        self.hits = 0
        self.misses = 0
        self.pending = 0

    def get(self, word: Word) -> Polynomial | None:
        row = self.connection.execute("SELECT body,digest FROM canonical WHERE namespace=? AND word=?",
            (self.namespace, json.dumps(word))).fetchone()
        if row is not None:
            body, digest = row
            try:
                if hashlib.sha256(body.encode()).hexdigest() != digest:
                    raise ValueError("Cache checksum mismatch.")
                result = decode(json.loads(body), self.model)
            except (ValueError, TypeError, KeyError, ZeroDivisionError):
                pass
            else:
                self.hits += 1
                return result
        self.misses += 1
        return None

    def put(self, word: Word, value: Polynomial) -> None:
        body = json.dumps(encode(value), separators=(",", ":"))
        self.connection.execute("INSERT OR REPLACE INTO canonical VALUES (?,?,?,?)",
            (self.namespace, json.dumps(word), body, hashlib.sha256(body.encode()).hexdigest()))
        self.pending += 1
        if self.pending >= 100:
            self.connection.commit()
            self.pending = 0

    def close(self) -> None:
        self.connection.commit()
        self.connection.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

