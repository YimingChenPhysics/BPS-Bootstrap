"""Persistent local solve records and ownership of cancellable worker processes."""

from datetime import datetime, timezone
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import threading
import uuid

from .artifact import load_artifact, select_artifact, text_artifact
from .objective_values import objective_components_data
from .sdpa import check_sdpa
from .solver_settings import validate_settings
from .storage import read_json, write_json

ACTIVE = {"queued", "running"}


class SolveManager:
    def __init__(self, directory, jobs):
        self.directory = Path(directory).resolve() / "solves"
        self.directory.mkdir(parents=True, exist_ok=True)
        self.jobs = jobs
        self.processes = {}
        self.component_cache = {}
        self.lock = threading.RLock()
        self.closed = False
        self.owner = (self.directory / ".owner").open("a+b")
        try:
            if os.name == "posix":
                import fcntl
                fcntl.flock(self.owner.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            else:
                import msvcrt
                if self.owner.tell() == 0:
                    self.owner.write(b"0")
                    self.owner.flush()
                self.owner.seek(0)
                msvcrt.locking(self.owner.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            self.owner.close()
            raise ValueError("Another solver app is using this data directory. Close it or choose another --data-dir.") from None
        for path in self.directory.glob("*/status.json"):
            try:
                if read_json(path).get("status") in ACTIVE:
                    (path.parent / "cancel").touch()
                    write_json(path, {"status": "failed", "error":
                        "The server stopped during this solve. Start a new run to try again."})
            except (OSError, ValueError):
                continue

    def _directory(self, run_id):
        if not isinstance(run_id, str) or not re.fullmatch(r"[a-f0-9]{32}", run_id):
            raise ValueError("Unknown solve run.")
        directory = self.directory / run_id
        if not (directory / "run.json").is_file():
            raise ValueError("Unknown solve run.")
        return directory

    def record(self, run_id, compact=False):
        with self.lock:
            directory = self._directory(run_id)
            status = read_json(directory / "status.json")
            running = self.processes.get(run_id)
            if running is not None and running[0].poll() is not None:
                status = read_json(directory / "status.json")
                running[1].close()
                del self.processes[run_id]
                if status["status"] in ACTIVE:
                    status = {"status": "failed", "error": "The solve process stopped before completing."}
                    write_json(directory / "status.json", status)
            record = read_json(directory / "run.json")
            record.pop("executable", None)
            record.pop("setup", None)
            record.update(status)
            if (directory / "result.json").is_file():
                result = read_json(directory / "result.json")
                # Older completed runs already contain the solution and exact
                # loop reductions. Feasible optimization runs previously stored
                # empty components even when a validated point was available.
                # Enrich once, without changing their snapshots.
                if ((result.get("status") == "optimal" and "objective_components" not in result)
                        or (result.get("status") == "feasible" and result.get("objective_value") is not None
                            and not result.get("objective_components"))):
                    if run_id not in self.component_cache:
                        snapshot = directory / "prepared.json"
                        self.component_cache[run_id] = objective_components_data(
                            load_artifact(read_json(snapshot)), result, record.get("settings")) if snapshot.is_file() else []
                    result["objective_components"] = self.component_cache[run_id]
                if compact:
                    result = {key: value for key, value in result.items()
                              if key not in {"variables", "reconstructed_variables", "diagnostics"}}
                record["result"] = result
            return record

    def list(self):
        with self.lock:
            records = []
            for path in self.directory.glob("*/run.json"):
                try:
                    records.append(self.record(path.parent.name, compact=True))
                except (ValueError, OSError):
                    continue
            records.sort(key=lambda item: item["created_at"], reverse=True)
            active = next((record["run_id"] for record in records if record["status"] in ACTIVE), None)
            return {"runs": records, "active_run_id": active}

    def start(self, request):
        if not isinstance(request, dict) or set(request) - {"job_id", "settings", "settings_mode"}:
            raise ValueError("A solve request contains job_id, settings and settings_mode.")
        job_id = request.get("job_id")
        if not isinstance(job_id, str):
            raise ValueError("Build the SDP before solving it.")
        settings_mode = request.get("settings_mode", "default")
        if settings_mode not in {"default", "custom"}:
            raise ValueError("Choose default or custom SDPA settings.")
        settings = validate_settings(request.get("settings"))
        if settings_mode == "default" and settings != validate_settings():
            raise ValueError("Choose custom mode to change SDPA settings.")
        with self.lock:
            if self.closed:
                raise ValueError("The solver app is shutting down.")
            if self.list()["active_run_id"]:
                raise ValueError("A solve is already running. Wait for it or cancel it first.")
            result_path = self.jobs.result_path(job_id)
            saved = read_json(result_path)
            snapshot = select_artifact(saved, "preparation")
            prepared = snapshot["body"]["data"]
            if not isinstance(prepared, dict) or prepared.get("status") != "prepared":
                raise ValueError("This build has no prepared SDP. Resolve the build issues first.")
            installation = check_sdpa(self.jobs.directory)
            if installation.get("status") != "ready":
                raise ValueError(" ".join(filter(None, [installation.get("message"), installation.get("instruction")])) )
            setup = read_json(result_path.parent / "request.json")
            preparation = setup.get("preparation", {})
            optimization = prepared.get("optimization", {"mode": "feasibility"})
            objective_preview = None
            if optimization["mode"] != "feasibility":
                display_path = result_path.with_name("display.json")
                if display_path.is_file():
                    objective_preview = read_json(display_path).get("preparation", {}).get("optimization")
                elif "preparation" in saved:
                    objective_preview = saved["preparation"].get("optimization")
            run_id = uuid.uuid4().hex
            directory = self.directory / run_id
            record = {"run_id": run_id, "job_id": job_id,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "settings_mode": settings_mode, "settings": settings,
                "executable": installation["executable"], "solver_version": installation.get("version"),
                "setup": setup, "summary": {
                    "level": setup["level"], "mode": optimization["mode"],
                    "objective": objective_preview,
                    "fixed_observables": preparation.get("fixed_observables", []),
                    "variable_cutoff": preparation.get("variable_cutoff"),
                    "bmn_observable_cutoff": preparation.get("bmn_observable_cutoff"),
                    "letters": [row["name"] for row in setup["model"]["species"]]}}
            write_json(directory / "run.json", record)
            write_json(directory / "prepared.json", snapshot, compact=True)
            write_json(directory / "status.json", {"status": "queued"})
            log = (directory / "worker.log").open("wb")
            env = dict(os.environ)
            package_root = str(Path(__file__).resolve().parent.parent)
            env["PYTHONPATH"] = package_root + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
            env["PYTHONDONTWRITEBYTECODE"] = "1"
            try:
                process = subprocess.Popen([sys.executable, "-m", "public_solver.solve_worker",
                    "--directory", str(directory)], stdout=log, stderr=log,
                    stdin=subprocess.DEVNULL, env=env, start_new_session=(os.name == "posix"))
            except OSError:
                log.close()
                write_json(directory / "status.json", {"status": "failed", "error": "The solve process could not be started."})
                raise ValueError("The solve process could not be started.") from None
            self.processes[run_id] = (process, log)
            return run_id

    def progress(self, run_id, offset=0):
        if isinstance(offset, bool) or not isinstance(offset, int) or offset < 0:
            raise ValueError("Log offset must be a nonnegative integer.")
        record = self.record(run_id)
        path = self._directory(run_id) / "console.log"
        if path.exists():
            with path.open("rb") as handle:
                handle.seek(min(offset, path.stat().st_size))
                log = handle.read(65536).decode("utf-8", errors="replace")
                next_offset = handle.tell()
        else:
            log, next_offset = "", 0
        return {**record, "log": log, "next_offset": next_offset}

    def download(self, run_id):
        directory = self._directory(run_id)
        return {**self.record(run_id), "setup": read_json(directory / "run.json")["setup"],
                "prepared_sdp": text_artifact(load_artifact(read_json(directory / "prepared.json")))}

    def cancel(self, run_id):
        with self.lock:
            record = self.record(run_id)
            if record["status"] not in ACTIVE:
                return record
            directory = self._directory(run_id)
            (directory / "cancel").touch()
            running = self.processes.get(run_id)
            if running:
                process = running[0]
                try:
                    process.wait(timeout=4)
                except subprocess.TimeoutExpired:
                    if os.name == "posix":
                        try:
                            os.killpg(process.pid, signal.SIGTERM)
                        except ProcessLookupError:
                            pass
                    else:
                        process.terminate()
                    try:
                        process.wait(timeout=2)
                    except subprocess.TimeoutExpired:
                        if os.name == "posix":
                            try:
                                os.killpg(process.pid, signal.SIGKILL)
                            except ProcessLookupError:
                                pass
                        else:
                            process.kill()
                        process.wait(timeout=2)
            if read_json(directory / "status.json")["status"] in ACTIVE:
                write_json(directory / "status.json", {"status": "cancelled"})
            return self.record(run_id)

    def close(self):
        with self.lock:
            if self.closed:
                return
            self.closed = True
            try:
                for run_id in list(self.processes):
                    self.cancel(run_id)
            finally:
                self.owner.close()
