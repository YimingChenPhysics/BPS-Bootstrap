# Guide for AI agents

This folder is a self-contained local application, **BPS Bootstrap: Toy Solver**.
It builds exact large-N oscillator moment constraints and prepares and solves
SDPs. It must remain usable without the parent research project.
See [README.md](README.md) for input formats, installation, and detailed behavior;
see [docs/algebra.md](docs/algebra.md) for the algebra.

## Start here

Use Python 3.10 or later. From this folder, preferably in a virtual environment:

```sh
python -m pip install -e .
python launch.py --no-browser
```

Open `http://127.0.0.1:8769/`; do not open `static/index.html` directly.
In the page, define letters and charges, choose the level and constraints,
configure fixed observables and an objective, then click **Build SDP**.
**Solve** is a separate action. Native **SDPA-GMP** (`sdpa_gmp`) is needed only
for numerical solving, not for building the SDP. Step 4 checks its installation.
Use `SDPA_GMP_EXECUTABLE` or the settings described in the README if it is not
on PATH. No Node.js or external web service is needed to run the app.

## Code map

All application code is in `src/public_solver/`:

- `pipeline.py`: shared cached build workflow for browser, batch, and Python use.
- `model.py`, `canonical.py`, `polynomial.py`: letters, exact oscillator algebra,
  and trace canonicalization. `cache.py` stores reusable canonical results.
- `moments.py`: charge blocks, moment matrices, and Hermitian coordinates;
  `constraints.py` and `brackets.py`: gauge, supercharge, matrix-relation, and
  symmetry equations.
- `constraint_reduction.py`: generic symmetry, gauge, and supercharge/matrix
  family reduction with sparse extraction and exact reconstruction checks.
  Its checkpoints belong to the Sections 1–2 model cache and exclude every
  Section 3 setting. New reductions are verified before saving; trusted cache
  hits do not repeat that algebraic verification. Preserve the existing
  elimination priority and free variables.
- `affine_data.py` defines immutable exact `AffineRow` coefficient maps and
  sparse `AffineMatrix` pencils. They are the mathematical authority after
  moment construction. `artifact.py` stores one interned row table, one exact
  number DAG, and references from all matrices and observables in a versioned,
  checksummed, self-contained artifact. No second full formula representation
  or optional coefficient sidecar participates in the core.
- `pipeline.build_request_data` is the native entry point used by workers.
  `build_request`, `build_moment_matrix`, and `prepare_sdp` are explicit legacy
  text adapters around that same algorithm. Text downloads and old result
  imports convert at their boundary; core preparation/export never print or
  parse formulas. `display.py` selects bounded preview data before rendering.
- `preparation.py` compiles one whole unfixed model: moments, relaxation blocks,
  optional BMN projection, coordinates, and block-equivalence certificates.
  `compiled_model` is an atomic checkpoint in `build.sqlite3`. A cache hit and
  fresh construction feed the same point-preparation function. Model, level,
  constraints, SU(3) switch, and algorithm/SymPy version determine its key;
  fixed targets, objective, inequalities, and cutoff do not. No expression,
  relaxation, fixed-factor, or per-target preparation cache is required.
  The shared model checkpoint and constraint-family checkpoints are deliberate
  dependency boundaries: changing Step 3 observables, numerical targets,
  objectives, or cutoff must reuse them. The SU(3) projection switch belongs
  to the compiled model's identity. Current
  target values must still enter fixed-factor equations, affine elimination,
  and exact null certification. Do not reuse substituted matrices across targets.
  Optional cache-write failures must be logged without aborting computation.
- `affine.py` and `block_reduction.py` operate directly on those rows. Preserve
  `_clean` normalization, elimination priority, ordered pivots, and independent
  variables. Singleton coefficient rows may certify full column rank (including
  after peeling already certified columns); skip RREF only with a complete
  exact certificate. A complete certificate from the substituted original
  pencil remains valid after certified common-kernel compression and exact
  duplicate removal; carry that proof through instead of eliminating again.
  Otherwise use the original ordered exact elimination.
  Full moment reconstruction uses `AffineSubstitution` too, including lifted
  scalar-kernel parameters. Reuse certified source coefficients instead of
  simplifying them again while transporting each moment to the current point.
  Model-wide block equivalence is searched only before point preparation and
  capped at 120 seconds. Retain every unfinished block on timeout and store
  only certified removals in the complete model checkpoint. Cancellation must
  propagate normally.
- Compact `null_direction_plan` / `bmn_su3_null_plan` records preserve scan
  semantics: key by model and fixed-observable definitions, excluding targets,
  names, objective, inequalities, and cutoff. Initial discovery uses numerical
  SVD/QR followed by exact certification. At later values recompute from the
  saved row selections at the baseline dimension and certify against the full
  pencil. Never discover additional nulls at later points. If certification
  fails, retain the full block and preserve the baseline plan. These plans are
  distinct from disposable performance caches; never reuse old numerical
  vectors merely because definitions match.
  Their exact-pencil identity and `exact-null-baselines-v1` namespace are
  independent of compiled-model and general build-cache versions. The compiled
  checkpoint carries that identity once. An exact legacy-key migration adopts
  original plans before transitional rewrite-era plans; historical formula
  rendering belongs only to that one-time compatibility boundary. A storage
  format change must not silently start a new scientific scan baseline.
- `solver_engine.py`, `solver_settings.py`, `sdpa.py`: native coefficient export,
  settings, installation checks, and numerical validation. The native writer
  and validator consume rows directly. Legacy imports parse authoritative text
  once and ignore obsolete optional coefficient copies. Preserve exact number
  and symmetry validation, native settings/scaling, objective offsets, and
  margin exclusion for physical observable bounds. Numerical conversion is
  local to each validation precision.
- `bmn_irrep.py`, `bmn_reduction.py`: optional BMN SU(3) highest-weight reduction.
  Certify the full moment form and project once during model compilation.
  Point preparation sees the projected blocks, with auxiliary relaxation blocks
  preserved. Never prepare the original charge blocks first. Preserve scalar
  coordinates, physical bounds, and objectives. The projection is part of the
  whole model checkpoint; no independent projection cache is needed.
- The separate selectable `preparation.bmn_observable_cutoff` uses one positive exact
  Λ to upper-bound only `tr((f bar(f))^3)` and `tr((phi_1 bar(phi_1))^3)`.
  It requires BMN species/charges and level at least 3, independently of the
  SU(3) reduction switch. Resolve actual species IDs by statistics and charges;
  in the standard preset the words are `[7,-7,7,-7,7,-7]` and
  `[1,-1,1,-1,1,-1]`. Preserve literal ordering and exact contact terms.
  Transport both observables through affine equalities and include each
  independently in scalar-coordinate selection. Append exactly two scalar
  `kind="cutoff"` blocks after physical reduction, including constant blocks;
  do not apply a feasibility-margin shift or add lower/absolute-value bounds.
  Display the two blocks individually. This setting never belongs in the
  Sections 1–2/model or null-plan keys. Complete per-value preparation caching
  is disabled for all models.
  The old general `variable_cutoff` option has been removed. Never silently
  reinterpret historical coordinate bounds as these physical moment bounds.
  The built-in BMN preset enables both BMN options with Λ = 100. The browser
  shows them only when Steps 1–2 match that preset, including level and all its
  gauge/supercharge/symmetry settings, while ignoring display names, species
  ordering, and equivalent exact coefficient spellings. New matching inputs
  without a Step 3 configuration get those defaults. Saved Step 3 choices
  remain authoritative; omitted or disabled options are not re-enabled.
- Section 3 observable rows retain the `preparation.fixed_observables` transport
  field and accept optional `relation` values `=`, `<=`, or `>=`. Omitted and
  explicit `=` normalize to the legacy equality row without a relation field.
  Only equality rows participate in affine elimination, fixed-factor propagation,
  and the fixed-definition/null-plan cache keys. Inequalities preserve each
  observable direction independently during scalar selection, then append
  `kind="inequality"` scalar PSD blocks with residual `value - observable`
  for `<=` or `observable - value` for `>=`. Retain constant bounds and exact
  contact terms. These are hard constraints, excluded from feasibility-margin
  shifts just like BMN cutoff blocks. Model caches remain independent of all
  Section 3 settings. Prepared `fixed_observables` contains equalities only;
  `observable_inequalities` describes bounds. Save, load, and run history must
  preserve the relation and display it accurately.
- `server.py`, `worker.py`, `solve_worker.py`, `solve_runs.py`: local HTTP app,
  background calculations, cancellation, and run history. `static/` contains
  the page and editors; `setups.py` stores named setups. Its read-only legacy
  validation allows old saved cutoff records to remain readable without
  rewriting them; new saves and builds reject the removed active option.
  The browser removes it only from the editable loaded/imported copy and shows
  a persistent notice; it never enables the new BMN cutoff on that basis.
- `builtin_setups.py` and `presets/`: permanent Half BPS, Quarter BPS, Eighth
  BPS, and BMN configurations. These are packaged with the application;
  personal copies stay in local storage.

## Conventions to preserve

- Unbarred letters are **creators**; barred letters are **annihilators**.
  JSON words use positive species IDs for creators and negative IDs for
  annihilators. Word order matters; names are only presentation.
- Charges are exact. Each surviving trace factor is neutral. Moments are
  identified with their Hermitian conjugates under the real-moment assumption,
  including the contact terms from canonicalizing the adjoint.
- Matrix mode imposes `<tr(F O)> = 0` and `<tr(O F†)> = 0` for admissible
  insertions, not an unrestricted operator identity `F = 0`. Ward mode uses
  graded brackets with traced generators. One shared mode applies to all entries.
- Preserve the existing independent-variable selection and exact reconstruction
  checks. Do not silently change mathematical assumptions, chosen UI wording,
  or introduce automatic build-size ceilings. Keep implementations generic
  except for the explicitly authorized, selectable BMN SU(3) block reduction and
  two-observable upper cutoff. Preserve those observable directions when
  selecting independent variables.

## Data and checks

`.public-solver/cache/` holds reusable mathematical checkpoints and compact scan
baseline plans. Users can delete this subfolder after stopping the app; it is
recreated on the next build. Deletion also resets the null-direction baseline
to the first subsequent point, so preserve plans when continuing an existing
scan's dimension convention.
Named setups, build jobs, solver settings, and historical runs stay outside
`cache/` in `.public-solver/`. This is local runtime data, not publishable source. Keep machine
paths and experimental outputs out of application code. Check for active jobs
before restarting the server; a static progress message alone does not prove a
calculation has stalled.

`examples/` contains sample inputs; `dist/` contains a clean source ZIP and an
installable wheel. These can be shared. Tests, research comparisons, audits,
and the maintainer's existing runtime data are kept in a separate sibling folder,
`Public Solver Internal`, which is not required by this application.

When working in the full research checkout, use `Public Solver Internal/run_local.py`
to preserve the maintainer's local setups and history, and follow that folder's
README for tests and release building. A standalone recipient uses `launch.py`
as above. Keep new tests and experimental outputs out of this public folder;
do not interrupt an active user run to execute tests.
