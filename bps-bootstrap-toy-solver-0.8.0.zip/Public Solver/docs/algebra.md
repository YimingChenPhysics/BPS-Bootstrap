# Canonical trace algebra

The internal token `(species, creation)` is represented by a signed integer:
positive for creation, negative for annihilation. Bar notation is confined to
presentation. A model owns its species definitions; there is no global registry.

For unscaled matrix entries, exchanging adjacent operators u and v gives

`u_ij v_kl = (-1)^(p(u)p(v)) v_kl u_ij + c(u,v) delta_il delta_jk`.

The contact is zero except for a species and its adjoint. For a fermionic pair
it is +1 in either order. For a bosonic pair it is +1 for annihilator–creator
and −1 for creator–annihilator. No contact comes from different species.

## One cyclic rotation

Let `w = a0 ... a(n-2) b` and move b left across all preceding entries.
The mother term is the rotated trace, with sign
`s = (-1)^(p(b) sum_j p(aj))`.

Each contraction with `ak` contributes

`(-1)^(p(b) sum_{j=k+1}^{n-2} p(aj)) c(ak,b)`

times the product of traces of `a0...a(k-1)` and `a(k+1)...a(n-2)`.
The two Kronecker deltas join the corresponding color indices and split the
original cycle into precisely these two cycles. An empty trace contributes N
before normalization, and 1 after normalization.

For a length-n normalized trace the normalization is `N^(-1-n/2)`.
The two daughter traces have n−2 letters in total and two trace factors, so
their normalization has the same power of N. The cyclic contact therefore
survives the leading large-N limit. This is why plain cyclic word sorting is
insufficient even for bosons.

For example, with creator X and annihilator bar(X),

`<tr(bar(X) X)> = <tr(X bar(X))> + 1`,

and

`<tr(bar(X) X bar(X) X)> = <tr(X bar(X) X bar(X))> + 2<tr(X bar(X))> + 1`.

For a fermion p the first identity instead reads

`<tr(bar(p) p)> = 1 - <tr(p bar(p))>`.

## Canonical representative and products

Choose the least cyclic rotation using creation before annihilation and the
model's species order. Rotate to it, recursively canonicalizing every shorter
contact daughter. If a periodic word returns to itself with minus sign, solve
`2 tr(w) = contact terms`; do not discard those contacts. The simple case
`tr(p p) = 0` follows automatically.

Products of normalized traces supercommute at leading order. Reordering two
traces can also generate contacts joining their two color cycles into one;
these carry an additional `N^-2` and are outside this truncation. Thus odd
factors acquire a sign on exchange and a repeated odd factor vanishes in the
leading algebra. Trace products label independent multi-trace moments; this
ordering rule is not an assumption of factorized expectation values.

The algebra algorithm and its cache are independent of charges. Moment
construction first selects entries with zero total charge, then discards
every canonical term containing an individually charged trace factor. This
implements the charge-selection consequence of large-N factorization:
`<tr(A)tr(B)>` vanishes if either factor is charged, even when their charges
cancel. Surviving neutral multi-traces remain symbolic at this stage. The
same projection is applied to canonicalized adjoints, including their contacts.
Gauge identities and model-specific Ward identities are later operations.

## Hermitian coordinates

The adjoint reverses a word and swaps creation with annihilation. For products,
it also reverses the order of trace factors. Canonicalizing that adjoint may
generate lower-degree contact terms.

The solver imposes the real-moment assumption `<O> = <O†>` automatically.
Write every formal moment as a real variable `r_k`, and impose
`r_k = neutral_factors(canonical(adjoint(moment_k)))`. Exact rational row
reduction yields independent real coordinates, keeping affine contacts and
graded signs. This is stronger than Hermiticity alone, which would allow
complex off-diagonal entries. Both raw orientations of every matrix entry
are canonicalized; the completed matrix is checked against its transpose
exactly (all entries are real).

## Loop equations and symmetry constraints

Gauge singlets impose `<tr(G W)> = 0`, with

`G = sum_b (b bar(b) - bar(b) b) + sum_f (f bar(f) + bar(f) f) + (n_b - n_f) I`.

Here the unbarred letters create. W runs through neutral words of length
at most `2ℓ−2`. The contact is fixed by statistics; even the empty insertion
reduces consistently to zero. This is a matrix insertion, not a commutator
of two traces.

A traced generator imposes

`<lim(N→∞) N² [tr(Q), tr(W)]_graded> = 0`.

The bracket is an anticommutator when both inputs have odd parity. The
indexed engine commutes the two strings past each other and retains every
contact, then restores color-cycle order with oscillator swaps. After k
contractions, f output trace factors and L closed index loops, the term has
power `N^(f−k+L)` in this rescaling. Only power zero survives. The usual
canonicalizer handles the resulting trace products. Odd trace-factor
exchanges retain their sign. A single-contraction necklace formula is not
enough: multiple contractions can contribute at the same planar order.

The user supplies an odd traced supercharge or an even traced symmetry
generator as a sum of ordered words. The adjoint conjugates coefficients,
reverses words, and negates signed tokens. Both generator and adjoint
equations are generated. Charge neutrality and individual-factor neutrality
are applied after the full algebra. For generators with several charge
components, insertions target the negative charge of each component.

For maximum generator degree d, test words extend through `2ℓ+2−d`.
This includes the standard cubic-supercharge bound `2ℓ−1` and quadratic
symmetry bound `2ℓ`. For mixed-degree generators this common bound keeps
every term of each complete equation within the moment truncation; it does
not impose partial equations obtained by dropping the longer terms.

The **Matrix relation** option instead imposes `<tr(F W)> = 0` and its
adjoint `<tr(W F†)> = 0`, for `|W|≤2ℓ−d`. This reproduces reduced equations
such as `[X,Y]=0` in the quarter-BPS workflow. The adjoint is on the opposite
side of the insertion; contact-aware traces cannot be rotated freely.

All equations share the canonical moment inventory and Hermitian relations.
Coefficients are exact rational/complex radical expressions, parsed by a
small arithmetic grammar. In real moment coordinates, both real and
imaginary parts of every equation are imposed by exact affine row reduction.
The resulting substitutions are applied to the matrix and moment legend.
Contradictions with normalization produce an error, not a matrix result.
The exported equations are canonical physical moment identities before
coordinate elimination; the reported rank is their additional rank after
the automatic Hermitian relations. Redundant equations may remain in the
export, but scalar multiples are deduplicated.

These are generic Ward identities. No SU(2)/SU(3) representation data,
highest-weight blocks, or cone compression are inferred from a generator.
The explicitly enabled BMN option described below is a separate exception.
Neutral multi-traces remain independent variables. Numerical PSD solving
and nonlinear factorization of surviving moments are still later steps.

The canonical cache remains independent of all these state constraints.
Generator equations are recomputed when inputs change. Local guards limit
generator words to eight letters, each definition to 64 terms, definitions
to 12, and insertion/charge-search work to bounded inventories.

## Optional BMN SU(3) moment blocks

The BMN option uses the preset's fundamental scalar triplet, antifundamental
fermion triplet, and singlet `f`, with signed tokens in the public convention.
The simple-root actions are even derivations on ordered words. Within each
commuting charge grade, the joint exact kernel of the two raising operators in
each dominant weight space supplies columns `H`. Every copy of each irrep is
retained; the sum of multiplicity times irrep dimension must reconstruct the
complete graded word space. Word lengths are not separated within a grade.

Before reducing the moment cone, the code certifies symmetry and the exact
Ward identities `Eᵀ M_target = M_source F` for both simple roots on the full
Step 2 affine matrix. Here `F = Eᵀ` in the ordered-word basis. An invariant
Hermitian form on each irrep is determined by its highest-weight multiplicity
matrix, so replacing the full cone by all `Hᵀ M_weight H ≥ 0` is equivalent.
The implementation never applies this assertion to an unverified pencil.

The projected matrices enter Section 3 before fixed-factor equations, null
compression, and scalar-coordinate selection. These operations run once on the
smaller moment blocks and the unchanged multitrace relaxation blocks. Restriction
to all highest-weight multiplicity spaces is injective on invariant forms, so
the projected and full pencils have the same exact coefficient rowspace. This
remains true after fixed-value affine substitution. With the same ordered scalar
columns, exact row reduction therefore selects the same independent variables
and reconstruction formulas. The objective and scalar cutoff bounds retain the
public solver's conventions.

Certified projections and auxiliary structure are model-only caches. Fixed-factor
and null-row plans depend on fixed-observable definitions, excluding numerical
targets, objective and cutoff. Initial null compression uses a numerical proposal
with exact certification. At later targets the cached row selection is certified
again; a failed candidate keeps the full block without searching for new nulls.
Complete per-value preparations are not persisted. Congruence preserves
feasibility and physical optima, but not the numerical value of the auxiliary
minimum-eigenvalue margin.
